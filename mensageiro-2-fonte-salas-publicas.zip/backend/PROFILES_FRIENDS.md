# Perfis visíveis no chat e lista de amigos

Este recurso adiciona foto/nome visíveis em cada mensagem e uma lista de amigos com pedidos por e-mail cadastrado. O destinatário precisa aceitar. O e-mail não é exibido no app. O SQL não altera linhas das mensagens nem permite amizade dar acesso a salas privadas.

## Ativação necessária no Nhost

1. Faça backup do projeto Nhost Mensageiro (`fapcygtcubeukddoieus`).
2. Execute `PROFILES_FRIENDS.sql`; ele cria tabelas e funções novas.
3. Rastreie `messenger_profiles` e `messenger_friend_requests` no Hasura. Rastreie estas funções: `my_messenger_profile`, `room_message_profiles`, `get_message_profile`, `upsert_my_profile`, `request_friend_by_email`, `respond_friend_request`, `my_messenger_friends`, `my_incoming_friend_requests`.
4. Marque cada argumento `hasura_session` como sessão injetada pelo Hasura; conceda execução somente à role autenticada `user`, nunca à role anônima. Não permita que o app forneça sua própria sessão.
5. Não conceda escrita direta em `messenger_friend_requests`. As funções devem gerir pedidos e conferir o destinatário pela sessão autenticada.
6. Configure `messenger_profiles` para impedir que um usuário escreva o perfil de outra pessoa. A mutação `upsert_my_profile` só deve alterar o próprio perfil; nunca exponha email.
7. `room_message_profiles` deve só devolver perfil de remetente em sala que o usuário já pode ler (pública, privada própria ou membro aceito). Teste também IDs de sala privados conhecidos por usuário não convidado: sem nome/foto/mensagens.
8. A função de pedido usa `auth.users.email_verified`. Confirme que essa coluna existe no schema ativo. Se o Nhost usar outro campo para e-mail verificado, adapte a verificação após confirmar o nome correto. Não remova a checagem, nem permita enumeração de usuários.

## Testes antes de liberar

- Em duas contas, preencher perfil com nome/foto e confirmar que nome e foto do remetente aparecem ao lado das mensagens autorizadas.
- Pedido por e-mail: destinatário recebe, aceita, e ambos aparecem na lista Amigos; recusar não cria amizade.
- Confirmar que e-mails não aparecem; conta C não pode alterar perfil alheio, forjar aceite, enumerar contas, nem ler perfis/mensagens de sala privada alheia.
- Não conceder acesso de sala privada automaticamente por ser amigo.

O projeto contém interfaces e funções SQL, mas elas não foram aplicadas ao Nhost nem testadas com duas contas. Até configurar/testar o backend, nomes/fotos e amigos não estarão sincronizados entre aparelhos.
