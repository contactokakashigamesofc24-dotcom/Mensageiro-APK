-- Public-room photo/video attachments stored in ordered chunks; only authenticated users may use functions.
CREATE TABLE IF NOT EXISTS public.message_media_files (
 message_id uuid PRIMARY KEY REFERENCES public.messages(id) ON DELETE CASCADE,
 uploaded_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 mime_type text NOT NULL CHECK (mime_type IN ('image/jpeg','video/mp4')),
 chunk_count integer,
 created_at timestamptz NOT NULL DEFAULT now(),
 completed_at timestamptz,
 CONSTRAINT message_media_count CHECK (chunk_count IS NULL OR chunk_count BETWEEN 1 AND 2147483647)
);
CREATE TABLE IF NOT EXISTS public.message_media_chunks (
 message_id uuid NOT NULL REFERENCES public.message_media_files(message_id) ON DELETE CASCADE,
 chunk_index integer NOT NULL CHECK(chunk_index>=0),
 media_data text NOT NULL CHECK(octet_length(media_data)<=180000),
 PRIMARY KEY(message_id,chunk_index)
);

CREATE OR REPLACE FUNCTION public.create_public_room_media(p_room_id uuid,p_mime_type text,hasura_session json)
RETURNS TABLE(message_id uuid) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_id uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF NOT EXISTS(SELECT 1 FROM public.rooms r WHERE r.id=p_room_id AND r.room_type='public') THEN RAISE EXCEPTION 'Public rooms only'; END IF;
 IF p_mime_type NOT IN ('image/jpeg','video/mp4') THEN RAISE EXCEPTION 'Invalid media'; END IF;
 INSERT INTO public.messages(room_id,sender_id,body) VALUES(p_room_id,v_actor,CASE WHEN p_mime_type='image/jpeg' THEN 'Foto' ELSE 'Vídeo' END) RETURNING id INTO v_id;
 INSERT INTO public.message_media_files(message_id,uploaded_by,mime_type) VALUES(v_id,v_actor,p_mime_type);
 RETURN QUERY SELECT v_id;
END; $fn$;

CREATE OR REPLACE FUNCTION public.add_public_room_media_chunk(p_message_id uuid,p_chunk_index integer,p_mime_type text,p_media_data text,hasura_session json)
RETURNS TABLE(chunk_index integer) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_expected text;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF p_mime_type NOT IN ('image/jpeg','video/mp4') OR p_chunk_index<0 OR octet_length(p_media_data)>180000 OR p_media_data NOT LIKE ('data:'||p_mime_type||';base64,%') OR substring(p_media_data from length('data:'||p_mime_type||';base64,')+1) !~ '^[A-Za-z0-9+/]*={0,2}$' THEN RAISE EXCEPTION 'Invalid media'; END IF;
 SELECT f.mime_type INTO v_expected FROM public.message_media_files f JOIN public.messages m ON m.id=f.message_id JOIN public.rooms r ON r.id=m.room_id WHERE f.message_id=p_message_id AND f.uploaded_by=v_actor AND f.completed_at IS NULL AND r.room_type='public' FOR UPDATE OF f;
 IF NOT FOUND THEN RAISE EXCEPTION 'Not authorized'; END IF;
 IF v_expected<>p_mime_type THEN RAISE EXCEPTION 'MIME mismatch'; END IF;
 INSERT INTO public.message_media_chunks(message_id,chunk_index,media_data) VALUES(p_message_id,p_chunk_index,p_media_data);
 RETURN QUERY SELECT p_chunk_index;
END; $fn$;

CREATE OR REPLACE FUNCTION public.complete_public_room_media(p_message_id uuid,p_chunk_count integer,hasura_session json)
RETURNS TABLE(message_id uuid) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_count bigint; v_min integer; v_max integer;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF p_chunk_count<1 THEN RAISE EXCEPTION 'Invalid count'; END IF;
 SELECT count(*),min(c.chunk_index),max(c.chunk_index) INTO v_count,v_min,v_max FROM public.message_media_chunks c WHERE c.message_id=p_message_id;
 IF v_count<>p_chunk_count OR v_min<>0 OR v_max<>p_chunk_count-1 THEN RAISE EXCEPTION 'Upload incomplete'; END IF;
 UPDATE public.message_media_files f SET chunk_count=p_chunk_count,completed_at=now() FROM public.messages m JOIN public.rooms r ON r.id=m.room_id WHERE f.message_id=p_message_id AND f.uploaded_by=v_actor AND f.completed_at IS NULL AND m.id=f.message_id AND r.room_type='public';
 IF NOT FOUND THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN QUERY SELECT p_message_id;
END; $fn$;

CREATE OR REPLACE FUNCTION public.public_room_media_message_ids(p_room_id uuid,hasura_session json)
RETURNS TABLE(message_id uuid,mime_type text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF NOT EXISTS(SELECT 1 FROM public.rooms r WHERE r.id=p_room_id AND r.room_type='public') THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN QUERY SELECT f.message_id,f.mime_type FROM public.message_media_files f JOIN public.messages m ON m.id=f.message_id WHERE m.room_id=p_room_id AND f.completed_at IS NOT NULL ORDER BY m.created_at;
END; $fn$;

CREATE OR REPLACE FUNCTION public.public_room_media_info(p_message_id uuid,hasura_session json)
RETURNS TABLE(mime_type text,chunk_count integer) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 RETURN QUERY SELECT f.mime_type,f.chunk_count FROM public.message_media_files f JOIN public.messages m ON m.id=f.message_id JOIN public.rooms r ON r.id=m.room_id WHERE f.message_id=p_message_id AND f.completed_at IS NOT NULL AND r.room_type='public';
END; $fn$;

CREATE OR REPLACE FUNCTION public.get_public_room_media_chunks(p_message_id uuid,p_start_index integer,p_limit integer,hasura_session json)
RETURNS TABLE(chunk_index integer,media_data text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF p_start_index<0 OR p_limit<1 OR p_limit>4 THEN RAISE EXCEPTION 'Invalid range'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.message_media_files f JOIN public.messages m ON m.id=f.message_id JOIN public.rooms r ON r.id=m.room_id WHERE f.message_id=p_message_id AND f.completed_at IS NOT NULL AND r.room_type='public') THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN QUERY SELECT c.chunk_index,c.media_data FROM public.message_media_chunks c WHERE c.message_id=p_message_id AND c.chunk_index>=p_start_index ORDER BY c.chunk_index LIMIT p_limit;
END; $fn$;

REVOKE ALL ON FUNCTION public.create_public_room_media(uuid,text,json),public.add_public_room_media_chunk(uuid,integer,text,text,json),public.complete_public_room_media(uuid,integer,json),public.public_room_media_message_ids(uuid,json),public.public_room_media_info(uuid,json),public.get_public_room_media_chunks(uuid,integer,integer,json) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_public_room_media(uuid,text,json),public.add_public_room_media_chunk(uuid,integer,text,text,json),public.complete_public_room_media(uuid,integer,json),public.public_room_media_message_ids(uuid,json),public.public_room_media_info(uuid,json),public.get_public_room_media_chunks(uuid,integer,integer,json) TO PUBLIC;
-- Track functions in Hasura, mark hasura_session as injected, grant execute only to authenticated `user` role. No direct CRUD on media tables.
