# Existing private-room invitations (Nhost/Hasura)

These files are a **prepared change, not yet enabled in production**. They target the existing room IDs in `public.rooms`; they do not create a replacement room. They preserve the public-message long-press deletion code unchanged. No DB rows have been altered by preparing these files.

## Critical identity check before inviting

The existing room `Privado` is `bf795ce4-6517-4020-a63c-ce8539d39682`. Current DB view showed its `created_by` is `4d9fb6ab-ff95-404c-b6ef-621fccdba5e9`. The Nhost dashboard identifies Luiz as `27a5eca4-18d2-4a67-9a34-3e075317740b` and Lucas as an account with `contacto.narutoealadim23@gmail.com`. **These IDs do not match**, so do not invoke the owner-only invite as Luiz on this room. Verify the owner's account/intent first. The owner must use the new “person +” action on the existing private room and invite an already-registered email; the invitee then accepts from their own account.

## Authorization plan

1. Back up the Nhost project before database changes. Apply `PRIVATE_ROOM_INVITES.sql` in the SQL console for this dedicated project only.
2. Track the four functions in Hasura: `invite_room_member_by_email` (VOLATILE mutation), `accept_private_room_invite` (VOLATILE mutation), `my_pending_private_invites` (STABLE query), `my_accepted_private_rooms` (STABLE query). In the Nhost permissions screen, allow execution only for authenticated role `user`; mark each `hasura_session` JSON argument as Hasura's session argument so callers cannot supply their own identity. No admin secret in the app. Confirm anonymous role has no function permission. In Nhost permissions, allow execution only for authenticated role `user`; mark each `hasura_session` JSON argument as the Hasura session argument so callers cannot supply their own identity. No admin secret in the app. Confirm anonymous role has no function permission.
3. For `room_members`, role `user` must have **select only**, columns `room_id,user_id,invited_by,accepted_at,created_at`, row filter `user_id _eq X-Hasura-User-Id`. Deny direct insert/update/delete. The SQL definer functions perform the authorized writes.
4. For `rooms`, role `user` select: `_or` of `room_type _eq public`, `created_by _eq X-Hasura-User-Id`, and related `room_members` with both `user_id _eq X-Hasura-User-Id` and `accepted_at _is_null false`. Do not allow pending memberships to satisfy the private-room branch. Keep owner-preset insert as already configured; deny update/delete.
5. For `messages`, select filter through `room`: public OR room created by current session OR related `room_members` matching current session with `accepted_at` non-null. Insert only `room_id,body`, preset `sender_id` to session user ID, check that room is public, owner-created, or accepted membership (same predicates). Deny all other columns and update. Preserve the existing public delete row filter (sender is session user AND related room is public); do not make private-message deletes broader.
6. Ensure relationship names in Hasura (`rooms.room_members` array relationship and `messages.room` object relationship) match these filters. If console cannot express the exact filters, do not substitute a broader permission; stop and use a reviewed server action.
7. Keep app Nhost GraphQL schema/cache in sync after tracking functions and permissions. App behavior: owners see their existing private rooms and can invite by email; invitees see only a pending invite card (no messages), tapping it explicitly accepts; accepted rooms then appear and message queries use the member permission.

## Required live tests before saying it works

Use actual regular non-admin JWTs for owner, invitee, unrelated outsider; also try anonymous. Record each separately:
- Owner invokes invite on existing `Privado`; verify one pending `room_members` row for Luiz, no new room, and re-inviting is idempotent.
- Pending invitee can see minimal invite title/inviter but cannot query room/messages or send a message by known room UUID.
- Invitee accepts; accepted_at set once; owner and invitee read/send messages to the same exact room ID.
- Outsider and anonymous cannot list private room, read its messages, send, invite, accept another person's invitation, or spoof sender/owner IDs.
- Non-owner cannot invite to that room; accepted membership stays accepted on repeated invite.
- Public messages still work and public sender deletion still enforces author-only.

A successful admin-console SELECT is not proof of the role permissions. Do not declare private access validated until the above non-admin tests pass on two accounts/devices.
