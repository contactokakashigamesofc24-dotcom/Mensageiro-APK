-- Unbounded-duration voice notes, stored in sequential chunks in the dedicated Mensageiro Nhost database.
-- Duration is not capped by the app. Device storage, network, and Nhost storage/GraphQL quotas still apply.
CREATE TABLE IF NOT EXISTS public.message_audio_files (
  message_id uuid PRIMARY KEY REFERENCES public.messages(id) ON DELETE CASCADE,
  uploaded_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  chunk_count integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  CONSTRAINT message_audio_chunk_count CHECK (chunk_count IS NULL OR chunk_count BETWEEN 1 AND 2147483647)
);
CREATE TABLE IF NOT EXISTS public.message_audio_chunks (
  message_id uuid NOT NULL REFERENCES public.message_audio_files(message_id) ON DELETE CASCADE,
  chunk_index integer NOT NULL CHECK (chunk_index >= 0),
  audio_data text NOT NULL CHECK (octet_length(audio_data) <= 180000 AND audio_data LIKE 'data:audio/mp4;base64,%'),
  PRIMARY KEY(message_id,chunk_index)
);

DROP TRIGGER IF EXISTS messenger_audio_file_gate ON public.message_audio_files;
CREATE TRIGGER messenger_audio_file_gate BEFORE INSERT OR UPDATE ON public.message_audio_files
FOR EACH ROW EXECUTE FUNCTION public.enforce_messenger_attachment_write();
DROP TRIGGER IF EXISTS messenger_audio_chunk_gate ON public.message_audio_chunks;
CREATE TRIGGER messenger_audio_chunk_gate BEFORE INSERT ON public.message_audio_chunks
FOR EACH ROW EXECUTE FUNCTION public.enforce_messenger_attachment_write();

CREATE OR REPLACE FUNCTION public.create_private_room_audio(p_room_id uuid,hasura_session json)
RETURNS TABLE(message_id uuid) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_message uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF NOT public.messenger_user_can_access_private_room(p_room_id,v_actor) THEN RAISE EXCEPTION 'Only accepted private-room members may send audio'; END IF;
 INSERT INTO public.messages(room_id,sender_id,body) VALUES(p_room_id,v_actor,'Mensagem de áudio') RETURNING id INTO v_message;
 INSERT INTO public.message_audio_files(message_id,uploaded_by) VALUES(v_message,v_actor);
 RETURN QUERY SELECT v_message;
END; $fn$;

CREATE OR REPLACE FUNCTION public.add_private_room_audio_chunk(p_message_id uuid,p_chunk_index integer,p_audio_data text,hasura_session json)
RETURNS TABLE(chunk_index integer) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF p_chunk_index<0 OR p_chunk_index>=2147483647 OR octet_length(p_audio_data)>180000 OR p_audio_data NOT LIKE 'data:audio/mp4;base64,%' OR substring(p_audio_data from length('data:audio/mp4;base64,')+1) !~ '^[A-Za-z0-9+/]*={0,2}$' THEN RAISE EXCEPTION 'Invalid audio chunk'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.message_audio_files f JOIN public.messages m ON m.id=f.message_id JOIN public.rooms r ON r.id=m.room_id WHERE f.message_id=p_message_id AND f.uploaded_by=v_actor AND f.completed_at IS NULL AND public.messenger_user_can_access_private_room(m.room_id,v_actor)) THEN RAISE EXCEPTION 'Not authorized'; END IF;
 INSERT INTO public.message_audio_chunks(message_id,chunk_index,audio_data) VALUES(p_message_id,p_chunk_index,p_audio_data);
 RETURN QUERY SELECT p_chunk_index;
END; $fn$;

CREATE OR REPLACE FUNCTION public.complete_private_room_audio(p_message_id uuid,p_chunk_count integer,hasura_session json)
RETURNS TABLE(message_id uuid,chunk_count integer) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_rows bigint; v_min integer; v_max integer;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF p_chunk_count NOT BETWEEN 1 AND 2147483647 THEN RAISE EXCEPTION 'Invalid audio'; END IF;
 SELECT count(*),min(c.chunk_index),max(c.chunk_index) INTO v_rows,v_min,v_max FROM public.message_audio_chunks c WHERE c.message_id=p_message_id;
 IF v_rows<>p_chunk_count OR v_min<>0 OR v_max<>p_chunk_count-1 THEN RAISE EXCEPTION 'Audio upload incomplete'; END IF;
 UPDATE public.message_audio_files f SET chunk_count=p_chunk_count,completed_at=now()
 WHERE f.message_id=p_message_id AND f.uploaded_by=v_actor AND f.completed_at IS NULL
 AND EXISTS(SELECT 1 FROM public.messages m WHERE m.id=f.message_id AND public.messenger_user_can_access_private_room(m.room_id,v_actor));
 IF NOT FOUND THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN QUERY SELECT p_message_id,p_chunk_count;
END; $fn$;

CREATE OR REPLACE FUNCTION public.private_room_audio_message_ids(p_room_id uuid,hasura_session json)
RETURNS TABLE(message_id uuid) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF NOT public.messenger_user_can_access_private_room(p_room_id,v_actor) THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN QUERY SELECT f.message_id FROM public.message_audio_files f JOIN public.messages m ON m.id=f.message_id WHERE m.room_id=p_room_id AND f.completed_at IS NOT NULL ORDER BY m.created_at;
END; $fn$;

CREATE OR REPLACE FUNCTION public.get_private_room_audio_chunks(p_message_id uuid,p_start_index integer,p_limit integer,hasura_session json)
RETURNS TABLE(chunk_index integer,audio_data text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF hasura_session->>'x-hasura-role'<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF p_start_index<0 OR p_limit<1 OR p_limit>4 THEN RAISE EXCEPTION 'Invalid range'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.message_audio_files f JOIN public.messages m ON m.id=f.message_id JOIN public.rooms r ON r.id=m.room_id WHERE f.message_id=p_message_id AND f.completed_at IS NOT NULL AND public.messenger_user_can_access_private_room(m.room_id,v_actor)) THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN QUERY SELECT c.chunk_index,c.audio_data FROM public.message_audio_chunks c WHERE c.message_id=p_message_id AND c.chunk_index>=p_start_index ORDER BY c.chunk_index LIMIT p_limit;
END; $fn$;

REVOKE ALL ON FUNCTION public.create_private_room_audio(uuid,json),public.add_private_room_audio_chunk(uuid,integer,text,json),public.complete_private_room_audio(uuid,integer,json),public.private_room_audio_message_ids(uuid,json),public.get_private_room_audio_chunks(uuid,integer,integer,json) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_private_room_audio(uuid,json),public.add_private_room_audio_chunk(uuid,integer,text,json),public.complete_private_room_audio(uuid,integer,json),public.private_room_audio_message_ids(uuid,json),public.get_private_room_audio_chunks(uuid,integer,integer,json) TO PUBLIC;
-- Track functions in Hasura, mark hasura_session as injected session argument. Grant execute only to authenticated role `user`.
-- Audio is supported in private rooms only when the current user is owner or accepted member; public rooms are read-only.
-- Do not grant anonymous access or direct CRUD on either audio table. The app never sees any admin secret.
