-- STAGED ONLY. Do NOT apply to the production Nhost until a recoverable backup is confirmed.
-- Allow an authenticated participant to request friendship with someone who posted in the same room.
-- The caller's identity comes from Hasura's injected session, never from a client-supplied sender ID.
CREATE OR REPLACE FUNCTION public.request_friend_by_user_id_in_room(
  p_room_id uuid,
  p_user_id uuid,
  hasura_session json
)
RETURNS TABLE(request_id uuid)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE
  v_actor uuid;
  v_request uuid;
BEGIN
  IF coalesce(hasura_session->>'x-hasura-role','') <> 'user'
     OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  IF p_user_id IS NULL OR p_room_id IS NULL OR p_user_id = v_actor THEN
    RAISE EXCEPTION 'Invalid friend request';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.rooms r
    WHERE r.id=p_room_id AND (
      r.room_type='public' OR r.created_by=v_actor OR EXISTS (
        SELECT 1 FROM public.room_members m
        WHERE m.room_id=r.id AND m.user_id=v_actor AND m.accepted_at IS NOT NULL
      )
    )
  ) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.messages m
    WHERE m.room_id=p_room_id AND m.sender_id=p_user_id
  ) THEN RAISE EXCEPTION 'User is not visible in this room'; END IF;
  IF EXISTS (
    SELECT 1 FROM public.messenger_friend_requests f
    WHERE f.status='accepted' AND (
      (f.requester_id=v_actor AND f.recipient_id=p_user_id) OR
      (f.requester_id=p_user_id AND f.recipient_id=v_actor)
    )
  ) THEN RAISE EXCEPTION 'Already friends'; END IF;
  INSERT INTO public.messenger_friend_requests(requester_id,recipient_id,status)
  VALUES(v_actor,p_user_id,'pending')
  ON CONFLICT(requester_id,recipient_id) DO UPDATE
    SET status=CASE WHEN messenger_friend_requests.status='declined' THEN 'pending' ELSE messenger_friend_requests.status END,
        created_at=CASE WHEN messenger_friend_requests.status='declined' THEN now() ELSE messenger_friend_requests.created_at END
  RETURNING messenger_friend_requests.request_id INTO v_request;
  RETURN QUERY SELECT v_request;
END; $fn$;
REVOKE ALL ON FUNCTION public.request_friend_by_user_id_in_room(uuid,uuid,json) FROM PUBLIC;
-- Track in Hasura, inject hasura_session, and allow execution only for authenticated role `user`.
-- Do not grant EXECUTE to PostgreSQL PUBLIC or Hasura anonymous; configure the narrow authenticated Hasura role only.
-- Do not expose to anonymous. Never permit client CRUD on messenger_friend_requests.
