-- Private groups in the Mensageiro. Apply only to Nhost project fapcygtcubeukddoieus after backup.
-- Groups use existing private rooms and accepted room_members memberships; do not grant anonymous access.
CREATE TABLE IF NOT EXISTS public.messenger_groups (
  room_id uuid PRIMARY KEY REFERENCES public.rooms(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS messenger_groups_owner_idx ON public.messenger_groups(owner_id);

CREATE OR REPLACE FUNCTION public.create_private_messenger_group(p_title text,p_member_ids uuid[],hasura_session json)
RETURNS TABLE(room_id uuid,group_title text)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_room uuid; v_friend uuid; v_title text;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 v_title:=trim(coalesce(p_title,''));
 IF length(v_title) NOT BETWEEN 1 AND 60 THEN RAISE EXCEPTION 'Group title must be 1 to 60 characters'; END IF;
 IF coalesce(cardinality(p_member_ids),0)<1 OR cardinality(p_member_ids)>50 THEN RAISE EXCEPTION 'Choose 1 to 50 friends'; END IF;
 IF EXISTS(SELECT 1 FROM unnest(p_member_ids) x WHERE x IS NULL OR x=v_actor) OR (SELECT count(DISTINCT x) FROM unnest(p_member_ids) x)<>cardinality(p_member_ids) THEN RAISE EXCEPTION 'Invalid members'; END IF;
 FOREACH v_friend IN ARRAY p_member_ids LOOP
  IF NOT EXISTS(SELECT 1 FROM public.messenger_friend_requests f WHERE f.status='accepted' AND ((f.requester_id=v_actor AND f.recipient_id=v_friend) OR (f.recipient_id=v_actor AND f.requester_id=v_friend))) THEN RAISE EXCEPTION 'Every member must be an accepted friend'; END IF;
 END LOOP;
 INSERT INTO public.rooms(title,room_type,created_by) VALUES(v_title,'private',v_actor) RETURNING id INTO v_room;
 INSERT INTO public.messenger_groups(room_id,owner_id) VALUES(v_room,v_actor);
 INSERT INTO public.room_members(room_id,user_id,invited_by,accepted_at) VALUES(v_room,v_actor,v_actor,now());
 INSERT INTO public.room_members(room_id,user_id,invited_by,accepted_at) SELECT v_room,x,v_actor,NULL FROM unnest(p_member_ids) x;
 RETURN QUERY SELECT v_room,v_title;
END; $fn$;

CREATE OR REPLACE FUNCTION public.my_messenger_groups(hasura_session json)
RETURNS TABLE(room_id uuid,group_title text,owner_id uuid)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 RETURN QUERY SELECT r.id,r.title,g.owner_id FROM public.messenger_groups g JOIN public.rooms r ON r.id=g.room_id JOIN public.room_members m ON m.room_id=g.room_id WHERE m.user_id=v_actor AND m.accepted_at IS NOT NULL ORDER BY g.created_at DESC;
END; $fn$;

CREATE OR REPLACE FUNCTION public.my_pending_group_invites(hasura_session json)
RETURNS TABLE(room_id uuid,group_title text,inviter_id uuid,invited_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 RETURN QUERY SELECT r.id,r.title,m.invited_by,m.created_at FROM public.messenger_groups g JOIN public.rooms r ON r.id=g.room_id JOIN public.room_members m ON m.room_id=g.room_id WHERE m.user_id=v_actor AND m.accepted_at IS NULL ORDER BY m.created_at DESC;
END; $fn$;

CREATE OR REPLACE FUNCTION public.accept_messenger_group_invite(p_room_id uuid,hasura_session json)
RETURNS TABLE(room_id uuid,accepted_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 UPDATE public.room_members m SET accepted_at=coalesce(m.accepted_at,now()) FROM public.messenger_groups g WHERE m.room_id=p_room_id AND g.room_id=m.room_id AND m.user_id=v_actor AND m.accepted_at IS NULL;
 IF NOT FOUND THEN RAISE EXCEPTION 'Group invitation not found'; END IF;
 RETURN QUERY SELECT m.room_id,m.accepted_at FROM public.room_members m WHERE m.room_id=p_room_id AND m.user_id=v_actor AND m.accepted_at IS NOT NULL;
END; $fn$;

REVOKE ALL ON FUNCTION public.create_private_messenger_group(text,uuid[],json),public.my_messenger_groups(json),public.my_pending_group_invites(json),public.accept_messenger_group_invite(uuid,json) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_private_messenger_group(text,uuid[],json),public.my_messenger_groups(json),public.my_pending_group_invites(json),public.accept_messenger_group_invite(uuid,json) TO PUBLIC;
-- Track four functions in Hasura. Mark each hasura_session parameter as injected session argument.
-- Grant execution only to authenticated `user`; deny anonymous. Keep messenger_groups table untracked/default-deny.
-- Hasura default permissions must deny direct INSERT into public.rooms with room_type='private' and deny UPDATE/DELETE on those rooms; only group/owner-approved functions may create them. Configure private room/message SELECT and message INSERT predicates to require owner OR room_members row for session user with accepted_at IS NOT NULL. Restrict room_type to public/private and preset created_by/sender_id from session. Do not grant public-room permissions to private rooms.
-- Deny direct inserts into messenger_groups and room_members; only these checked SECURITY DEFINER functions may create membership.
