-- Global on/off switch for accepting new messages in this Mensageiro deployment.
-- Apply only to the dedicated Nhost project fapcygtcubeukddoieus, after a backup.
-- The allowlisted administrator is Luiz's verified Nhost UUID. This is a public identifier, not a secret.

CREATE TABLE IF NOT EXISTS public.messenger_global_settings (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  enabled boolean NOT NULL DEFAULT true,
  updated_by uuid REFERENCES auth.users(id),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.messenger_global_settings(singleton,enabled) VALUES(true,true)
ON CONFLICT(singleton) DO NOTHING;

CREATE OR REPLACE FUNCTION public.messenger_global_status(hasura_session json)
RETURNS TABLE(enabled boolean, updated_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','') <> 'user'
    OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN
   RAISE EXCEPTION 'Not authorized';
 END IF;
 RETURN QUERY SELECT s.enabled,s.updated_at FROM public.messenger_global_settings s WHERE s.singleton=true;
END; $fn$;

CREATE OR REPLACE FUNCTION public.set_messenger_global_enabled(p_enabled boolean,hasura_session json)
RETURNS TABLE(enabled boolean, updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','') <> 'user'
    OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN
   RAISE EXCEPTION 'Not authorized';
 END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF v_actor <> '27a5eca4-18d2-4a67-9a34-3e075317740b'::uuid THEN RAISE EXCEPTION 'Only the authorized administrator may change the global switch'; END IF;
 INSERT INTO public.messenger_global_settings(singleton,enabled,updated_by,updated_at)
 VALUES(true,p_enabled,v_actor,now())
 ON CONFLICT(singleton) DO UPDATE SET enabled=EXCLUDED.enabled,updated_by=EXCLUDED.updated_by,updated_at=now();
 RETURN QUERY SELECT s.enabled,s.updated_at FROM public.messenger_global_settings s WHERE s.singleton=true;
END; $fn$;

CREATE OR REPLACE FUNCTION public.enforce_messenger_global_enabled()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public AS $fn$
DECLARE v_enabled boolean;
BEGIN
 SELECT s.enabled INTO v_enabled FROM public.messenger_global_settings s WHERE s.singleton=true;
 IF NOT FOUND OR v_enabled IS DISTINCT FROM true THEN RAISE EXCEPTION 'Mensageiro desativado: novas mensagens estão bloqueadas para todos.'; END IF;
 RETURN NEW;
END; $fn$;
DROP TRIGGER IF EXISTS messenger_global_message_gate ON public.messages;
CREATE TRIGGER messenger_global_message_gate BEFORE INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.enforce_messenger_global_enabled();

REVOKE ALL ON public.messenger_global_settings FROM PUBLIC;
REVOKE ALL ON FUNCTION public.messenger_global_status(json),public.set_messenger_global_enabled(boolean,json),public.enforce_messenger_global_enabled() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.messenger_global_status(json),public.set_messenger_global_enabled(boolean,json) TO PUBLIC;
-- Track only messenger_global_status and set_messenger_global_enabled in Hasura.
-- Mark hasura_session as injected session argument; grant execute only to authenticated role `user`; no anonymous access.
-- Do not track/expose messenger_global_settings or grant direct table operations.
-- The BEFORE INSERT trigger is the enforcement point: it blocks normal text, audio, and media message creation.
-- Do not grant client UPDATE on messages or any direct setting-table access. Re-test after every schema/permission change.
