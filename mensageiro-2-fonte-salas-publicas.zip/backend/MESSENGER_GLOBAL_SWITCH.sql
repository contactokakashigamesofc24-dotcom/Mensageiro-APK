-- Global on/off switch for accepting new messages in this Mensageiro deployment.
-- Apply only to the dedicated Nhost project fapcygtcubeukddoieus, after a backup.
-- The allowlisted administrator is Luiz's verified Nhost UUID. This is a public identifier, not a secret.
-- Apply only after checking the UUID belongs to the intended admin account.

CREATE TABLE IF NOT EXISTS public.messenger_global_settings (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  enabled boolean NOT NULL DEFAULT true,
  updated_by uuid REFERENCES auth.users(id),
  updated_at timestamptz NOT NULL DEFAULT now()
);
DO $seed$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.messenger_global_settings WHERE singleton=true) THEN
   INSERT INTO public.messenger_global_settings(singleton,enabled) VALUES(true,true);
 END IF;
END; $seed$;

CREATE OR REPLACE FUNCTION public.messenger_global_status(hasura_session json)
RETURNS TABLE(enabled boolean, updated_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','') <> 'user'
    OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN
   RAISE EXCEPTION 'Not authorized';
 END IF;
 RETURN QUERY SELECT s.enabled,s.updated_at FROM public.messenger_global_settings s WHERE s.singleton=true;
END; $fn$;

CREATE OR REPLACE FUNCTION public.set_messenger_global_enabled(p_enabled boolean,hasura_session json)
RETURNS TABLE(enabled boolean, updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','') <> 'user'
    OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN
   RAISE EXCEPTION 'Not authorized';
 END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 IF v_actor <> '27a5eca4-18d2-4a67-9a34-3e075317740b'::uuid THEN RAISE EXCEPTION 'Only the authorized administrator may change the global switch'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.messenger_global_settings s WHERE s.singleton=true AND s.enabled IS DISTINCT FROM p_enabled) THEN RAISE EXCEPTION 'Mensageiro already has this state'; END IF;
 UPDATE public.messenger_global_settings SET enabled=p_enabled,updated_by=v_actor,updated_at=now() WHERE singleton=true;
 IF NOT FOUND THEN RAISE EXCEPTION 'Settings row is missing; contact administrator'; END IF;
 RETURN QUERY SELECT s.enabled,s.updated_at FROM public.messenger_global_settings s WHERE s.singleton=true;
END; $fn$;

CREATE OR REPLACE FUNCTION public.messenger_user_can_access_private_room(p_room_id uuid,p_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
 SELECT EXISTS(
   SELECT 1 FROM public.rooms r
   WHERE r.id=p_room_id AND r.room_type='private' AND (
     r.created_by=p_user_id OR EXISTS(
       SELECT 1 FROM public.room_members m
       WHERE m.room_id=r.id AND m.user_id=p_user_id AND m.accepted_at IS NOT NULL
     )
   )
 );
$fn$;

CREATE OR REPLACE FUNCTION public.enforce_messenger_attachment_write()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_enabled boolean; v_session jsonb; v_actor uuid; v_owner uuid; v_room uuid; v_parent_table text;
BEGIN
 v_session:=nullif(current_setting('hasura.user',true),'')::jsonb;
 IF v_session IS NULL OR v_session->>'x-hasura-role'<>'user' OR coalesce(v_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(v_session->>'x-hasura-user-id')::uuid;
 SELECT s.enabled INTO v_enabled FROM public.messenger_global_settings s WHERE s.singleton=true;
 IF NOT FOUND OR v_enabled IS DISTINCT FROM true THEN RAISE EXCEPTION 'Mensageiro desativado: upload interrompido.'; END IF;
 IF TG_TABLE_NAME IN ('message_audio_files','message_media_files') THEN
   v_room:=NULL;
   SELECT m.room_id INTO v_room FROM public.messages m WHERE m.id=NEW.message_id;
   v_owner:=NEW.uploaded_by;
 ELSE
   v_parent_table:=CASE TG_TABLE_NAME WHEN 'message_audio_chunks' THEN 'message_audio_files' WHEN 'message_media_chunks' THEN 'message_media_files' ELSE NULL END;
   IF v_parent_table IS NULL THEN RAISE EXCEPTION 'Invalid attachment table'; END IF;
   EXECUTE format('SELECT uploaded_by FROM public.%I WHERE message_id=$1',v_parent_table) INTO v_owner USING NEW.message_id;
   SELECT m.room_id INTO v_room FROM public.messages m WHERE m.id=NEW.message_id;
 END IF;
 IF v_owner IS NULL OR v_room IS NULL OR v_owner<>v_actor OR NOT public.messenger_user_can_access_private_room(v_room,v_actor) THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN NEW;
END; $fn$;

CREATE OR REPLACE FUNCTION public.enforce_messenger_global_enabled()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public AS $fn$
DECLARE v_enabled boolean; v_room_type text; v_owner uuid; v_session jsonb; v_session_user uuid;
BEGIN
 v_session:=nullif(current_setting('hasura.user',true),'')::jsonb;
 IF v_session IS NULL OR v_session->>'x-hasura-role'<>'user' OR coalesce(v_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_session_user:=(v_session->>'x-hasura-user-id')::uuid;
 IF NEW.sender_id IS DISTINCT FROM v_session_user THEN RAISE EXCEPTION 'Sender must match authenticated session'; END IF;
 SELECT s.enabled INTO v_enabled FROM public.messenger_global_settings s WHERE s.singleton=true;
 IF NOT FOUND OR v_enabled IS DISTINCT FROM true THEN RAISE EXCEPTION 'Mensageiro desativado: novas mensagens estão bloqueadas para todos.'; END IF;
 SELECT r.room_type,r.created_by INTO v_room_type,v_owner FROM public.rooms r WHERE r.id=NEW.room_id;
 IF NOT FOUND OR v_room_type<>'private' THEN RAISE EXCEPTION 'Salas públicas estão somente para leitura; use uma sala privada ou grupo por convite.'; END IF;
 IF NEW.sender_id IS DISTINCT FROM v_owner AND NOT EXISTS(
   SELECT 1 FROM public.room_members m WHERE m.room_id=NEW.room_id AND m.user_id=NEW.sender_id AND m.accepted_at IS NOT NULL
 ) THEN RAISE EXCEPTION 'Somente o criador ou um participante que aceitou o convite pode enviar mensagens.'; END IF;
 RETURN NEW;
END; $fn$;
DROP TRIGGER IF EXISTS messenger_global_message_gate ON public.messages;
CREATE TRIGGER messenger_global_message_gate BEFORE INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.enforce_messenger_global_enabled();

CREATE OR REPLACE FUNCTION public.enforce_messenger_global_setting_owner()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_session jsonb; v_actor uuid;
BEGIN
 v_session:=nullif(current_setting('hasura.user',true),'')::jsonb;
 IF v_session IS NULL OR v_session->>'x-hasura-role'<>'user' OR coalesce(v_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(v_session->>'x-hasura-user-id')::uuid;
 IF v_actor<>'27a5eca4-18d2-4a67-9a34-3e075317740b'::uuid OR NEW.updated_by IS DISTINCT FROM v_actor THEN RAISE EXCEPTION 'Only the authorized administrator may change settings'; END IF;
 IF TG_OP='INSERT' THEN RAISE EXCEPTION 'Initial settings are created by migration only'; END IF;
 IF NEW.enabled IS NOT DISTINCT FROM OLD.enabled THEN RAISE EXCEPTION 'No change to settings'; END IF;
 RETURN NEW;
END; $fn$;
DROP TRIGGER IF EXISTS messenger_global_settings_owner_gate ON public.messenger_global_settings;
CREATE TRIGGER messenger_global_settings_owner_gate BEFORE INSERT OR UPDATE ON public.messenger_global_settings
FOR EACH ROW EXECUTE FUNCTION public.enforce_messenger_global_setting_owner();

CREATE OR REPLACE FUNCTION public.enforce_messenger_private_room_owner()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_session jsonb; v_actor uuid;
BEGIN
 IF NEW.room_type<>'private' THEN RAISE EXCEPTION 'Public room creation is disabled'; END IF;
 v_session:=nullif(current_setting('hasura.user',true),'')::jsonb;
 IF v_session IS NULL OR v_session->>'x-hasura-role'<>'user' OR coalesce(v_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(v_session->>'x-hasura-user-id')::uuid;
 IF NEW.created_by IS DISTINCT FROM v_actor THEN RAISE EXCEPTION 'Room owner must match authenticated session'; END IF;
 RETURN NEW;
END; $fn$;
DROP TRIGGER IF EXISTS messenger_private_room_owner_gate ON public.rooms;
CREATE TRIGGER messenger_private_room_owner_gate BEFORE INSERT ON public.rooms
FOR EACH ROW EXECUTE FUNCTION public.enforce_messenger_private_room_owner();

CREATE OR REPLACE FUNCTION public.send_private_message(p_room_id uuid,p_body text,hasura_session json)
RETURNS TABLE(id uuid)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_body text; v_id uuid; v_enabled boolean;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid; v_body:=trim(coalesce(p_body,''));
 SELECT s.enabled INTO v_enabled FROM public.messenger_global_settings s WHERE s.singleton=true;
 IF NOT FOUND OR v_enabled IS DISTINCT FROM true THEN RAISE EXCEPTION 'Mensageiro desativado: envio bloqueado para todos.'; END IF;
 IF length(v_body) NOT BETWEEN 1 AND 4000 THEN RAISE EXCEPTION 'Message must be 1 to 4000 characters'; END IF;
 IF NOT public.messenger_user_can_access_private_room(p_room_id,v_actor) THEN RAISE EXCEPTION 'Only accepted members may send'; END IF;
 INSERT INTO public.messages(room_id,sender_id,body) VALUES(p_room_id,v_actor,v_body) RETURNING messages.id INTO v_id;
 RETURN QUERY SELECT v_id;
END; $fn$;

CREATE OR REPLACE FUNCTION public.create_private_messenger_room(p_title text,hasura_session json)
RETURNS TABLE(id uuid,title text,room_type text,created_by uuid)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_title text; v_id uuid;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 v_title:=trim(coalesce(p_title,''));
 IF length(v_title) NOT BETWEEN 1 AND 100 THEN RAISE EXCEPTION 'Room title must be 1 to 100 characters'; END IF;
 INSERT INTO public.rooms(title,room_type,created_by) VALUES(v_title,'private',v_actor) RETURNING rooms.id INTO v_id;
 RETURN QUERY SELECT r.id,r.title,r.room_type,r.created_by FROM public.rooms r WHERE r.id=v_id;
END; $fn$;

CREATE OR REPLACE FUNCTION public.my_owned_private_rooms(hasura_session json)
RETURNS TABLE(id uuid,title text,created_by uuid,created_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 v_actor:=(hasura_session->>'x-hasura-user-id')::uuid;
 RETURN QUERY SELECT r.id,r.title,r.created_by,r.created_at FROM public.rooms r WHERE r.room_type='private' AND r.created_by=v_actor ORDER BY r.created_at DESC;
END; $fn$;

CREATE OR REPLACE FUNCTION public.readable_public_rooms(hasura_session json)
RETURNS TABLE(id uuid,title text,created_by uuid,created_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
BEGIN
 IF coalesce(hasura_session->>'x-hasura-role','')<>'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
 RETURN QUERY SELECT r.id,r.title,r.created_by,r.created_at FROM public.rooms r WHERE r.room_type='public' ORDER BY r.created_at DESC;
END; $fn$;


REVOKE ALL ON public.messenger_global_settings FROM PUBLIC;
REVOKE ALL ON FUNCTION public.messenger_global_status(json),public.set_messenger_global_enabled(boolean,json),public.readable_public_rooms(json),public.my_owned_private_rooms(json),public.enforce_messenger_global_enabled(),public.enforce_messenger_attachment_write(),public.messenger_user_can_access_private_room(uuid,uuid),public.enforce_messenger_global_setting_owner(),public.enforce_messenger_private_room_owner(),public.create_private_messenger_room(text,json),public.send_private_message(uuid,text,json) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.messenger_global_status(json),public.set_messenger_global_enabled(boolean,json),public.readable_public_rooms(json),public.my_owned_private_rooms(json),public.create_private_messenger_room(text,json),public.send_private_message(uuid,text,json) TO PUBLIC;
-- Track messenger_global_status, set_messenger_global_enabled, readable_public_rooms, create_private_messenger_room, send_private_message. my_owned_private_rooms is in PRIVATE_ROOM_INVITES.sql. Inject hasura_session.
-- readable_public_rooms exposes titles only for historical public rooms; no public message insert permission.
-- Mark hasura_session as injected session argument; grant execute only to authenticated role `user`; no anonymous access.
-- Do not track/expose messenger_global_settings or grant direct table operations.
-- The BEFORE INSERT trigger enforces both global pause and accepted-member-only writes. Public rooms become read-only; private room writes require owner or accepted member. For standard Hasura requests the trigger also checks current_setting('hasura.user') against NEW.sender_id; deny direct anonymous SQL/API pathways and preserve Hasura's preset sender_id.
-- Hasura messages INSERT must preset sender_id from X-Hasura-User-Id and allow only rooms accessible to that same session user. Never trust a client-chosen sender_id.
-- Attachments must also receive BEFORE INSERT triggers on their file/chunk tables to stop an upload mid-stream after pause; see their SQL scripts.
-- Do not grant client UPDATE on messages or any direct setting-table access. Re-test after every schema/permission change.
