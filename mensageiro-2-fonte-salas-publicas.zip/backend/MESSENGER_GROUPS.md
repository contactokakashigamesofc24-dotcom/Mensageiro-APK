# Grupos privados do Mensageiro

O app permite criar grupo com nome e selecionar amigos já aceitos. O criador entra como membro; as demais pessoas recebem convite pendente. Cada convidado precisa aceitar para entrar e ler/enviar mensagens. Ser amigo, por si só, não dá acesso às conversas. A criação aceita de 1 a 50 amigos. Grupos são privados; não publique conteúdo que exija sigilo forte — o app/backend não têm criptografia ponta a ponta.

## Configuração obrigatória antes de testar

1. Faça backup do projeto dedicado Nhost do Mensageiro (`fapcygtcubeukddoieus`) e execute `MESSENGER_GROUPS.sql`.
2. Rastreie quatro funções no Hasura: `create_private_messenger_group` (mutação), `my_messenger_groups` (consulta), `my_pending_group_invites` (consulta), `accept_messenger_group_invite` (mutação). Configure `hasura_session` como argumento de sessão injetado. Permita execução só para usuário autenticado; nada para anônimo. Não exponha nem rastreie a tabela `messenger_groups` com acesso ao cliente.
3. Mantenha `room_members` sem insert/update/delete direto. Só as funções com verificação de sessão podem criar membros e aceitar convites.
4. Nas permissões Hasura de `rooms` e `messages`, configure leitura para sala privada somente se for criada pelo usuário atual ou existir `room_members` para ele com `accepted_at` não nulo. Escrita de mensagens exige essa mesma condição e remetente sempre definido pela sessão. Nunca conceda acesso pela presença de uma associação pendente. Bloqueie insert direto de salas `private`, edição e exclusão; configure `rooms.room_type` restrito a `public/private`, e siga as relações `messages.room`/`rooms.room_members` em `PRIVATE_ROOM_INVITES.md`. Não deixe filtros antigos de sala pública abrirem leitura ou escrita em sala privada.
5. Funções de áudio, fotos/vídeos e perfis devem continuar restringindo sala privada a dono/membro aceito. Esta versão de mídia ainda pode estar limitada a salas públicas — verifique cada recurso antes de liberar em grupo.

## Testes necessários em duas ou mais contas comuns

- Criar grupo com Luiz e amigo já aceito; confirmar um único grupo e convites pendentes.
- Antes de aceitar, convidado e terceiro não conseguem ler nem enviar mensagens, mesmo com o UUID da sala.
- Convidado aceita e ambos passam a ver/enviar mensagens no mesmo grupo; o terceiro continua bloqueado.
- Recusar/não aceitar não dá acesso; conta anônima não pode listar, ler, escrever, criar convite nem forjar identidade.
- Confirmar mensagens em salas públicas e privadas anteriores continuam funcionando e que não existe mudança global em permissões.

Até aplicar SQL, rastrear/configurar permissões e validar esses testes com tokens não administrativos, o recurso é código preparado e não está sincronizado/seguro para uso real. Nunca use JWT administrativo no APK.
