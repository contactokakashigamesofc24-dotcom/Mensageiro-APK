# Grupos privados do Mensageiro

O app permite criar grupo com nome e selecionar amigos já aceitos. O criador entra como membro; as demais pessoas recebem convite pendente. Cada convidado precisa aceitar para entrar e ler/enviar mensagens. Ser amigo, por si só, não dá acesso às conversas. A criação aceita de 1 a 50 amigos. Grupos são privados; não publique conteúdo que exija sigilo forte — o app/backend não têm criptografia ponta a ponta.

## Configuração obrigatória antes de testar

1. Aplique primeiro `MESSENGER_GLOBAL_SWITCH.sql`, `PROFILES_FRIENDS.sql` e `PRIVATE_ROOM_INVITES.sql` (backup do projeto dedicado Nhost antes). Então execute `MESSENGER_GROUPS.sql`. O helper/trigger do controle global permite criação de sala apenas por função segura; a função de grupos usa contexto transacional para criar a sala e aceitar amizades já configuradas.
2. Rastreie quatro funções no Hasura: `create_private_messenger_group` (mutação), `my_messenger_groups` (consulta), `my_pending_group_invites` (consulta), `accept_messenger_group_invite` (mutação). Configure `hasura_session` como argumento de sessão injetado. Permita execução só para usuário autenticado; nada para anônimo. Não exponha nem rastreie a tabela `messenger_groups` com acesso ao cliente.
3. Mantenha `room_members` sem insert/update/delete direto. Só as funções com verificação de sessão podem criar membros e aceitar convites.
4. Salas públicas devem ser somente leitura: desabilite o envio público no app e configure o trigger/filtros server-side de `MESSENGER_GLOBAL_SWITCH.sql`. Nas permissões Hasura de `rooms` e `messages`, configure leitura para sala privada somente se for criada pelo usuário atual ou existir `room_members` para ele com `accepted_at` não nulo. Escrita de mensagens exige essa mesma condição e remetente sempre definido pela sessão. Nunca conceda acesso pela presença de uma associação pendente. Bloqueie insert direto de salas, edição e exclusão; a criação segura usa funções SQL. Configure `rooms.room_type` restrito a `public/private`, e siga as relações `messages.room`/`rooms.room_members` em `PRIVATE_ROOM_INVITES.md`. Não deixe filtros antigos de sala pública abrirem leitura ou escrita em sala privada.
5. Funções de áudio, fotos/vídeos e perfis devem continuar restringindo sala privada a dono/membro aceito. O SQL atualizado de áudio e foto/vídeo usa o mesmo helper de membro aceito; aplique-o após `MESSENGER_GLOBAL_SWITCH.sql` e teste cada tipo antes de liberar.

## Testes necessários em duas ou mais contas comuns

- Criar grupo com Luiz e amigo já aceito; confirmar um único grupo e convites pendentes.
- Antes de aceitar, convidado e terceiro não conseguem ler nem enviar mensagens, mesmo com o UUID da sala.
- Convidado aceita e ambos passam a ver/enviar mensagens no mesmo grupo; o terceiro continua bloqueado.
- Recusar/não aceitar não dá acesso; conta anônima não pode listar, ler, escrever, criar convite nem forjar identidade.
- Confirmar que salas públicas são somente leitura e que grupos privados estão isolados de contas não membros.

Até aplicar SQL, rastrear/configurar permissões e validar esses testes com tokens não administrativos, o recurso é código preparado e não está sincronizado/seguro para uso real. Nunca use JWT administrativo no APK.
