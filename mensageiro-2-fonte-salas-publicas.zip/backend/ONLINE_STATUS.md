# Estado online/offline

O nome e a foto continuam na linha de perfil; logo abaixo aparece um ponto colorido e Online/Offline. Para amigos, lista Amigos mostra presença também. O app envia heartbeat a cada 15 segundos enquanto aberto e visível. Ao voltar ao fundo, tenta remover o estado; se o Android matar o processo, o servidor considera offline após 45 segundos sem heartbeat.

## Configurar

1. Faça backup do backend Nhost Mensageiro e aplique `ONLINE_STATUS.sql`.
2. Rastreie as funções `set_my_presence`, `my_presence_state` e `my_friends_presence` no Hasura, marcando `hasura_session` como valor de sessão injetado.
3. Permita execução apenas para role autenticada `user`, não para anonymous. Não conceda leitura/escrita direta em `messenger_presence`.
4. Teste duas contas: A entra e B (amigo aceito) a vê Online; A fecha o app e, após ~45 s, B vê Offline. Faça teste também com modo avião e encerramento forçado. O indicador é melhor esforço e pode demorar até 45 s para detectar queda abrupta.

O status é compartilhado com amigos aceitos, não é uma localização. Não foi aplicado nem testado no Nhost ainda. A interface exige o backend e versão compilada para funcionar.
