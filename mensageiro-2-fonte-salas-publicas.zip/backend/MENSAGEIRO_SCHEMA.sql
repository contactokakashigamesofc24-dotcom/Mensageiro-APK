-- Execute only in the dedicated Nhost project "Mensageiro".
-- First chat phase: public rooms and owner-only private rooms. Invites are intentionally not enabled yet.
create extension if not exists pgcrypto;

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(trim(title)) between 1 and 100),
  room_type text not null check (room_type in ('public','private')),
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (length(trim(body)) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists messages_room_created_idx on public.messages(room_id, created_at);

-- Track public.rooms and public.messages in Hasura after executing this SQL.
-- Configure role "user" as described in HASURA_PERMISSIONS.md BEFORE installing/testing the app.
-- Nhost/Hasura is default-deny for user role. Never put the admin secret into the APK.

create table if not exists public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  invited_by uuid not null references auth.users(id) on delete cascade,
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  primary key (room_id, user_id)
);
create index if not exists room_members_user_room_idx on public.room_members(user_id, room_id);
