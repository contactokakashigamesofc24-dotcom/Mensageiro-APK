-- User profiles (display name + optional compressed avatar) and friend requests.
-- Apply only to Mensageiro Nhost project fapcygtcubeukddoieus.
CREATE TABLE IF NOT EXISTS public.messenger_profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL CHECK (length(trim(display_name)) BETWEEN 1 AND 60),
  avatar_data text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT messenger_profiles_avatar_size CHECK (avatar_data IS NULL OR octet_length(avatar_data) <= 300000),
  CONSTRAINT messenger_profiles_avatar_type CHECK (avatar_data IS NULL OR avatar_data LIKE 'data:image/jpeg;base64,%')
);
CREATE TABLE IF NOT EXISTS public.messenger_friend_requests (
  request_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined')),
  created_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  CONSTRAINT messenger_friend_no_self CHECK (requester_id <> recipient_id),
  CONSTRAINT messenger_friend_pair_unique UNIQUE (requester_id, recipient_id)
);
CREATE INDEX IF NOT EXISTS messenger_friend_recipient_status_idx ON public.messenger_friend_requests(recipient_id,status);
CREATE INDEX IF NOT EXISTS messenger_friend_requester_status_idx ON public.messenger_friend_requests(requester_id,status);

CREATE OR REPLACE FUNCTION public.my_messenger_profile(hasura_session json)
RETURNS SETOF public.messenger_profiles LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  RETURN QUERY SELECT * FROM public.messenger_profiles p WHERE p.user_id=v_actor;
END; $fn$;

CREATE OR REPLACE FUNCTION public.room_message_profiles(p_room_id uuid, hasura_session json)
RETURNS TABLE(sender_id uuid, display_name text, avatar_data text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  IF NOT EXISTS (
    SELECT 1 FROM public.rooms r WHERE r.id=p_room_id AND (
      r.room_type='public' OR r.created_by=v_actor OR EXISTS (
        SELECT 1 FROM public.room_members rm WHERE rm.room_id=r.id AND rm.user_id=v_actor AND rm.accepted_at IS NOT NULL
      )
    )
  ) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  RETURN QUERY SELECT DISTINCT p.user_id,p.display_name,p.avatar_data FROM public.messages m
    JOIN public.messenger_profiles p ON p.user_id=m.sender_id WHERE m.room_id=p_room_id;
END; $fn$;

CREATE OR REPLACE FUNCTION public.get_message_profile(p_user_id uuid, hasura_session json)
RETURNS TABLE(display_name text, avatar_data text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  IF p_user_id <> v_actor AND NOT EXISTS (
      SELECT 1 FROM public.rooms r
      JOIN public.messages m ON m.room_id=r.id
      WHERE m.sender_id=p_user_id AND (
        r.room_type='public' OR r.created_by=v_actor OR EXISTS (
          SELECT 1 FROM public.room_members rm WHERE rm.room_id=r.id AND rm.user_id=v_actor AND rm.accepted_at IS NOT NULL
        )
      )
  ) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  RETURN QUERY SELECT p.display_name,p.avatar_data FROM public.messenger_profiles p WHERE p.user_id=p_user_id;
END; $fn$;

CREATE OR REPLACE FUNCTION public.upsert_my_profile(p_display_name text, p_avatar_data text, hasura_session json)
RETURNS SETOF public.messenger_profiles LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  IF length(trim(p_display_name)) NOT BETWEEN 1 AND 60 OR (p_avatar_data IS NOT NULL AND (octet_length(p_avatar_data)>300000 OR p_avatar_data NOT LIKE 'data:image/jpeg;base64,%')) THEN RAISE EXCEPTION 'Invalid profile'; END IF;
  INSERT INTO public.messenger_profiles(user_id,display_name,avatar_data) VALUES(v_actor,trim(p_display_name),p_avatar_data)
  ON CONFLICT(user_id) DO UPDATE SET display_name=excluded.display_name, avatar_data=COALESCE(excluded.avatar_data,public.messenger_profiles.avatar_data), updated_at=now();
  RETURN QUERY SELECT * FROM public.messenger_profiles p WHERE p.user_id=v_actor;
END; $fn$;

CREATE OR REPLACE FUNCTION public.request_friend_by_email(p_email text, hasura_session json)
RETURNS TABLE(request_id uuid) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_target uuid; v_request uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  SELECT id INTO v_target FROM auth.users WHERE lower(email)=lower(trim(p_email)) AND email_verified IS TRUE LIMIT 1;
  IF v_target IS NULL OR v_target=v_actor THEN RAISE EXCEPTION 'Conta não encontrada ou pedido inválido'; END IF;
  INSERT INTO public.messenger_friend_requests(requester_id,recipient_id,status) VALUES(v_actor,v_target,'pending')
  ON CONFLICT(requester_id,recipient_id) DO UPDATE SET status=CASE WHEN messenger_friend_requests.status='declined' THEN 'pending' ELSE messenger_friend_requests.status END,created_at=CASE WHEN messenger_friend_requests.status='declined' THEN now() ELSE messenger_friend_requests.created_at END
  RETURNING messenger_friend_requests.request_id INTO v_request;
  RETURN QUERY SELECT v_request;
END; $fn$;

CREATE OR REPLACE FUNCTION public.respond_friend_request(p_request_id uuid,p_accept boolean,hasura_session json)
RETURNS TABLE(request_id uuid,status text) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid; v_status text;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  UPDATE public.messenger_friend_requests r SET status=CASE WHEN p_accept THEN 'accepted' ELSE 'declined' END,responded_at=now()
  WHERE r.request_id=p_request_id AND r.recipient_id=v_actor AND r.status='pending' RETURNING r.status INTO v_status;
  IF v_status IS NULL THEN RAISE EXCEPTION 'Pedido não encontrado'; END IF;
  RETURN QUERY SELECT p_request_id,v_status;
END; $fn$;

CREATE OR REPLACE FUNCTION public.my_messenger_friends(hasura_session json)
RETURNS TABLE(user_id uuid,display_name text,avatar_data text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  RETURN QUERY SELECT p.user_id,p.display_name,p.avatar_data FROM public.messenger_friend_requests r JOIN public.messenger_profiles p ON p.user_id=CASE WHEN r.requester_id=v_actor THEN r.recipient_id ELSE r.requester_id END
  WHERE r.status='accepted' AND (r.requester_id=v_actor OR r.recipient_id=v_actor) ORDER BY p.display_name;
END; $fn$;

CREATE OR REPLACE FUNCTION public.my_incoming_friend_requests(hasura_session json)
RETURNS TABLE(request_id uuid,user_id uuid,display_name text,avatar_data text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  RETURN QUERY SELECT r.request_id,p.user_id,p.display_name,p.avatar_data FROM public.messenger_friend_requests r JOIN public.messenger_profiles p ON p.user_id=r.requester_id WHERE r.recipient_id=v_actor AND r.status='pending' ORDER BY r.created_at DESC;
END; $fn$;

REVOKE ALL ON FUNCTION public.my_messenger_profile(json), public.room_message_profiles(uuid,json), public.get_message_profile(uuid,json), public.upsert_my_profile(text,text,json), public.request_friend_by_email(text,json), public.respond_friend_request(uuid,boolean,json), public.my_messenger_friends(json), public.my_incoming_friend_requests(json) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.my_messenger_profile(json), public.room_message_profiles(uuid,json), public.get_message_profile(uuid,json), public.upsert_my_profile(text,text,json), public.request_friend_by_email(text,json), public.respond_friend_request(uuid,boolean,json), public.my_messenger_friends(json), public.my_incoming_friend_requests(json) TO PUBLIC;
-- Track all eight functions in Hasura, mark hasura_session as session argument, grant execute only to role user.
-- Track messenger_profiles; permit authenticated user select only profile fields needed by chat, insert/update own user_id = X-Hasura-User-Id. Do not expose email.
