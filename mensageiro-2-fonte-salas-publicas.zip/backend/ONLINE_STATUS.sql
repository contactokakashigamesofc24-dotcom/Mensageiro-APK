-- Presence for Messenger. Last heartbeat expires after 45 s if the app closes/crashes/offline.
-- Apply only to Nhost Mensageiro project.
CREATE TABLE IF NOT EXISTS public.messenger_presence (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  last_seen timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS messenger_presence_last_seen_idx ON public.messenger_presence(last_seen);

CREATE OR REPLACE FUNCTION public.set_my_presence(p_online boolean, hasura_session json)
RETURNS TABLE(user_id uuid,last_seen timestamptz) LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  IF p_online THEN
    INSERT INTO public.messenger_presence(user_id,last_seen) VALUES(v_actor,now())
      ON CONFLICT(user_id) DO UPDATE SET last_seen=now();
  ELSE
    DELETE FROM public.messenger_presence p WHERE p.user_id=v_actor;
  END IF;
  RETURN QUERY SELECT p.user_id,p.last_seen FROM public.messenger_presence p WHERE p.user_id=v_actor;
END; $fn$;

CREATE OR REPLACE FUNCTION public.my_presence_state(hasura_session json)
RETURNS TABLE(is_online boolean,last_seen timestamptz) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  RETURN QUERY SELECT coalesce(p.last_seen > now()-interval '45 seconds',false),p.last_seen FROM (SELECT 1) x LEFT JOIN public.messenger_presence p ON p.user_id=v_actor;
END; $fn$;

CREATE OR REPLACE FUNCTION public.my_friends_presence(hasura_session json)
RETURNS TABLE(user_id uuid,is_online boolean,last_seen timestamptz) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog,public,auth AS $fn$
DECLARE v_actor uuid;
BEGIN
  IF hasura_session->>'x-hasura-role' <> 'user' OR coalesce(hasura_session->>'x-hasura-user-id','') !~* '^[0-9a-f-]{36}$' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  v_actor := (hasura_session->>'x-hasura-user-id')::uuid;
  RETURN QUERY SELECT f.user_id,coalesce(p.last_seen>now()-interval '45 seconds',false),p.last_seen
  FROM public.messenger_friend_requests r
  CROSS JOIN LATERAL (SELECT CASE WHEN r.requester_id=v_actor THEN r.recipient_id ELSE r.requester_id END AS user_id) f
  LEFT JOIN public.messenger_presence p ON p.user_id=f.user_id
  WHERE r.status='accepted' AND (r.requester_id=v_actor OR r.recipient_id=v_actor)
  ORDER BY coalesce(p.last_seen>now()-interval '45 seconds',false) DESC;
END; $fn$;

REVOKE ALL ON FUNCTION public.set_my_presence(boolean,json),public.my_presence_state(json),public.my_friends_presence(json) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.set_my_presence(boolean,json),public.my_presence_state(json),public.my_friends_presence(json) TO PUBLIC;
-- Track messenger_presence and all three functions in Hasura; mark hasura_session as session argument.
-- Grant function execute to authenticated role user only. No direct table access or anonymous execute.
-- No tracking of public profile or room membership outside these functions.
