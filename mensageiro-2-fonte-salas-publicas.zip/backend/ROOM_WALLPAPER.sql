-- Shared per-room chat wallpaper metadata/content for the Mensageiro Nhost project.
-- No files are stored on the server bucket: a compressed JPEG data URI is stored in this table.
-- Hasura permissions are mandatory before the client feature can work. See ROOM_WALLPAPER.md.
CREATE TABLE IF NOT EXISTS public.room_wallpapers (
  room_id uuid PRIMARY KEY REFERENCES public.rooms(id) ON DELETE CASCADE,
  wallpaper_data text NOT NULL,
  updated_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT room_wallpapers_data_size CHECK (octet_length(wallpaper_data) <= 550000),
  CONSTRAINT room_wallpapers_data_type CHECK (wallpaper_data LIKE 'data:image/jpeg;base64,%')
);
CREATE INDEX IF NOT EXISTS room_wallpapers_updated_at_idx ON public.room_wallpapers(updated_at);

CREATE OR REPLACE FUNCTION public.set_room_wallpaper_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$fn$;

DROP TRIGGER IF EXISTS room_wallpapers_set_updated_at ON public.room_wallpapers;
CREATE TRIGGER room_wallpapers_set_updated_at
BEFORE UPDATE ON public.room_wallpapers
FOR EACH ROW EXECUTE FUNCTION public.set_room_wallpaper_updated_at();
