import { createCipheriv, createDecipheriv, randomBytes, timingSafeEqual } from 'node:crypto';

const HOST = 'ntfy.sh';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const b64u = b => Buffer.from(b).toString('base64url');
const fromB64u = s => Buffer.from(s, 'base64url');
export function endpointUrl(input) {
  if (typeof input !== 'string' || input.length > 240) throw Error('endpoint');
  const u = new URL(input);
  if (u.protocol !== 'https:' || u.hostname !== HOST || u.port || u.username || u.password || u.search || u.hash || !/^\/[A-Za-z0-9_-]{16,128}$/.test(u.pathname)) throw Error('endpoint');
  return u;
}

export function acceptedRecipientIds(room, members, senderId) {
  if (!room || room.room_type !== 'private') return [];
  return [...new Set([room.created_by, ...(members || []).filter(x => x.accepted_at != null).map(x => x.user_id)].filter(x => x && x !== senderId))];
}

// Dependency-injected event processor: deterministic tests use an in-memory fake store.
export async function processMessageEvent({ eventId, message, room, members, subscriptions, store, deliver }) {
  if (!eventId || !message?.id || !message?.room_id || !message?.sender_id) throw Error('invalid event');
  if (!(await store.claimEvent(eventId))) return 'duplicate';
  try {
    const recipients = acceptedRecipientIds(room, members, message.sender_id);
    if (!recipients.length) { await store.releaseEvent(eventId); return 'ignored'; }
    for (const sub of subscriptions || []) {
      if (!recipients.includes(sub.user_id)) continue;
      if (!(await store.claimDelivery(eventId, sub.user_id, sub.device_id))) continue;
      let ok = false;
      try { await deliver(sub); ok = true; }
      finally { await store.finishDelivery(eventId, sub.user_id, sub.device_id, ok); }
    }
    return 'ok';
  } catch (e) { await store.releaseEvent(eventId).catch(()=>{}); throw e; }
}

function key() {
  const k = Buffer.from(process.env.PUSH_ENDPOINT_ENCRYPTION_KEY || '', 'base64');
  if (k.length !== 32) throw Error('server config');
  return k;
}
function seal(value, aad) {
  const iv = randomBytes(12), c = createCipheriv('aes-256-gcm', key(), iv);
  c.setAAD(Buffer.from(aad));
  const ciphertext = Buffer.concat([c.update(value, 'utf8'), c.final()]);
  return `v1.${b64u(iv)}.${b64u(c.getAuthTag())}.${b64u(ciphertext)}`;
}
function open(value, aad) {
  const [v, iv, tag, data, extra] = String(value).split('.');
  if (v !== 'v1' || !iv || !tag || !data || extra) throw Error('ciphertext');
  const d = createDecipheriv('aes-256-gcm', key(), fromB64u(iv));
  d.setAAD(Buffer.from(aad)); d.setAuthTag(fromB64u(tag));
  return Buffer.concat([d.update(fromB64u(data)), d.final()]).toString('utf8');
}
async function graph(query, variables, token) {
  const headers = { 'content-type': 'application/json' };
  if (token) headers.authorization = `Bearer ${token}`;
  else headers['x-hasura-admin-secret'] = process.env.NHOST_ADMIN_SECRET;
  const r = await fetch(process.env.NHOST_GRAPHQL_URL, { method: 'POST', headers, body: JSON.stringify({ query, variables }), signal: AbortSignal.timeout(8000) });
  const j = await r.json();
  if (!r.ok || j.errors?.length) throw Error('backend');
  return j.data;
}
export function tokenFrom(req) {
  const h = req.headers.authorization || '';
  if (!/^Bearer [A-Za-z0-9._-]{30,4096}$/.test(h)) return null;
  return h.slice(7);
}
function eqSecret(a, b) {
  if (!a || !b) return false;
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}
async function postNtfy(url) {
  const u = endpointUrl(url);
  const r = await fetch(u, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Title': 'Mensageiro', 'Priority': 'default' }, body: 'Você tem uma nova mensagem.', signal: AbortSignal.timeout(5000) });
  if (r.status >= 300 && r.status < 400) throw Error('redirect');
  if (!r.ok) throw Error('delivery');
}
const ADMIN = `mutation($id:String!){claim_push_event(args:{p_event_id:$id})}`;
const RELEASE = `mutation($id:String!){release_push_event(args:{p_event_id:$id})}`;
const CLAIM_D = `mutation($e:String!,$u:uuid!,$d:uuid!){claim_push_delivery(args:{p_event_id:$e,p_user_id:$u,p_device_id:$d})}`;
const FINISH_D = `mutation($e:String!,$u:uuid!,$d:uuid!,$ok:Boolean!){finish_push_delivery(args:{p_event_id:$e,p_user_id:$u,p_device_id:$d,p_success:$ok})}`;
export async function handler(req, res, forcedRoute = null) {
  res.set('Cache-Control', 'no-store');
  try {
    if (req.method !== 'POST') return res.status(405).send('method');
    const route = forcedRoute || req.path;
    if (route === 'register' || route === 'unregister') {
      const token = tokenFrom(req);
      const device = req.body?.device_id;
      if (!token || typeof device !== 'string' || !UUID.test(device)) return res.status(400).send('invalid request');
      if (route === 'register') {
        const url = endpointUrl(req.body.endpoint).toString();
        const ciphertext = seal(url, device);
        await graph('mutation($d:uuid!,$c:String!){register_push_endpoint(args:{p_device_id:$d,p_ciphertext:$c})}', { d: device, c: ciphertext }, token);
      } else {
        await graph('mutation($d:uuid!){unregister_push_endpoint(args:{p_device_id:$d})}', { d: device }, token);
      }
      return res.status(204).send('');
    }
    if (route !== 'events') return res.status(404).send('not found');
    if (!eqSecret(req.headers['x-hasura-event-secret'], process.env.PUSH_EVENT_SECRET)) return res.status(401).send('unauthorized');
    const e = req.body?.event, eventId = req.body?.id;
    const m = e?.data?.new;
    if (e?.op !== 'INSERT' || !m || !UUID.test(m.id || '') || !UUID.test(m.room_id || '') || !UUID.test(m.sender_id || '') || typeof eventId !== 'string' || eventId.length > 200) return res.status(400).send('invalid event');
    const roomData = await graph(`query($id:uuid!){rooms(where:{id:{_eq:$id}}){id room_type created_by} room_members(where:{room_id:{_eq:$id},accepted_at:{_is_null:false}}){user_id}}`, { id: m.room_id });
    const room = roomData.rooms?.[0];
    const users = acceptedRecipientIds(room, roomData.room_members, m.sender_id);
    const q = users.length ? await graph(`query($ids:[uuid!]!){push_subscriptions(where:{user_id:{_in:$ids}}){user_id device_id endpoint_ciphertext}}`, { ids: users }) : { push_subscriptions: [] };
    try {
      const result = await processMessageEvent({eventId, message:m, room, members:roomData.room_members, subscriptions:q.push_subscriptions,
        store: {
          claimEvent: async id => !!(await graph(ADMIN,{id})).claim_push_event,
          releaseEvent: async id => graph(RELEASE,{id}),
          claimDelivery: async (e,u,d) => !!(await graph(CLAIM_D,{e,u,d})).claim_push_delivery,
          finishDelivery: async (e,u,d,ok) => graph(FINISH_D,{e,u,d,ok})
        },
        deliver: async sub => { const url=open(sub.endpoint_ciphertext,sub.device_id); endpointUrl(url); await postNtfy(url); }
      });
      return res.status(200).send(result);
    } catch (_) { return res.status(500).send('retry'); }
  } catch (_) { return res.status(400).send('request failed'); }
}
// No request body, JWT, event payload, endpoint, ciphertext or downstream response is logged.

export default handler;
