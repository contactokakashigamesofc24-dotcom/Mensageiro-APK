import { handler } from './index.js';
export default async function events(req, res) { return handler(req, res, 'events'); }
