import { handler } from './index.js';
export default async function unregister(req, res) { return handler(req, res, 'unregister'); }
