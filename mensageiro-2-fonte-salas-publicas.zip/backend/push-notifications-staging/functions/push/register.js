import { handler } from './index.js';
export default async function register(req, res) { return handler(req, res, 'register'); }
