import test from 'node:test';
import assert from 'node:assert/strict';
import { endpointUrl, acceptedRecipientIds, processMessageEvent, tokenFrom } from '../functions/push/index.js';

test('endpoint allowlist only accepts HTTPS ntfy.sh opaque topic, blocks SSRF variants', () => {
  assert.equal(endpointUrl('https://ntfy.sh/a_very_long_private_topic_123456').hostname,'ntfy.sh');
  for (const x of [
    'http://ntfy.sh/a_very_long_private_topic_123456',
    'https://ntfy.sh.evil.test/a_very_long_private_topic_123456',
    'https://ntfy.sh@127.0.0.1/a_very_long_private_topic_123456',
    'https://127.0.0.1/a_very_long_private_topic_123456',
    'https://ntfy.sh:443/a_very_long_private_topic_123456',
    'https://ntfy.sh/a_very_long_private_topic_123456?x=1',
    'https://ntfy.sh/a_very_long_private_topic_123456#x',
    'https://ntfy.sh/short'
  ]) assert.throws(() => endpointUrl(x), undefined, x);
});

test('only private owner and accepted members receive; sender, pending, public and strangers excluded', () => {
  const owner='owner', accepted='accepted', sender='sender', pending='pending', stranger='stranger';
  assert.deepEqual(acceptedRecipientIds({room_type:'private',created_by:owner},[{user_id:accepted,accepted_at:'2026-01-01T00:00:00Z'},{user_id:pending,accepted_at:null}],sender),[owner,accepted]);
});

test('public room never gets push',()=>assert.deepEqual(acceptedRecipientIds({room_type:'public',created_by:'o'},[{user_id:'m',accepted_at:'now'}],'s'),[]));

test('duplicate event is idempotent; delivery failure releases its claim for retry', async()=>{
 const events=new Set(), deliveries=new Set(), sent=[];
 const store={claimEvent:async e=>{if(events.has(e))return false;events.add(e);return true},releaseEvent:async e=>events.delete(e),claimDelivery:async(e,u,d)=>{let k=[e,u,d].join(':');if(deliveries.has(k))return false;deliveries.add(k);return true},finishDelivery:async(e,u,d,ok)=>{if(!ok)deliveries.delete([e,u,d].join(':'))}};
 const args={eventId:'evt-1',message:{id:'m1',room_id:'r1',sender_id:'s'},room:{room_type:'private',created_by:'owner'},members:[{user_id:'member',accepted_at:'yes'},{user_id:'pending',accepted_at:null}],subscriptions:[{user_id:'owner',device_id:'d1'},{user_id:'member',device_id:'d2'},{user_id:'pending',device_id:'d3'},{user_id:'s',device_id:'d4'}],store,deliver:async sub=>sent.push(sub.user_id)};
 assert.equal(await processMessageEvent(args),'ok'); assert.deepEqual(sent,['owner','member']);
 assert.equal(await processMessageEvent(args),'duplicate'); assert.deepEqual(sent,['owner','member']);
});

test('unauthenticated registration is rejected before any database call',()=>{
 assert.equal(tokenFrom({headers:{}}),null); assert.equal(tokenFrom({headers:{authorization:'Bearer short'}}),null); assert.equal(tokenFrom({headers:{authorization:'Bearer '+'x'.repeat(40)}}),'x'.repeat(40));
});
