# Mensageiro / Nhost security checkpoint — 2026-11-02

**Staging only. No production settings, policies, functions, SQL, Auth accounts, or deployments were changed.** This is an audit note and a review plan, not executable migration instructions.

## Auth account check (read-only)

The Nhost Auth users screen lists Luiz Fernando and Eloir Anderson Arndt, and a read-only SQL Console query confirmed the two requested Auth UUIDs:

- Luiz Fernando (`contacto.kakashigamesofc24@gmail.com`): `27a5eca4-18d2-4a67-9a34-3e075317740b`
- Eloir Anderson Arndt (`eloirandersonarndt@gmail.com`): `ce0434ff-7520-4fb9-8703-78b9cf420f2e`

So Eloir already has an Auth account; he does not need to register to obtain an ID. The Auth screen also lists a third account, outside the two intended people. No details or changes to that account are included here. Confirm whether it is an authorized test account before enabling access.

These IDs are an **allowlist proposal only**. No live authorization currently uses this list. Do not assume that presence in Auth means the database restricts all app access to these accounts.

## Live checks and security status

- Nhost project `fapcygtcubeukddoieus` is shown as **No deployments**; automatic deployment was previously verified off. Functions dashboard previously showed none deployed.
- Read-only GraphQL/console observation confirmed `public.room_members` currently has no rows. Messages has rows, so private membership-based access is not presently demonstrated.
- Previously inspected live Hasura `messages / role user / Select` permission has filter: room is public **or** room creator equals `X-Hasura-User-Id`. It does **not** include accepted `room_members`. Therefore accepted private-room members are denied message selection by that filter, while public-room messages are allowed. This is an access/availability defect, not proof that all other permissions are safe.
- The dashboard metadata export reported “Metadata exported successfully”, but the downloaded JSON was not available for review here. Other permissions for `messages`, `rooms`, and `room_members` (including insert/update/delete, anonymous role, and all room-member management paths) remain **unverified**. Do not treat the rest as audited.
- The GraphQL playground was run under the dashboard, not under user A/B/C credentials; its returned rows do not prove user-role isolation.

## Proposed safe allowlist design (not applied)

Use the two UUIDs above as approved identities only after an explicit review of the full exported Hasura metadata and Auth account inventory. Deny all other authenticated users by default. Prefer an explicit database-backed allowlist relation/claim enforced consistently in every relevant role permission; do not rely on app UI hiding features, email text sent by a client, or a function's unverified JWT decoding. Maintain access for existing intended users only; do not automatically invite/create accounts. If any account is removed/recreated, re-verify its new Auth UUID before updating the allowlist.

Before applying any change, export and retain a backup of metadata; produce a reversible, narrowly scoped diff that covers all CRUD operations and relationships. Test anonymous, allowlisted owner, allowlisted accepted member, pending invitee, and non-allowlisted user, including public and private rooms. Confirm room creation and membership acceptance still work for the two intended accounts. Review rollback before applying. No SQL or metadata patch is supplied as an executable deployment because the complete live schema/permissions and tested policy expressions are not yet available.

## Review of staged UnifiedPush implementation

- Existing code is a backend-only staging proposal; the APK/app still does not call registration routes or implement the UnifiedPush callback. No push will be delivered by this package as-is.
- Push code does not implement a general two-user application allowlist. The SQL registration functions trust the Hasura `hasura_session` argument as a session identity but the exact Nhost tracking/session-argument configuration and behavior are unverified. Thus it is not safe to claim that arbitrary valid `user` tokens cannot register endpoints.
- `room_members.accepted_at` and the `rooms` fields used by the event handler must be checked against the live schema before deployment. Event-handler delivery path and GraphQL function names also need an integration test against Nhost.
- `README.md` previously said a shared `_push.js` file would be deployed; there is no `_push.js` in the staged files, so that wording has been corrected. Route mapping/prefix still needs verification in Nhost before publishing.
- Existing unit tests are source files only. They were **not run** because Node.js is unavailable in this environment. There was no runtime, Nhost integration, Android, or two-account test.

## Next safe step

Download/review the current metadata export and inspect each role/action for all three public tables; inspect Auth configuration and clarify the third account. Then create and review a reversible metadata-only patch plus a two-user test matrix. Keep production untouched until that review passes. No Firebase, paid upgrade, deployment, account creation, invitation, or APK build is needed for this review.
