-- Staging-only proposal. Do not execute until Hasura permissions + private-room model are audited.
-- No client role receives direct table CRUD. Track only the SECURITY DEFINER functions below.
CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  user_id uuid NOT NULL,
  device_id uuid NOT NULL,
  endpoint_ciphertext text NOT NULL CHECK (length(endpoint_ciphertext) BETWEEN 40 AND 4096),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, device_id)
);
CREATE TABLE IF NOT EXISTS public.push_event_claims (
  event_id text PRIMARY KEY,
  claimed_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.push_delivery_claims (
  event_id text NOT NULL,
  user_id uuid NOT NULL,
  device_id uuid NOT NULL,
  sent_at timestamptz,
  PRIMARY KEY (event_id, user_id, device_id)
);

CREATE OR REPLACE FUNCTION public.register_push_endpoint(p_device_id uuid, p_ciphertext text, hasura_session json)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
DECLARE actor uuid;
BEGIN
  actor := NULLIF(hasura_session->>'x-hasura-user-id','')::uuid;
  IF actor IS NULL OR length(p_ciphertext) < 40 OR length(p_ciphertext) > 4096 THEN RAISE EXCEPTION 'Invalid registration'; END IF;
  INSERT INTO public.push_subscriptions(user_id,device_id,endpoint_ciphertext)
  VALUES(actor,p_device_id,p_ciphertext)
  ON CONFLICT(user_id,device_id) DO UPDATE SET endpoint_ciphertext=EXCLUDED.endpoint_ciphertext,updated_at=now();
  RETURN true;
END $$;
CREATE OR REPLACE FUNCTION public.unregister_push_endpoint(p_device_id uuid, hasura_session json)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
DECLARE actor uuid;
BEGIN
  actor := NULLIF(hasura_session->>'x-hasura-user-id','')::uuid;
  IF actor IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  DELETE FROM public.push_subscriptions WHERE user_id=actor AND device_id=p_device_id;
  RETURN true;
END $$;

-- The event handler calls these only with the Nhost server admin credential (never from an app).
CREATE OR REPLACE FUNCTION public.claim_push_event(p_event_id text)
RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
  WITH i AS (INSERT INTO public.push_event_claims(event_id) VALUES(p_event_id) ON CONFLICT DO NOTHING RETURNING 1)
  SELECT EXISTS(SELECT 1 FROM i)
$$;
CREATE OR REPLACE FUNCTION public.release_push_event(p_event_id text)
RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
  WITH d AS (DELETE FROM public.push_event_claims WHERE event_id=p_event_id RETURNING 1) SELECT EXISTS(SELECT 1 FROM d)
$$;
CREATE OR REPLACE FUNCTION public.claim_push_delivery(p_event_id text,p_user_id uuid,p_device_id uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
  WITH i AS (INSERT INTO public.push_delivery_claims(event_id,user_id,device_id) VALUES(p_event_id,p_user_id,p_device_id) ON CONFLICT DO NOTHING RETURNING 1)
  SELECT EXISTS(SELECT 1 FROM i)
$$;
CREATE OR REPLACE FUNCTION public.finish_push_delivery(p_event_id text,p_user_id uuid,p_device_id uuid,p_success boolean)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
BEGIN
 IF p_success THEN UPDATE public.push_delivery_claims SET sent_at=now() WHERE event_id=p_event_id AND user_id=p_user_id AND device_id=p_device_id;
 ELSE DELETE FROM public.push_delivery_claims WHERE event_id=p_event_id AND user_id=p_user_id AND device_id=p_device_id AND sent_at IS NULL; END IF;
 RETURN true;
END $$;

REVOKE ALL ON public.push_subscriptions, public.push_event_claims, public.push_delivery_claims FROM PUBLIC;
REVOKE ALL ON FUNCTION public.register_push_endpoint(uuid,text,json), public.unregister_push_endpoint(uuid,json), public.claim_push_event(text), public.release_push_event(text), public.claim_push_delivery(text,uuid,uuid), public.finish_push_delivery(text,uuid,uuid,boolean) FROM PUBLIC;
-- Grant EXECUTE only after tracking functions in Hasura: register/unregister to role user only;
-- claim/release/delivery functions to admin server calls only. Never allow role user/anonymous on claims.
