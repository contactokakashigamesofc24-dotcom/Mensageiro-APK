# Bloqueio de desconhecidos e controle global

Em Configurações, a conta administradora usa os botões **Ativar para todos** e **Desativar para todos**. Desativar faz o servidor rejeitar novas mensagens; áudio e foto/vídeo também são barrados, inclusive se o envio já começou. Ativar permite envio apenas em salas privadas e grupos para o criador/membro aceito. Salas públicas antigas ficam visíveis somente para leitura. O histórico não é apagado.

## Antes de aplicar

Confirme que o UUID allowlist `27a5eca4-18d2-4a67-9a34-3e075317740b` é mesmo a conta administradora do Mensageiro. É o identificador de Luiz verificado no projeto; não é segredo. Não coloque credencial administrativa no APK.

Faça backup do Nhost dedicado `fapcygtcubeukddoieus`, depois aplique os SQL nessa ordem:

1. `MESSENGER_GLOBAL_SWITCH.sql` — cria settings e funções de leitura/criação de sala privada, triggers que negam postagem pública, pausa global e inserção de remetente não autenticado.
2. `PROFILES_FRIENDS.sql` — perfis e amizades. Requer a tabela `messenger_friend_requests` antes de criar grupos.
3. `PRIVATE_ROOM_INVITES.sql` — convites privados e função `my_owned_private_rooms`, usada para listar suas próprias salas privadas.
4. `MESSENGER_GROUPS.sql` — grupos privados; exige funções/tabelas de amizades configuradas.
5. `ROOM_AUDIO.sql` e `ROOM_MEDIA.sql` — anexos privados; instalam triggers para pausar/rejeitar uploads.

Rastreie apenas as funções públicas chamadas pelo app, com `hasura_session` injetado pelo Hasura, role autenticada `user`, sem anônimo. Não rastreie funções de trigger nem `messenger_user_can_access_private_room`. Não exponha tabela de settings, grupos ou chunks. Permissões Hasura `rooms`/`messages` devem seguir `HASURA_PERMISSIONS.md` e `MESSENGER_GROUPS.md`; negue insert direto em salas, writes em salas públicas, updates e acesso pending/terceiros. Não use permissões admin para testar.

## Validação obrigatória

Com tokens normais: criador e membro que aceitou convite conseguem ver/enviar em sua sala/grupo; pendente, terceiro e anônimo não leem histórico nem enviam, mesmo sabendo UUID. Salas públicas legadas permanecem somente leitura. Desativado bloqueia texto, criação de mensagem de áudio/mídia e chunks; ativado libera só salas privadas autorizadas. Conta diferente da allowlist não pode mudar a flag. Teste foto, vídeo e áudio entre dois aparelhos. O código não comprova que permissões do servidor estejam aplicadas: mantenha fechado até passar esses testes.
