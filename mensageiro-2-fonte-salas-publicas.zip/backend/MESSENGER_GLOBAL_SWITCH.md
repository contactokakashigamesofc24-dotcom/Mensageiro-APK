# Controle global Ativar/Desativar

Em Configurações há dois botões separados: **Ativar para todos** e **Desativar para todos**. O estado é lido do servidor. Quando desativado, um trigger no banco rejeita a inserção de qualquer nova linha em `messages`, então bloqueia envio por qualquer conta (inclusive os metadados de áudio/foto/vídeo, que criam a mensagem antes do upload). Quando reativado, novas mensagens voltam a ser aceitas. Histórico permanece; o controle não apaga mensagens, não impede leitura das antigas e não bloqueia criação/aceite de convites.

Apenas a conta Nhost de Luiz com UUID `27a5eca4-18d2-4a67-9a34-3e075317740b` pode mudar o estado. O app esconde os controles de outras contas, mas a garantia de segurança vem da checagem server-side. Não inclua segredo administrativo no APK.

## Configuração e testes necessários

1. Faça backup do projeto Nhost Mensageiro (`fapcygtcubeukddoieus`) e execute `MESSENGER_GLOBAL_SWITCH.sql`.
2. Rastreie apenas `messenger_global_status` (consulta) e `set_messenger_global_enabled` (mutação) no Hasura. Marque `hasura_session` como argumento injetado de sessão; permita execução à role autenticada `user` somente, sem acesso anônimo. Não rastreie/exponha a tabela de configuração nem conceda acesso direto à tabela.
3. Garanta que nenhum role cliente possa desativar/remover o trigger, gravar diretamente a tabela ou usar acesso administrativo.
4. Compile/instale o APK. Como Luiz, confira o estado, desative e teste envio de texto, áudio, foto/vídeo: todos devem ser rejeitados pelo servidor. Em outra conta, confirme a mesma rejeição. Tente chamar a mutação como outra conta e confirme que recebe `Not authorized`. Reative e confirme que ambas conseguem enviar de novo. O UUID do Luiz na autenticação precisa coincidir com a allowlist definida no SQL; se não coincidir, pare e revise de modo controlado antes de alterar a allowlist.

Até aplicar SQL, rastrear/configurar permissões e fazer os testes com tokens comuns, os botões estão apenas preparados no código, sem efeito global confirmado. O endpoint para ler pode mostrar estado somente a usuários autenticados, mas apenas Luiz consegue mudar.
