# Nhost Hasura permissions — first safe chat phase

After running `MENSAGEIRO_SCHEMA.sql`, track `public.rooms` and `public.messages` in Hasura. Add the FK relationship from messages.room_id to rooms.id if the console does not create it automatically (name relationship `room`). Add role `user` permissions before app testing. Hasura default is deny; never add admin secret to APK.

## `rooms`, role `user`
- **select** row filter: OR of (room_type `_eq` `public`) and (created_by `_eq` `X-Hasura-User-Id`). Columns: id, title, room_type, created_by, created_at.
- **insert** allowed columns: title, room_type only. Preset `created_by` to session `X-Hasura-User-Id`. Check: room_type is one of public/private. Do not let client choose created_by.
- update/delete: deny for first phase.

## `messages`, role `user`
- **select** row filter through relationship `room`: room.room_type is `public` OR room.created_by equals `X-Hasura-User-Id`. Columns: id, room_id, sender_id, body, created_at.
- **insert** allowed columns: room_id, body only. Preset `sender_id` to session `X-Hasura-User-Id`. Check sender preset and room relationship permission: referenced room is public OR created_by equals `X-Hasura-User-Id`. Do not allow client to choose sender_id.
- **update**: deny.
- **delete**: Required for “Apagar para todos”: configure a partial delete permission with BOTH row filters: `sender_id` `_eq` `X-Hasura-User-Id` AND relationship `room.room_type` `_eq` `public`. Do not omit the public-room condition. Never rely only on the Android filter. Test with two real non-admin accounts: author can delete their own public message; another user cannot delete it by ID; nobody can delete private-room messages with this app permission. Until this permission is configured and live-tested, the server will reject “Apagar para todos” safely.

If the Hasura UI cannot express an exact relationship filter/preset as above, STOP and do not enable that table; use a server-side function/action instead. Do not substitute a broader rule. Check that the `user` role has no inherited broad permission.

For this permission to work, the Hasura relationship from `messages.room_id` to `rooms.id` must be named `room`, as specified above. If the UI cannot enforce both predicates, leave delete disabled.

## What this phase does/doesn't do
- Public rooms and their messages are visible to authenticated users.
- Private rooms and messages are visible only to their creator.
- Private invitation/acceptance is NOT included; never claim a second user can enter a private room yet.
- Chat app polls GraphQL every 4 seconds while a room is open. No push notification when app is closed.

## Security gate before production
Test with two real non-admin accounts A and B and an anonymous request:
1. B can read/write public room; A and B see same messages on separate phones.
2. B cannot read A's private room or messages (including direct GraphQL query by known room ID).
3. B cannot spoof sender_id or created_by; GraphQL rejects attempts because columns are not client-writable and server presets are used.
4. Anonymous users cannot read or write any room/message.
5. Errors never reveal private titles/content. Test actual non-admin user JWT, not the admin console.

Do not enable invites until an atomic server-side invite+accept workflow with authorization checks has been built and tested.
