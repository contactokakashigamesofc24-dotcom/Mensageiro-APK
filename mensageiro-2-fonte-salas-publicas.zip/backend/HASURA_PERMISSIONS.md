# Hasura/Nhost permissions — chat privado, sem postagem pública

As funções SQL preparadas neste projeto são default-deny. Faça backup, aplique os scripts requeridos, rastreie funções e configure role autenticada `user`; jamais exponha admin secret.

## Salas
- `rooms` não deve ter insert/update/delete direto pelo cliente. Criação de sala privada só pela função `create_private_messenger_room` ou função segura de grupo.
- `messenger_global_settings`, `messenger_groups`, `room_members`, e tabelas de áudio/mídia/chunks sem CRUD direto para client roles.
- Funções SECURITY DEFINER com parâmetro `hasura_session` precisam da sessão injetada pela Hasura; executar só como `user`, nunca `public/anonymous`.
- Salas públicas antigas podem continuar legíveis (título/histórico conforme política), mas não podem aceitar nova mensagem. `MESSENGER_GLOBAL_SWITCH.sql` cria `readable_public_rooms` e leitura privada somente por dono/membro aceito nas funções correspondentes.

## Mensagens
- `messages` select privado: somente criador de sala privada ou relação `room_members` com `user_id = X-Hasura-User-Id` e `accepted_at IS NOT NULL`. Membros pendentes e terceiros não podem ler. Salas públicas: leitura histórica, se desejada, sem escrita.
- `messages` insert: habilitar apenas se relação sala é privada E (owner atual OU `room_members` do usuário atual com `accepted_at` não nulo). Colunas graváveis somente `room_id,body`; `sender_id` preset obrigatório para `X-Hasura-User-Id`, nunca escolhido pelo app. Sem update/delete para conversas privadas.
- Trigger do `MESSENGER_GLOBAL_SWITCH.sql` é uma proteção adicional: bloqueia envio com flag global desligada, sala pública, remetente falsificado e sessão não autenticada.
- Não manter filtros antigos de sala pública nos inserts. Nenhuma permissão ampla para `user` ou `anonymous`.

## Teste de isolamento obrigatório
Com contas comuns A (criador), B (aceita convite), C (terceiro) e anônimo, tente via endpoints autorizados e UUID conhecido: A/B leem e escrevem; C, pendente e anônimo não leem nem escrevem. Salas públicas rejeitam qualquer insert. Tente forjar sender_id e alterar diretamente settings/members; servidor deve negar. Enquanto controles desligados, texto e começo/continuação de áudio/mídia devem falhar. Ative e reteste. Só liberar após validar tudo com JWTs não administrativos e dois aparelhos.
