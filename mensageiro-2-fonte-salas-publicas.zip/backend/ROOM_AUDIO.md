# Áudios sem limite de duração nas salas públicas

O app permite gravar sem limite de tempo definido pelo mensageiro. Ao tocar no microfone, grava; ao tocar novamente, para e começa o envio. Arquivos grandes são divididos em partes pequenas para envio e reprodução em fluxo por segmentos. O limite real é o espaço livre do telefone, a conexão, os limites de serviço/conta e o espaço disponível no Nhost — não duração configurada no app. Se acabar o armazenamento ou a conexão falhar durante envio, a operação não termina com sucesso; faça novo teste e evite sair do app durante upload.

## Configuração (Nhost Mensageiro)

1. Faça backup do projeto Mensageiro. Se a versão anterior do `ROOM_AUDIO.sql` já foi aplicada, execute a versão atualizada: ela cria tabelas novas `message_audio_files` e `message_audio_chunks` e funções com envio/recepção em pedaços. Ela não altera/remova as tabelas de texto.
2. Rastreie as duas tabelas no Hasura, mas **não** conceda acesso CRUD direto às roles `user` ou `public`.
3. Rastreie as cinco funções `create_public_room_audio`, `add_public_room_audio_chunk`, `complete_public_room_audio`, `room_audio_message_ids`, `get_public_room_audio_chunks`; marque `hasura_session` como argumento de sessão injetado.
4. Conceda execução somente à role autenticada `user`, não a anonymous. Não coloque segredo de administrador no APK.
5. Teste com duas contas reais em sala pública: enviar áudio curto e longo, outro aparelho carregar e ouvir todas as partes completas. Interrompa rede no upload e confirme que mensagem incompleta não aparece como áudio reproduzível.

A duração não tem teto no app, mas não significa armazenamento ilimitado: Nhost e aparelho têm cotas/espaço finitos. Áudio fica guardado no backend até exclusão da mensagem; sem criptografia ponta a ponta. Não envie gravações que não quer compartilhar.
