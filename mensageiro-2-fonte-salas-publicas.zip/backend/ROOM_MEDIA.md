# Emojis, fotos e vídeos no chat público

O seletor de carinhas adiciona emoji ao texto. Na conversa pública, o botão de câmera abre o app de câmera do Android com opções para tirar uma foto ou gravar um vídeo. A mídia é enviada em partes ao backend e aparece como foto ou vídeo reproduzível no chat.

## Ativação no Nhost

1. Faça backup do projeto Nhost Mensageiro e execute `ROOM_MEDIA.sql`.
2. Rastreie as tabelas novas `message_media_files` e `message_media_chunks` no Hasura. Não conceda leitura/escrita direta para `user` ou `public`.
3. Rastreie e permita somente à role autenticada `user` executar estas funções; marque `hasura_session` como sessão injetada: `create_public_room_media`, `add_public_room_media_chunk`, `complete_public_room_media`, `public_room_media_message_ids`, `public_room_media_info`, `get_public_room_media_chunks`. A função de criação recebe MIME `image/jpeg` ou `video/mp4` para identificar a mídia desde o primeiro chunk.
4. Não permita acesso anônimo. O servidor cria a mensagem com a identidade da sessão e só aceita envio em sala pública. As consultas de mídia também verificam que a mensagem pertence a sala pública.
5. Teste entre duas contas: tirar foto, gravar vídeo, enviar e abrir/reproduzir no outro celular; interromper uma transmissão e confirmar que mídia incompleta não é exibida como completa.

O app aceita foto JPEG até 20 MB (a câmera tira JPEG comprimido) e vídeo MP4 até 150 MB; arquivos são enviados em blocos. Esses tetos protegem a memória/solicitação GraphQL, mas as cotas do serviço e o espaço do aparelho continuam sendo limites práticos. Foto/vídeo só estão habilitados em sala pública por enquanto. O vídeo usa o aplicativo de câmera disponível no Android; se não houver câmera compatível, o Android informará. Conteúdo não tem criptografia ponta a ponta e fica no backend.
