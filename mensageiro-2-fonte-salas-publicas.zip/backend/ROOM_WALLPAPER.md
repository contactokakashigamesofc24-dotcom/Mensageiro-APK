# Papel de parede compartilhado por sala

Esta funcionalidade envia uma cópia JPEG reduzida (máx. aproximado de 400 KB) para `public.room_wallpapers`, no Nhost do Mensageiro. A foto passa a ser compartilhada entre as contas que conseguem ler aquela sala; portanto deve-se escolher uma imagem adequada para compartilhar. A pessoa que troca o papel de parede o troca para toda a sala. O cliente recarrega o papel de parede periodicamente enquanto o chat está aberto.

## Antes de usar

1. Aplicar `ROOM_WALLPAPER.sql` no projeto Nhost do Mensageiro (`fapcygtcubeukddoieus`) sem alterar/remover tabelas existentes.
2. Rastrear `public.room_wallpapers` no Hasura.
3. Criar o relacionamento objeto `room` de `room_wallpapers.room_id` para `rooms.id`.
4. Para o role autenticado `user`, configurar **select** com `room_id, wallpaper_data, updated_at` e filtro via relacionamento `room`: sala pública OR sala privada criada por `X-Hasura-User-Id` OR membro aceito verificado. Não exponha outros metadados de contas.
5. Configurar **insert** apenas para `room_id, wallpaper_data`; preset `updated_by` para `X-Hasura-User-Id`. O check do relacionamento `room` deve permitir sala pública, criador da sala ou membro com `accepted_at` não nulo. Convites pendentes nunca contam. Se o painel não permitir filtro exato, não habilite upload.
6. Configurar **update** apenas para `wallpaper_data`; bloquear edição de `room_id`, `updated_by` e `updated_at`. A row filter deve garantir o mesmo acesso válido via relacionamento `room`, e check deve preservar o escopo autorizado. O trigger `room_wallpapers_set_updated_at` no SQL define a data. Se não for possível configurar update de forma segura, deixe update negado; nesse caso o aplicativo não substituirá uma foto existente.
7. Não conceder insert/update/select anônimo; não habilitar delete necessário para o cliente; não colocar segredo administrativo no app.

A consulta GraphQL do aplicativo usa `room_wallpapers_by_pk` e a mutação usa `insert_room_wallpapers_one` para criar ou `update_room_wallpapers_by_pk` para trocar a imagem já existente. Confirme que o GraphQL gerado para a tabela expõe estes campos e que ambos respeitam as permissões de usuário configuradas. Faça teste com contas reais antes de liberar.

## Teste obrigatório em duas contas

- A e B podem ler a mesma sala pública e veem o mesmo papel de parede após atualizar.
- A escolhe uma foto: A e B veem a imagem; B troca: A e B veem a nova.
- Conta C não autenticada não pode ler nem alterar o papel de parede.
- Em sala privada, somente criador e membros aceitos podem ler/escrever; usuário externo e convite pendente não podem ler o conteúdo nem o wallpaper.
- A foto deve estar comprimida como JPEG e nenhum dado arbitrário ou HTML é aceito.

Até executar SQL, configurar permissões e passar os testes reais, o ícone e seletor podem compilar, mas a sincronização ainda não está pronta para uso. A busca de salas e o ícone do app permanecem incluídos.
