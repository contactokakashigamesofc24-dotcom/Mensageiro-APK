# Configurações — alteração preparada

Nesta versão do código foram acrescentados:
- exibição do e-mail da conta atual e ação para sair localmente (encerra a sessão em memória, limpa a lista local e desregistra o UnifiedPush deste aparelho; não revoga sessão no servidor porque não há endpoint de logout implementado);
- ajuste persistente do tamanho do texto entre 85% e 130%;
- atalho às configurações de notificação do Android (não cria push de mensagens);
- limpeza confirmada dos arquivos temporários/cache locais, sem apagar mensagens/arquivos do servidor;
- avisos explícitos de que status online/última vez, push real, Bot e controles de privacidade ainda dependem de backend seguro.

Não alterei o Nhost nem publiquei APK. Não compilado/testado ainda. Requer build Android antes de instalar.
