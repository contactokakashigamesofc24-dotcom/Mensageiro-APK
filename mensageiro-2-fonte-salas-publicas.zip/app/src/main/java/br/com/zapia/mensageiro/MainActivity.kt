package br.com.zapia.mensageiro

import android.os.Bundle
import android.net.Uri
import android.graphics.Bitmap
import androidx.core.content.FileProvider
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.Manifest
import android.widget.Toast
import org.unifiedpush.android.connector.UnifiedPush
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.VideoView
import android.widget.MediaController
import android.graphics.BitmapFactory
import android.content.Intent
import android.content.Context
import android.provider.Settings
import android.media.MediaRecorder
import android.media.MediaPlayer
import java.io.File
import java.io.RandomAccessFile
import java.io.FileOutputStream
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

private val Navy = Color(0xFF101329)
private val Panel = Color(0xFF202440)
private val Purple = Color(0xFF7667E8)
private val Mint = Color(0xFF47D7B5)

private enum class Screen { AUTH, ROOMS, CHAT, FRIENDS }
private enum class RecorderState { IDLE, RECORDING, SENDING }
internal enum class RoomKind(val label: String) { PUBLIC("Pública"), PRIVATE("Privada"), GROUP("Grupo") }
internal data class Room(val id: String, val title: String, val kind: RoomKind, val detail: String, val createdBy: String = "", val pendingInvite: Boolean = false)
internal data class ChatMessage(val id: String, val roomId: String, val author: String, val text: String, val time: String, val senderId: String = "", val avatarData: String? = null, val audioId: String? = null, val mediaType: String? = null)
internal data class FriendProfile(val userId: String, val displayName: String, val avatarData: String? = null, val requestId: String = "", val pendingIncoming: Boolean = false, val isFriend: Boolean = false, val online: Boolean = false)

class MainActivity : ComponentActivity() {
    fun checkPublicMessageCapability(token: String, onResult: (String) -> Unit) {
        lifecycleScope.launch {
            onResult("Consultando somente o esquema GraphQL, sem gravar dados…")
            try {
                val result = withContext(Dispatchers.IO) {
                    val connection = (URL("https://mensageiro-gemini-isolado.contacto-kakashigamesofc24.workers.dev/v1/capabilities").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 12000
                        readTimeout = 12000
                        doOutput = true
                        setRequestProperty("Authorization", "Bearer $token")
                        setRequestProperty("Accept", "application/json")
                    }
                    connection.outputStream.use { it.write("{}".toByteArray(Charsets.UTF_8)) }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val payload = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    connection.disconnect()
                    if (status != 200) "Não consegui verificar agora (HTTP $status). Nenhum dado foi gravado."
                    else {
                        val result = JSONObject(payload)
                        if (result.optString("schema_check") != "ok") "A checagem somente de leitura não ficou disponível. Nenhuma alteração foi feita."
                        else if (result.optBoolean("message_insert_exposed")) "A conta user vê uma mutação de inserção de mensagens. Isso não concede ao Worker permissão para responder; nenhuma gravação foi feita."
                        else "A conta user não vê mutação de inserção de mensagens. Nenhuma gravação foi feita."
                    }
                }
                onResult(result)
            } catch (_: Exception) {
                onResult("Falha na checagem somente de leitura. Nenhuma alteração foi feita.")
            }
        }
    }

    fun testIsolatedGemini(token: String, onResult: (String) -> Unit) {
        lifecycleScope.launch {
            onResult("Validando sessão e enviando pergunta de teste curta…")
            try {
                val result = withContext(Dispatchers.IO) {
                    val connection = (URL("https://mensageiro-gemini-isolado.contacto-kakashigamesofc24.workers.dev/v1/test").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 12000
                        readTimeout = 25000
                        doOutput = true
                        setRequestProperty("Authorization", "Bearer $token")
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Accept", "application/json")
                    }
                    val body = JSONObject().put("prompt", "Responda somente: TESTE ISOLADO OK").toString()
                    connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val payload = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    connection.disconnect()
                    if (status == 200) {
                        val answer = JSONObject(payload).optString("answer")
                        if (answer.isBlank()) "O Worker respondeu sem texto. Nenhuma mensagem da sala foi usada."
                        else "Resposta do Gemini: $answer. Teste isolado; banco e sala não foram acessados."
                    } else if (status == 401) "Sessão expirada ou inválida. Entre novamente no Mensageiro e tente de novo."
                    else if (status == 403) "Esta conta não está autorizada para o teste isolado."
                    else if (status == 429) "Limite temporário do Gemini atingido; tente mais tarde."
                    else "O teste isolado falhou (HTTP $status). Nenhuma mensagem da sala foi usada."
                }
                onResult(result)
            } catch (_: Exception) {
                onResult("Não consegui concluir o teste. Nenhuma mensagem da sala foi usada.")
            }
        }
    }

    fun authenticateWithNhost(
        signup: Boolean,
        name: String,
        email: String,
        password: String,
        onSuccess: (String, String, String, String) -> Unit,
        onMessage: (String) -> Unit
    ) {
        val baseUrl = "https://fapcygtcubeukddoieus.auth.sa-east-1.nhost.run/v1"
        if (!email.contains("@") || password.length < 6 || (signup && name.isBlank())) {
            onMessage("Confira o nome, o e-mail e a senha (mínimo de 6 caracteres).")
            return
        }
        lifecycleScope.launch {
            onMessage(if (signup) "Criando sua conta…" else "Entrando…")
            try {
                val result = withContext(Dispatchers.IO) {
                    val endpoint = if (signup) "$baseUrl/signup/email-password" else "$baseUrl/signin/email-password"
                    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 15000
                        readTimeout = 15000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Accept", "application/json")
                    }
                    val body = JSONObject().apply {
                        put("email", email.trim())
                        put("password", password)
                        if (signup) put("options", JSONObject().put("displayName", name.trim()).put("locale", "pt"))
                    }.toString()
                    connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    connection.disconnect()
                    val json = runCatching { JSONObject(responseText) }.getOrElse { JSONObject() }
                    if (status !in 200..299) {
                        val message = json.optString("message").ifBlank { json.optString("reason") }.ifBlank { json.optString("msg") }.ifBlank { json.optString("error_description") }.ifBlank { json.optString("error") }.ifBlank { "Falha na autenticação (HTTP $status)." }
                        throw IllegalStateException(message)
                    }
                    val session = json.optJSONObject("session")
                    val accessToken = session?.optString("accessToken").orEmpty()
                    val user = session?.optJSONObject("user") ?: json.optJSONObject("user")
                    val userId = user?.optString("id").orEmpty()
                    val returnedEmail = user?.optString("email").orEmpty().ifBlank { email.trim() }
                    val returnedName = user?.optString("displayName").orEmpty().ifBlank { name.trim().ifBlank { returnedEmail.substringBefore('@') } }
                    if (accessToken.isBlank()) {
                        if (signup) throw IllegalStateException("Se a confirmação de e-mail estiver ativa, confirme a mensagem recebida e depois entre.")
                        throw IllegalStateException("O servidor não devolveu uma sessão válida.")
                    }
                    // Access token kept only in Activity composition state; refresh/persistent secure session is still pending.
                    Triple(returnedName, returnedEmail, accessToken) to userId
                }
                onSuccess(result.first.first, result.first.second, result.first.third, result.second)
            } catch (e: Exception) {
                onMessage(e.message ?: "Não consegui concluir a autenticação.")
            }
        }
    }

    private val graphqlUrl = "https://fapcygtcubeukddoieus.graphql.sa-east-1.nhost.run/v1"
    private var mediaRecorder: MediaRecorder? = null
    private var currentRecordingFile: File? = null

    @Suppress("DEPRECATION")
    private fun createAudioRecorder(): MediaRecorder = if (android.os.Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    internal fun startAudioRecording(onResult: (String?) -> Unit) {
        if (mediaRecorder != null) { onResult("Já existe uma gravação em andamento."); return }
        try {
            runCatching { mediaRecorder?.release() }
            mediaRecorder = null
            currentRecordingFile?.delete()
            val file = File(cacheDir, "voice-${UUID.randomUUID()}.m4a")
            val recorder = createAudioRecorder()
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioEncodingBitRate(64000)
            recorder.setAudioSamplingRate(44100)
            recorder.setOutputFile(file.absolutePath)
            mediaRecorder = recorder
            currentRecordingFile = file
            recorder.prepare()
            recorder.start()
            onResult(null)
        } catch (e: Exception) {
            runCatching { mediaRecorder?.release() }
            mediaRecorder = null
            currentRecordingFile?.delete()
            currentRecordingFile = null
            onResult(e.message ?: "Não consegui iniciar a gravação.")
        }
    }

    internal fun cancelAudioRecording() {
        val recorder = mediaRecorder
        val file = currentRecordingFile
        mediaRecorder = null
        currentRecordingFile = null
        runCatching { recorder?.stop() }
        runCatching { recorder?.release() }
        file?.delete()
    }

    internal fun stopAudioRecording(onResult: (File?, String?) -> Unit) {
        val recorder = mediaRecorder
        val file = currentRecordingFile
        mediaRecorder = null
        currentRecordingFile = null
        if (recorder == null || file == null) { onResult(null, "Não há gravação ativa."); return }
        try {
            recorder.stop()
            recorder.reset()
            recorder.release()
            if (!file.exists() || file.length() < 100) throw IllegalStateException("O áudio ficou vazio. Grave novamente.")
            onResult(file, null)
        } catch (e: Exception) {
            runCatching { recorder.release() }
            file.delete()
            onResult(null, e.message ?: "A gravação não pôde ser concluída.")
        }
    }

    internal fun playAudio(file: File, onFinished: () -> Unit) {
        var player: MediaPlayer? = null
        try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { it.release(); file.delete(); onFinished() }
                setOnErrorListener { mp, _, _ -> mp.release(); file.delete(); onFinished(); true }
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (_: Exception) {
            runCatching { player?.release() }
            file.delete()
            onFinished()
        }
    }

    internal fun sendAudioMessage(token: String, roomId: String, file: File, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val created = graphql(token, "mutation(${'$'}room: uuid!) { create_private_room_audio(args: {p_room_id: ${'$'}room}) { message_id } }", JSONObject().put("room", roomId))
                val messageId = created.optJSONArray("create_private_room_audio")?.optJSONObject(0)?.optString("message_id")
                    ?: throw IllegalStateException("Não consegui iniciar o envio do áudio.")
                val total = withContext(Dispatchers.IO) { file.length() }
                val chunkBytes = 96 * 1024
                var index = 0
                RandomAccessFile(file, "r").use { raf ->
                    val buffer = ByteArray(chunkBytes)
                    while (true) {
                        val n = withContext(Dispatchers.IO) { raf.read(buffer) }
                        if (n < 0) break
                        val payload = "data:audio/mp4;base64," + Base64.encodeToString(if (n == buffer.size) buffer.copyOf() else buffer.copyOf(n), Base64.NO_WRAP)
                        graphql(token, "mutation(${'$'}id: uuid!, ${'$'}index: Int!, ${'$'}audio: String!) { add_private_room_audio_chunk(args: {p_message_id: ${'$'}id, p_chunk_index: ${'$'}index, p_audio_data: ${'$'}audio}) { chunk_index } }", JSONObject().put("id", messageId).put("index", index).put("audio", payload))
                        index++
                        onResult("PROGRESS:${(raf.filePointer * 100 / total.coerceAtLeast(1)).toInt().coerceIn(0, 99)}")
                    }
                }
                if (index == 0) throw IllegalStateException("O áudio ficou vazio.")
                graphql(token, "mutation(${'$'}id: uuid!, ${'$'}count: Int!) { complete_private_room_audio(args: {p_message_id: ${'$'}id, p_chunk_count: ${'$'}count}) { message_id } }", JSONObject().put("id", messageId).put("count", index))
                withContext(Dispatchers.IO) { file.delete() }
                onResult(null)
            } catch (e: Exception) {
                withContext(Dispatchers.IO) { file.delete() }
                onResult(e.message ?: "Não foi possível enviar o áudio.")
            }
        }
    }

    internal fun createCameraImageFile(): File = File(cacheDir, "camera-${UUID.randomUUID()}.jpg")
    internal fun createCameraVideoFile(): File = File(cacheDir, "camera-${UUID.randomUUID()}.mp4")
    internal fun fileProviderUri(file: File): Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    internal fun compressCameraPhoto(source: File): File? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(source.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 1920 || bounds.outHeight / sample > 1920) sample *= 2
            val bitmap = BitmapFactory.decodeFile(source.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }) ?: return null
            val output = File(cacheDir, "photo-${UUID.randomUUID()}.jpg")
            FileOutputStream(output).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 86, it) }
            source.delete()
            output
        } catch (_: Exception) { null }
    }

    internal fun loadAudio(token: String, messageId: String, onResult: (File?, String?) -> Unit) {
        lifecycleScope.launch {
            val target = File(cacheDir, "play-${UUID.randomUUID()}.m4a")
            try {
                var next = 0
                while (true) {
                    val rows = graphql(token, "query(${'$'}id: uuid!, ${'$'}start: Int!, ${'$'}limit: Int!) { get_private_room_audio_chunks(args: {p_message_id: ${'$'}id, p_start_index: ${'$'}start, p_limit: ${'$'}limit}) { chunk_index audio_data } }", JSONObject().put("id", messageId).put("start", next).put("limit", 4)).optJSONArray("get_private_room_audio_chunks") ?: break
                    if (rows.length() == 0) break
                    withContext(Dispatchers.IO) { FileOutputStream(target, true).use { out ->
                        for (i in 0 until rows.length()) {
                            val row = rows.optJSONObject(i) ?: throw IllegalStateException("Áudio incompleto.")
                            if (row.optInt("chunk_index", -1) != next) throw IllegalStateException("Áudio incompleto.")
                            val data = row.optString("audio_data")
                            if (!data.startsWith("data:audio/mp4;base64,")) throw IllegalStateException("Áudio inválido.")
                            out.write(Base64.decode(data.substringAfter(","), Base64.DEFAULT))
                            next++
                        }
                    } }
                    if (rows.length() < 4) break
                }
                if (target.length() == 0L) throw IllegalStateException("Áudio indisponível ou vazio.")
                onResult(target, null)
            } catch (e: Exception) {
                target.delete()
                onResult(null, e.message ?: "Não foi possível carregar o áudio.")
            }
        }
    }

    internal fun sendMediaFile(token: String, roomId: String, file: File, mime: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                if (mime !in setOf("image/jpeg", "video/mp4")) throw IllegalArgumentException("Formato de foto ou vídeo inválido.")
                if (!file.exists() || file.length() == 0L) throw IllegalArgumentException("Arquivo vazio.")
                if (mime == "video/mp4" && file.length() > 150L * 1024 * 1024) throw IllegalArgumentException("Vídeo acima de 150 MB; grave um vídeo menor.")
                if (mime == "image/jpeg" && file.length() > 20L * 1024 * 1024) throw IllegalArgumentException("Foto acima de 20 MB.")
                val created = graphql(token, "mutation(${'$'}room: uuid!, ${'$'}mime: String!) { create_private_room_media(args: {p_room_id: ${'$'}room, p_mime_type: ${'$'}mime}) { message_id } }", JSONObject().put("room", roomId).put("mime", mime))
                val messageId = created.optJSONArray("create_private_room_media")?.optJSONObject(0)?.optString("message_id")
                    ?: throw IllegalStateException("Não consegui iniciar o envio da mídia.")
                val total = withContext(Dispatchers.IO) { file.length() }
                val chunkBytes = 96 * 1024
                var index = 0
                RandomAccessFile(file, "r").use { raf ->
                    val buffer = ByteArray(chunkBytes)
                    while (true) {
                        val n = withContext(Dispatchers.IO) { raf.read(buffer) }
                        if (n < 0) break
                        val encoded = Base64.encodeToString(if (n == buffer.size) buffer.copyOf() else buffer.copyOf(n), Base64.NO_WRAP)
                        val part = "data:$mime;base64,$encoded"
                        graphql(token, "mutation(${'$'}id: uuid!, ${'$'}index: Int!, ${'$'}mime: String!, ${'$'}data: String!) { add_private_room_media_chunk(args: {p_message_id: ${'$'}id, p_chunk_index: ${'$'}index, p_mime_type: ${'$'}mime, p_media_data: ${'$'}data}) { chunk_index } }", JSONObject().put("id", messageId).put("index", index).put("mime", mime).put("data", part))
                        index++
                        onResult("PROGRESS:${(raf.filePointer * 100 / total.coerceAtLeast(1)).toInt().coerceIn(0,99)}")
                    }
                }
                if (index == 0) throw IllegalStateException("Arquivo vazio.")
                graphql(token, "mutation(${'$'}id: uuid!, ${'$'}count: Int!) { complete_private_room_media(args: {p_message_id: ${'$'}id, p_chunk_count: ${'$'}count}) { message_id } }", JSONObject().put("id", messageId).put("count", index))
                withContext(Dispatchers.IO) { file.delete() }
                onResult(null)
            } catch (e: Exception) {
                withContext(Dispatchers.IO) { file.delete() }
                onResult(e.message ?: "Não foi possível enviar a foto/vídeo.")
            }
        }
    }

    internal fun shareMediaFile(token: String, roomId: String, source: File, mime: String, onResult: (String?) -> Unit) {
        sendMediaFile(token, roomId, source, mime, onResult)
    }

    internal fun loadMediaFile(token: String, messageId: String, onResult: (File?, String?, String?) -> Unit) {
        lifecycleScope.launch {
            val target = File(cacheDir, "media-${UUID.randomUUID()}")
            try {
                val meta = graphql(token, "query(${'$'}id: uuid!) { private_room_media_info(args: {p_message_id: ${'$'}id}) { mime_type chunk_count } }", JSONObject().put("id", messageId)).optJSONArray("private_room_media_info")?.optJSONObject(0)
                    ?: throw IllegalStateException("Foto ou vídeo indisponível.")
                val mime = meta.optString("mime_type")
                val count = meta.optInt("chunk_count")
                if (mime !in setOf("image/jpeg", "video/mp4") || count <= 0) throw IllegalStateException("Arquivo inválido.")
                for (start in 0 until count step 4) {
                    val rows = graphql(token, "query(${'$'}id: uuid!, ${'$'}start: Int!, ${'$'}limit: Int!) { get_private_room_media_chunks(args: {p_message_id: ${'$'}id, p_start_index: ${'$'}start, p_limit: ${'$'}limit}) { chunk_index media_data } }", JSONObject().put("id", messageId).put("start", start).put("limit", 4)).optJSONArray("get_private_room_media_chunks")
                        ?: throw IllegalStateException("Mídia incompleta.")
                    withContext(Dispatchers.IO) { FileOutputStream(target, start > 0).use { out ->
                        for (i in 0 until rows.length()) {
                            val row = rows.optJSONObject(i) ?: throw IllegalStateException("Mídia incompleta.")
                            val idx = row.optInt("chunk_index", -1)
                            if (idx != start + i) throw IllegalStateException("Mídia incompleta.")
                            val data = row.optString("media_data")
                            if (!data.startsWith("data:$mime;base64,")) throw IllegalStateException("Formato de mídia inesperado.")
                            out.write(Base64.decode(data.substringAfter(","), Base64.DEFAULT))
                        }
                    } }
                    if (rows.length() == 0) throw IllegalStateException("Mídia incompleta.")
                }
                if (target.length() == 0L) throw IllegalStateException("Arquivo vazio.")
                onResult(target, mime, null)
            } catch (e: Exception) {
                target.delete()
                onResult(null, null, e.message ?: "Não foi possível carregar a mídia.")
            }
        }
    }

    internal fun saveLocalChatWallpaper(userId: String, roomId: String, uri: Uri): Bitmap? = runCatching {
        val original = loadWallpaperBitmap(uri) ?: return@runCatching null
        val maxSide = maxOf(original.width, original.height)
        val scaled = if (maxSide > 1440) {
            val ratio = 1440f / maxSide
            Bitmap.createScaledBitmap(original, (original.width * ratio).toInt().coerceAtLeast(1), (original.height * ratio).toInt().coerceAtLeast(1), true)
        } else original
        val directory = File(filesDir, "local-chat-wallpapers").apply { mkdirs() }
        val safeUser = userId.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val safeRoom = roomId.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val target = File(directory, "${safeUser}_${safeRoom}.jpg")
        FileOutputStream(target).use { output ->
            if (!scaled.compress(Bitmap.CompressFormat.JPEG, 88, output)) return@runCatching null
            output.flush()
        }
        scaled
    }.getOrNull()

    internal fun loadLocalChatWallpaper(userId: String, roomId: String): Bitmap? = runCatching {
        val safeUser = userId.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val safeRoom = roomId.replace(Regex("[^A-Za-z0-9_-]"), "_")
        BitmapFactory.decodeFile(File(File(filesDir, "local-chat-wallpapers"), "${safeUser}_${safeRoom}.jpg").absolutePath)
    }.getOrNull()

    internal fun loadWallpaperBitmap(uri: Uri): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1440 || bounds.outHeight / sample > 1440) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }.getOrNull()

    internal fun imageToDataUri(uri: Uri): String? = runCatching {
        val original = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return@runCatching null
        val maxSide = maxOf(original.width, original.height)
        val scaled = if (maxSide > 1024) {
            val ratio = 1024f / maxSide
            Bitmap.createScaledBitmap(original, (original.width * ratio).toInt().coerceAtLeast(1), (original.height * ratio).toInt().coerceAtLeast(1), true)
        } else original
        val bytes = java.io.ByteArrayOutputStream().use { stream ->
            var quality = 82
            do {
                stream.reset()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, stream)
                quality -= 8
            } while (stream.size() > 300_000 && quality >= 34)
            stream.toByteArray()
        }
        if (bytes.size > 400_000) return@runCatching null
        "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }.getOrNull()

    internal fun decodeSharedWallpaper(data: String): Bitmap? = runCatching {
        val payload = data.substringAfter(",", data)
        val bytes = Base64.decode(payload, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }.getOrNull()

    internal fun loadSharedWallpaper(token: String, roomId: String, knownUpdatedAt: String, onResult: (String?, String?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val markerQuery = "query(${ '$' }room: uuid!) { room_wallpapers_by_pk(room_id: ${ '$' }room) { updated_at } }"
                val variables = JSONObject().put("room", roomId)
                val marker = graphql(token, markerQuery, variables).optJSONObject("room_wallpapers_by_pk")
                val latest = marker?.optString("updated_at").orEmpty()
                if (latest.isBlank()) { onResult(null, null, null); return@launch }
                if (latest == knownUpdatedAt) { onResult(null, latest, null); return@launch }
                val query = "query(${ '$' }room: uuid!) { room_wallpapers_by_pk(room_id: ${ '$' }room) { wallpaper_data updated_at } }"
                val row = graphql(token, query, variables).optJSONObject("room_wallpapers_by_pk")
                onResult(row?.optString("wallpaper_data")?.takeIf { it.isNotBlank() }, row?.optString("updated_at"), null)
            } catch (e: Exception) { onResult(null, null, e.message ?: "Não foi possível carregar o papel de parede compartilhado.") }
        }
    }

    internal fun uploadSharedWallpaper(token: String, roomId: String, uri: Uri, onResult: (String?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val bitmap = loadWallpaperBitmap(uri) ?: throw IllegalStateException("Não consegui abrir essa foto.")
                val maxSide = maxOf(bitmap.width, bitmap.height)
                val scaled = if (maxSide > 1024) {
                    val ratio = 1024f / maxSide
                    Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true)
                } else bitmap
                val bytes = java.io.ByteArrayOutputStream().use { stream ->
                    var quality = 76
                    do {
                        stream.reset()
                        scaled.compress(Bitmap.CompressFormat.JPEG, quality, stream)
                        quality -= 8
                    } while (stream.size() > 360_000 && quality >= 36)
                    stream.toByteArray()
                }
                if (bytes.size > 400_000) throw IllegalStateException("A foto ficou grande demais para compartilhar. Escolha outra imagem.")
                val mime = contentResolver.getType(uri)?.lowercase().orEmpty()
                if (!mime.startsWith("image/")) throw IllegalStateException("Escolha uma foto da galeria.")
                val encoded = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
                val check = graphql(token, "query(${ '$' }room: uuid!) { room_wallpapers_by_pk(room_id: ${ '$' }room) { room_id } }", JSONObject().put("room", roomId))
                val mutation = if (check.optJSONObject("room_wallpapers_by_pk") != null) {
                    "mutation(${ '$' }room: uuid!, ${ '$' }data: String!) { update_room_wallpapers_by_pk(pk_columns: {room_id: ${ '$' }room}, _set: {wallpaper_data: ${ '$' }data}) { room_id } }"
                } else {
                    "mutation(${ '$' }room: uuid!, ${ '$' }data: String!) { insert_room_wallpapers_one(object: {room_id: ${ '$' }room, wallpaper_data: ${ '$' }data}) { room_id } }"
                }
                val result = graphql(token, mutation, JSONObject().put("room", roomId).put("data", encoded))
                val row = result.optJSONObject("insert_room_wallpapers_one") ?: result.optJSONObject("update_room_wallpapers_by_pk")
                if (row == null) throw IllegalStateException("O servidor não devolveu a confirmação de compartilhamento.")
                onResult("data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP), null)
            } catch (e: Exception) { onResult(null, e.message ?: "Não foi possível compartilhar o papel de parede.") }
        }
    }

    internal fun hideMessageForMe(userId: String, messageId: String) {
        val key = "$userId:$messageId"
        getSharedPreferences("messenger_hidden_messages", MODE_PRIVATE)
            .edit().putBoolean(key, true).apply()
    }

    internal fun isMessageHiddenForMe(userId: String, messageId: String): Boolean =
        getSharedPreferences("messenger_hidden_messages", MODE_PRIVATE)
            .getBoolean("$userId:$messageId", false)

    internal fun deleteMessageForEveryone(token: String, roomId: String, messageId: String, userId: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                // The Hasura delete permission must independently restrict sender_id to X-Hasura-User-Id.
                val mutation = "mutation(${'$'}where: messages_bool_exp!) { delete_messages(where: ${'$'}where) { affected_rows } }"
                val where = JSONObject()
                    .put("id", JSONObject().put("_eq", messageId))
                    .put("sender_id", JSONObject().put("_eq", userId))
                    .put("room_id", JSONObject().put("_eq", roomId))
                val data = graphql(token, mutation, JSONObject().put("where", where))
                val affected = data.optJSONObject("delete_messages")?.optInt("affected_rows", 0) ?: 0
                if (affected != 1) throw IllegalStateException("A mensagem não foi apagada. Verifique a permissão segura do servidor.")
                onResult(null)
            } catch (e: Exception) {
                onResult(e.message ?: "Não foi possível apagar para todos.")
            }
        }
    }

    private suspend fun graphql(token: String, query: String, variables: JSONObject = JSONObject()): JSONObject = withContext(Dispatchers.IO) {
        val conn = (URL(graphqlUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
        }
        val payload = JSONObject().put("query", query).put("variables", variables).toString()
        conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val status = conn.responseCode
        val stream = if (status in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        val result = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
        val errors = result.optJSONArray("errors")
        if (status !in 200..299 || (errors != null && errors.length() > 0)) {
            val first = errors?.optJSONObject(0)
            throw IllegalStateException(first?.optString("message").orEmpty().ifBlank { "Falha ao acessar as conversas (HTTP $status)." })
        }
        result.optJSONObject("data") ?: throw IllegalStateException("O servidor não retornou dados do chat.")
    }

    internal fun loadRooms(token: String, onResult: (List<Room>?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val data = graphql(token, "query { rooms(order_by: {created_at: desc}) { id title room_type created_by } }")
                val found = LinkedHashMap<String, Room>()
                val rows = data.optJSONArray("rooms") ?: org.json.JSONArray()
                for (i in 0 until rows.length()) rows.optJSONObject(i)?.let { row ->
                    val kind = if (row.optString("room_type") == "private") RoomKind.PRIVATE else RoomKind.PUBLIC
                    if (kind == RoomKind.PUBLIC) found[row.optString("id")] = Room(row.optString("id"), row.optString("title"), RoomKind.PUBLIC, "Sala pública", row.optString("created_by"))
                }
                // O campo de salas privadas pertence a um tipo/versão que não está disponível neste Nhost.
                // Salas públicas são carregadas independentemente; consultas privadas opcionais abaixo continuam isoladas.
                runCatching { graphql(token, "query { my_accepted_private_rooms { room_id room_title owner_id joined_at } }") }.getOrNull()?.optJSONArray("my_accepted_private_rooms")?.let { rows2 ->
                    for (i in 0 until rows2.length()) rows2.optJSONObject(i)?.let { row ->
                        found[row.optString("room_id")] = Room(row.optString("room_id"), row.optString("room_title"), RoomKind.PRIVATE, "Privada • convite aceito", row.optString("owner_id"))
                    }
                }
                runCatching { graphql(token, "query { my_pending_private_invites { room_id room_title inviter_id invited_at } }") }.getOrNull()?.optJSONArray("my_pending_private_invites")?.let { rows2 ->
                    for (i in 0 until rows2.length()) rows2.optJSONObject(i)?.let { row ->
                        val id = row.optString("room_id")
                        found[id] = Room(id, row.optString("room_title"), RoomKind.PRIVATE, "Convite pendente • toque para aceitar", row.optString("inviter_id"), true)
                    }
                }
                runCatching { graphql(token, "query { my_messenger_groups { room_id group_title owner_id } }") }.getOrNull()?.optJSONArray("my_messenger_groups")?.let { rows2 ->
                    for (i in 0 until rows2.length()) rows2.optJSONObject(i)?.let { row ->
                        found[row.optString("room_id")] = Room(row.optString("room_id"), row.optString("group_title"), RoomKind.GROUP, "Grupo privado", row.optString("owner_id"))
                    }
                }
                runCatching { graphql(token, "query { my_pending_group_invites { room_id group_title inviter_id invited_at } }") }.getOrNull()?.optJSONArray("my_pending_group_invites")?.let { rows2 ->
                    for (i in 0 until rows2.length()) rows2.optJSONObject(i)?.let { row ->
                        val id = row.optString("room_id")
                        found[id] = Room(id, row.optString("group_title"), RoomKind.GROUP, "Convite de grupo pendente • toque para aceitar", row.optString("inviter_id"), true)
                    }
                }
                onResult(found.values.toList(), null)
            } catch (e: Exception) { onResult(null, e.message ?: "Erro ao buscar conversas.") }
        }
    }

    internal fun inviteByEmail(token: String, roomId: String, email: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${'$'}room: uuid!, ${'$'}email: String!) { invite_room_member_by_email(args: {p_room_id: ${'$'}room, p_email: ${'$'}email}) { id title room_type created_by } }"
                graphql(token, mutation, JSONObject().put("room", roomId).put("email", email.trim()))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não foi possível enviar o convite.") }
        }
    }

    internal fun acceptInvite(token: String, roomId: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${'$'}room: uuid!) { accept_private_room_invite(args: {p_room_id: ${'$'}room}) { room_id accepted_at } }"
                graphql(token, mutation, JSONObject().put("room", roomId))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não foi possível aceitar o convite.") }
        }
    }

    internal fun loadMessages(token: String, roomId: String, onResult: (List<ChatMessage>?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val query = "query(${'$'}roomId: uuid!) { messages(where: {room_id: {_eq: ${'$'}roomId}}, order_by: {created_at: asc}, limit: 200) { id room_id sender_id body created_at } }"
                val data = graphql(token, query, JSONObject().put("roomId", roomId))
                val rows = data.optJSONArray("messages") ?: org.json.JSONArray()
                val raw = (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { row ->
                    ChatMessage(row.optString("id"), row.optString("room_id"), "Usuário", row.optString("body"), row.optString("created_at"), row.optString("sender_id"))
                } }
                val profiles = mutableMapOf<String, JSONObject?>()
                runCatching {
                    graphql(token, "query(${'$'}roomId: uuid!) { room_message_profiles(args: {p_room_id: ${'$'}roomId}) { sender_id display_name avatar_data } }", JSONObject().put("roomId", roomId))
                        .optJSONArray("room_message_profiles")
                }.getOrNull()?.let { profileRows ->
                    for (i in 0 until profileRows.length()) profileRows.optJSONObject(i)?.let { profile -> profiles[profile.optString("sender_id")] = profile }
                }
                val audioRows = runCatching { graphql(token, "query(${'$'}roomId: uuid!) { private_room_audio_message_ids(args: {p_room_id: ${'$'}roomId}) { message_id } }", JSONObject().put("roomId", roomId)).optJSONArray("private_room_audio_message_ids") }.getOrNull()
                val audioIds = audioRows?.let { (0 until it.length()).mapNotNull { i -> it.optJSONObject(i)?.optString("message_id") }.toSet() }.orEmpty()
                val mediaRows = runCatching { graphql(token, "query(${'$'}roomId: uuid!) { private_room_media_message_ids(args: {p_room_id: ${'$'}roomId}) { message_id mime_type } }", JSONObject().put("roomId", roomId)).optJSONArray("private_room_media_message_ids") }.getOrNull()
                val mediaTypes = mediaRows?.let { rows -> (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { it.optString("message_id") to it.optString("mime_type") } }.toMap() }.orEmpty()
                val found = raw.map { message ->
                    val profileData = profiles[message.senderId]
                    message.copy(author = profileData?.optString("display_name").orEmpty().ifBlank { "Usuário" }, avatarData = profileData?.optString("avatar_data")?.takeIf { it.isNotBlank() }, audioId = message.id.takeIf { it in audioIds }, mediaType = mediaTypes[message.id])
                }
                onResult(found, null)
            } catch (e: Exception) { onResult(null, e.message ?: "Erro ao buscar mensagens.") }
        }
    }

    internal fun loadProfile(token: String, userId: String, onResult: (String?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val row = graphql(token, "query(${ '$' }id: uuid!) { get_message_profile(args: {p_user_id: ${ '$' }id}) { display_name avatar_data } }", JSONObject().put("id", userId)).optJSONArray("get_message_profile")?.optJSONObject(0)
                onResult(row?.optString("display_name"), row?.optString("avatar_data")?.takeIf { it.isNotBlank() })
            } catch (_: Exception) { onResult(null, null) }
        }
    }

    internal fun loadMyProfile(token: String, onResult: (String?, String?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val data = graphql(token, "query { my_messenger_profile { display_name avatar_data } }")
                val row = data.optJSONArray("my_messenger_profile")?.optJSONObject(0)
                onResult(row?.optString("display_name"), row?.optString("avatar_data")?.takeIf { it.isNotBlank() }, null)
            } catch (e: Exception) { onResult(null, null, e.message ?: "Perfil ainda não configurado.") }
        }
    }

    internal fun saveMyProfile(token: String, displayName: String, avatarData: String?, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${ '$' }name: String!, ${ '$' }avatar: String) { upsert_my_profile(args: {p_display_name: ${ '$' }name, p_avatar_data: ${ '$' }avatar}) { user_id } }"
                graphql(token, mutation, JSONObject().put("name", displayName.trim().take(60)).put("avatar", avatarData ?: JSONObject.NULL))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não foi possível salvar o perfil.") }
        }
    }

    internal fun requestFriend(token: String, email: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${ '$' }email: String!) { request_friend_by_email(args: {p_email: ${ '$' }email}) { request_id } }"
                graphql(token, mutation, JSONObject().put("email", email.trim()))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não foi possível enviar o pedido de amizade.") }
        }
    }

    internal fun requestFriendByUserId(token: String, roomId: String, targetUserId: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${ '$' }room: uuid!, ${ '$' }user: uuid!) { request_friend_by_user_id_in_room(args: {p_room_id: ${ '$' }room, p_user_id: ${ '$' }user}) { request_id } }"
                graphql(token, mutation, JSONObject().put("room", roomId).put("user", targetUserId))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não foi possível enviar o pedido de amizade.") }
        }
    }

    internal fun respondFriendRequest(token: String, requestId: String, accept: Boolean, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${ '$' }id: uuid!, ${ '$' }accept: Boolean!) { respond_friend_request(args: {p_request_id: ${ '$' }id, p_accept: ${ '$' }accept}) { request_id status } }"
                graphql(token, mutation, JSONObject().put("id", requestId).put("accept", accept))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não foi possível responder ao pedido.") }
        }
    }

    internal fun updatePresence(token: String, isOnline: Boolean, onResult: (String?) -> Unit = {}) {
        lifecycleScope.launch {
            try {
                graphql(token, "mutation(${'$'}online: Boolean!) { set_my_presence(args: {p_online: ${'$'}online}) { user_id last_seen } }", JSONObject().put("online", isOnline))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não consegui atualizar o estado online.") }
        }
    }

    internal fun loadFriends(token: String, onResult: (List<FriendProfile>?, List<FriendProfile>?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val data = graphql(token, "query { my_messenger_friends { user_id display_name avatar_data } my_incoming_friend_requests { request_id user_id display_name avatar_data } my_friends_presence { user_id is_online } }")
                val presenceRows = data.optJSONArray("my_friends_presence") ?: org.json.JSONArray()
                val presenceByUser = (0 until presenceRows.length()).mapNotNull { presenceRows.optJSONObject(it) }.associate { it.optString("user_id") to it.optBoolean("is_online") }
                fun parse(key: String, requests: Boolean): List<FriendProfile> {
                    val rows = data.optJSONArray(key) ?: org.json.JSONArray()
                    return (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { row ->
                        FriendProfile(row.optString("user_id"), row.optString("display_name").ifBlank { "Contato" }, row.optString("avatar_data").takeIf { it.isNotBlank() }, if (requests) row.optString("request_id") else "", requests, !requests, presenceByUser[row.optString("user_id")] == true)
                    } }
                }
                onResult(parse("my_messenger_friends", false), parse("my_incoming_friend_requests", true), null)
            } catch (e: Exception) { onResult(null, null, e.message ?: "Não consegui carregar amigos.") }
        }
    }

    internal fun createGroup(token: String, userId: String, title: String, friendIds: List<String>, onResult: (Room?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val ids = org.json.JSONArray(friendIds.distinct())
                val mutation = "mutation(${'$'}title: String!, ${'$'}members: [uuid!]!) { create_private_messenger_group(args: {p_title: ${'$'}title, p_member_ids: ${'$'}members}) { room_id group_title } }"
                val result = graphql(token, mutation, JSONObject().put("title", title.trim()).put("members", ids)).optJSONArray("create_private_messenger_group")?.optJSONObject(0)
                    ?: throw IllegalStateException("Não consegui criar o grupo.")
                onResult(Room(result.optString("room_id"), result.optString("group_title"), RoomKind.GROUP, "Grupo privado", userId), null)
            } catch (e: Exception) { onResult(null, e.message ?: "Erro ao criar grupo.") }
        }
    }

    internal fun acceptGroupInvite(token: String, roomId: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                graphql(token, "mutation(${'$'}room: uuid!) { accept_messenger_group_invite(args: {p_room_id: ${'$'}room}) { room_id accepted_at } }", JSONObject().put("room", roomId))
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Não foi possível aceitar o convite do grupo.") }
        }
    }

    internal fun createRoom(token: String, userId: String, title: String, kind: RoomKind, onResult: (Room?, String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${'$'}object: rooms_insert_input!) { insert_rooms_one(object: ${'$'}object) { id title room_type created_by } }"
                val variables = JSONObject().put("object", JSONObject().put("title", title.trim()).put("room_type", if (kind == RoomKind.PUBLIC) "public" else "private"))
                val row = graphql(token, mutation, variables).optJSONObject("insert_rooms_one")
                    ?: throw IllegalStateException("O servidor não permitiu criar a sala.")
                onResult(Room(row.optString("id"), row.optString("title", title), kind, if (kind == RoomKind.PUBLIC) "Sala pública" else "Sala privada", row.optString("created_by", userId)), null)
            } catch (e: Exception) { onResult(null, e.message ?: "Erro ao criar conversa.") }
        }
    }

    internal fun sendMessage(token: String, roomId: String, userId: String, body: String, onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val mutation = "mutation(${'$'}object: messages_insert_input!) { insert_messages_one(object: ${'$'}object) { id } }"
                val variables = JSONObject().put("object", JSONObject().put("room_id", roomId).put("body", body.trim()))
                graphql(token, mutation, variables)
                onResult(null)
            } catch (e: Exception) { onResult(e.message ?: "Erro ao enviar mensagem.") }
        }
    }

    internal fun registerUnifiedPush() {
        UnifiedPush.tryUseCurrentOrDefaultDistributor(this) { selected ->
            runOnUiThread {
                if (selected) {
                    // No endpoint is uploaded or stored. A secure authenticated backend is still required.
                    UnifiedPush.register(applicationContext, messageForDistributor = "Mensageiro")
                    Toast.makeText(this, "Registro UnifiedPush solicitado. O envio pelo servidor ainda não está configurado.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Nenhum distribuidor UnifiedPush disponível. Instale/abra ntfy e tente novamente.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    internal fun unregisterUnifiedPush() {
        UnifiedPush.unregister(applicationContext)
        Toast.makeText(this, "Notificações UnifiedPush desativadas neste aparelho.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Panel)) {
                MessengerApp()
            }
        }
    }
}

@Composable
private fun MessengerApp() {
    var screen by remember { mutableStateOf(Screen.AUTH) }
    var isSignup by remember { mutableStateOf(true) }
    var displayName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var accessToken by remember { mutableStateOf("") }
    var userId by remember { mutableStateOf("") }
    var selectedRoom by remember { mutableStateOf<Room?>(null) }
    var roomKind by remember { mutableStateOf(RoomKind.PUBLIC) }
    var showCreateRoom by remember { mutableStateOf(false) }
    var showCreateGroup by remember { mutableStateOf(false) }
    var groupTitle by remember { mutableStateOf("") }
    val selectedGroupFriends = remember { mutableStateListOf<String>() }
    var newRoomName by remember { mutableStateOf("") }
    var inviteRoom by remember { mutableStateOf<Room?>(null) }
    var inviteEmail by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var showBackendInfo by remember { mutableStateOf(false) }
    var showClearCacheConfirm by remember { mutableStateOf(false) }
    val activity = androidx.compose.ui.platform.LocalContext.current as? MainActivity
    val settingsPrefs = remember(activity) { activity?.getSharedPreferences("messenger_settings", Context.MODE_PRIVATE) }
    var fontScale by remember { mutableFloatStateOf(settingsPrefs?.getFloat("font_scale", 1f) ?: 1f) }
    var pushNotice by remember { mutableStateOf("Ainda não configurado neste aparelho.") }
    var authCheckStatus by remember { mutableStateOf("Ainda não testada.") }
    var authCheckInProgress by remember { mutableStateOf(false) }
    val pushPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { activity?.registerUnifiedPush(); pushNotice = "Registro solicitado. O backend de envio ainda não existe/configurado." }
        else pushNotice = "Permissão de notificações negada no Android."
    }
    var showProfileDialog by remember { mutableStateOf(false) }
    var ownOnline by remember { mutableStateOf(false) }
    var friendProfiles by remember { mutableStateOf<List<FriendProfile>>(emptyList()) }
    var incomingFriendRequests by remember { mutableStateOf<List<FriendProfile>>(emptyList()) }
    var friendEmail by remember { mutableStateOf("") }
    var myAvatarData by remember { mutableStateOf<String?>(null) }
    var myAvatarBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var pendingAvatarData by remember { mutableStateOf<String?>(null) }
    var pendingAvatarBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var notice by remember { mutableStateOf("Entre com sua conta para carregar as conversas do servidor.") }
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(accessToken, activity, lifecycleOwner) {
        if (accessToken.isBlank() || activity == null || screen == Screen.AUTH) return@LaunchedEffect
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            activity.updatePresence(accessToken, true) { error -> if (error == null) ownOnline = true else { ownOnline = false; notice = "Status online/offline ainda não ativado no servidor." } }
            val heartbeat = launch {
                while (true) {
                    delay(15_000)
                    activity.updatePresence(accessToken, true) { error -> if (error == null) ownOnline = true else ownOnline = false }
                }
            }
            try { awaitCancellation() }
            finally {
                heartbeat.cancel()
                activity.updatePresence(accessToken, false)
                ownOnline = false
            }
        }
    }
    val profileImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && activity != null) {
            val avatar = activity.imageToDataUri(uri)
            if (avatar == null) notice = "Não consegui preparar essa foto. Escolha outra."
            else {
                pendingAvatarData = avatar
                pendingAvatarBitmap = activity.decodeSharedWallpaper(avatar)
            }
        }
    }

    val rooms = remember { mutableStateListOf<Room>() }
    val messages = remember { mutableStateListOf<ChatMessage>() }

    fun refreshRooms() {
        val current = activity ?: return
        if (accessToken.isNotBlank()) current.loadRooms(accessToken) { found, error ->
            if (found != null) { rooms.clear(); rooms.addAll(found) }
            if (error != null) notice = error
        }
    }


    Surface(Modifier.fillMaxSize(), color = Navy) {
        val baseDensity = LocalDensity.current
        CompositionLocalProvider(LocalDensity provides Density(baseDensity.density, fontScale)) {
        when (screen) {
            Screen.AUTH -> AuthScreen(
                signup = isSignup,
                name = displayName,
                onName = { displayName = it },
                email = email,
                onEmail = { email = it },
                onToggle = { isSignup = !isSignup },
                onSubmit = { submittedName, submittedEmail, submittedPassword ->
                    val currentActivity = activity
                    if (currentActivity == null) {
                        notice = "Não consegui iniciar a autenticação."
                    } else {
                        currentActivity.authenticateWithNhost(
                            signup = isSignup,
                            name = submittedName,
                            email = submittedEmail,
                            password = submittedPassword,
                            onSuccess = { accountName, accountEmail, token, accountId ->
                                displayName = accountName
                                email = accountEmail
                                accessToken = token
                                userId = accountId
                                screen = Screen.ROOMS
                                notice = "Conectado ao servidor. Carregando conversas…"
                                currentActivity.loadRooms(token) { found, error ->
                                    if (found != null) { rooms.clear(); rooms.addAll(found); notice = "Conversas atualizadas do servidor." }
                                    if (error != null) notice = error
                                }
                                currentActivity.loadMyProfile(token) { savedName, avatar, profileError ->
                                    if (!savedName.isNullOrBlank()) {
                                        displayName = savedName
                                        myAvatarData = avatar
                                        myAvatarBitmap = avatar?.let(currentActivity::decodeSharedWallpaper)
                                    } else {
                                        currentActivity.saveMyProfile(token, accountName, null) { saveError ->
                                            if (saveError != null) notice = "Configure o backend de perfil incluído no ZIP para mostrar nome e foto aos outros. Sem esse backend, a criação segura de grupos por amizade não estará disponível."
                                            else { displayName = accountName; notice = "Perfil criado. Você pode adicionar uma foto pelo botão de perfil." }
                                        }
                                    }
                                    if (profileError != null) notice = "Perfil ainda não sincronizado. Configure as tabelas de perfil incluídas no ZIP."
                                }
                            },
                            onMessage = { notice = it }
                        )
                    }
                },
                notice = notice
            )
            Screen.ROOMS -> RoomListScreen(
                name = displayName,
                currentUserId = userId,
                rooms = rooms,
                onInvite = { inviteRoom = it },
                status = notice,
                onCreate = { showCreateRoom = true },
                onRefresh = { refreshRooms() },
                onSettings = { showBackendInfo = true },
                onFriends = {
                    activity?.loadFriends(accessToken) { friends, requests, error ->
                        if (error != null) notice = error else { friendProfiles = friends.orEmpty(); incomingFriendRequests = requests.orEmpty(); screen = Screen.FRIENDS }
                    }
                },
                onCreateGroup = {
                    activity?.loadFriends(accessToken) { friends, requests, error ->
                        if (error != null) notice = error else { friendProfiles = friends.orEmpty(); incomingFriendRequests = requests.orEmpty(); selectedGroupFriends.clear(); groupTitle = ""; showCreateGroup = true }
                    }
                },
                onProfile = { showProfileDialog = true },
                avatar = myAvatarBitmap,
                online = ownOnline,
                onRoom = { room ->
                    if (room.pendingInvite) {
                        val accept: (String?) -> Unit = { error -> if (error != null) notice = error else { notice = "Convite aceito."; refreshRooms() } }
                        if (room.kind == RoomKind.GROUP) activity?.acceptGroupInvite(accessToken, room.id, accept) else activity?.acceptInvite(accessToken, room.id, accept)
                    } else {
                        selectedRoom = room; messages.clear(); screen = Screen.CHAT
                        activity?.loadMessages(accessToken, room.id) { found, error ->
                            if (found != null) { messages.clear(); messages.addAll(found) }
                            if (error != null) notice = error
                        }
                    }
                }
            )
            Screen.FRIENDS -> FriendsScreen(
                friends = friendProfiles,
                requests = incomingFriendRequests,
                status = notice,
                email = friendEmail,
                onEmail = { friendEmail = it },
                onBack = { screen = Screen.ROOMS },
                onRefresh = { activity?.loadFriends(accessToken) { friends, requests, error -> if (error != null) notice = error else { friendProfiles = friends.orEmpty(); incomingFriendRequests = requests.orEmpty() } } },
                onAddFriend = { address -> activity?.requestFriend(accessToken, address) { error -> notice = error ?: "Pedido de amizade enviado." } },
                onRespond = { request, accept -> activity?.respondFriendRequest(accessToken, request, accept) { error ->
                    if (error != null) notice = error else { notice = if (accept) "Amizade aceita." else "Pedido recusado."; activity?.loadFriends(accessToken) { friends, requests, loadError -> if (loadError == null) { friendProfiles = friends.orEmpty(); incomingFriendRequests = requests.orEmpty() } } }
                } },
                onPresenceRefresh = { activity?.loadFriends(accessToken) { friends, requests, loadError -> if (loadError == null) { friendProfiles = friends.orEmpty(); incomingFriendRequests = requests.orEmpty() } } }
            )
            Screen.CHAT -> selectedRoom?.let { room ->
                ChatScreen(
                    room = room,
                    name = displayName,
                    messages = messages.toList(),
                    draft = draft,
                    currentUserId = userId,
                    avatarBitmap = myAvatarBitmap,
                    status = notice,
                    accessToken = accessToken,
                    activity = activity,
                    onMessages = { found -> messages.clear(); messages.addAll(found) },
                    onStatus = { notice = it },
                    onDraft = { draft = it },
                    onBack = { screen = Screen.ROOMS },
                    onSend = {
                        val clean = draft.trim()
                        if (clean.isNotEmpty() && activity != null) {
                            activity.sendMessage(accessToken, room.id, userId, clean) { error ->
                                if (error == null) {
                                    draft = ""
                                    activity?.loadMessages(accessToken, room.id) { found, loadError ->
                                        if (found != null) { messages.clear(); messages.addAll(found) }
                                        if (loadError != null) notice = loadError
                                    }
                                } else notice = error
                            }
                        }
                    }
                )
            }
        }
        }
    }

    if (showCreateGroup) {
        AlertDialog(
            onDismissRequest = { showCreateGroup = false; selectedGroupFriends.clear() },
            title = { Text("Criar grupo privado") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(groupTitle, { groupTitle = it }, label = { Text("Nome do grupo") }, singleLine = true)
                    Text("Escolha ao menos um amigo. Cada pessoa precisa aceitar o convite para entrar.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                    if (friendProfiles.isEmpty()) Text("Você ainda não tem amigos. Adicione primeiro pela tela Amigos.", color = Color(0xFFFFD28A), fontSize = 12.sp)
                    Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                        friendProfiles.forEach { friend ->
                            Row(Modifier.fillMaxWidth().clickable {
                                if (friend.userId in selectedGroupFriends) selectedGroupFriends.remove(friend.userId) else selectedGroupFriends.add(friend.userId)
                            }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = friend.userId in selectedGroupFriends, onCheckedChange = { checked ->
                                    if (checked && friend.userId !in selectedGroupFriends) selectedGroupFriends.add(friend.userId)
                                    if (!checked) selectedGroupFriends.remove(friend.userId)
                                })
                                Text(friend.displayName, color = Color.White)
                            }
                        }
                    }
                    Text("Selecionados: ${selectedGroupFriends.size}", color = Mint, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = {
                val title = groupTitle.trim()
                if (title.length !in 1..60) notice = "O nome deve ter de 1 a 60 caracteres."
                else if (selectedGroupFriends.isEmpty()) notice = "Escolha pelo menos um amigo."
                else activity?.createGroup(accessToken, userId, title, selectedGroupFriends.toList()) { room, error ->
                    if (error != null) notice = error else if (room != null) {
                        rooms.add(0, room); groupTitle = ""; selectedGroupFriends.clear(); showCreateGroup = false; notice = "Grupo criado e convites enviados."
                    }
                }
            }) { Text("Criar grupo") } },
            dismissButton = { TextButton(onClick = { showCreateGroup = false; selectedGroupFriends.clear() }) { Text("Cancelar") } }
        )
    }

    if (inviteRoom != null) {
        val targetRoom = inviteRoom!!
        AlertDialog(onDismissRequest = { inviteRoom = null; inviteEmail = "" },
            title = { Text("Convidar para ${targetRoom.title}") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Convite para a sala privada existente. A pessoa precisa ter conta e aceitar antes de ler as mensagens.", fontSize = 13.sp)
                OutlinedTextField(inviteEmail, { inviteEmail = it }, label = { Text("E-mail da conta") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
            } },
            confirmButton = { TextButton(onClick = {
                val address = inviteEmail.trim()
                if (!address.contains("@")) notice = "Informe o e-mail cadastrado no Mensageiro."
                else activity?.inviteByEmail(accessToken, targetRoom.id, address) { error ->
                    if (error == null) { notice = "Convite enviado para a sala existente."; inviteRoom = null; inviteEmail = ""; refreshRooms() } else notice = error
                }
            }) { Text("Enviar convite") } },
            dismissButton = { TextButton(onClick = { inviteRoom = null; inviteEmail = "" }) { Text("Cancelar") } }
        )
    }

    if (showCreateRoom) {
        AlertDialog(
            onDismissRequest = { showCreateRoom = false },
            title = { Text("Criar conversa") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(newRoomName, { newRoomName = it }, label = { Text("Nome da conversa") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(selected = roomKind == RoomKind.PUBLIC, onClick = { roomKind = RoomKind.PUBLIC }, label = { Text("Pública") }, leadingIcon = { Icon(Icons.Default.Public, null) })
                        Spacer(Modifier.width(8.dp))
                        FilterChip(selected = roomKind == RoomKind.PRIVATE, onClick = { roomKind = RoomKind.PRIVATE }, label = { Text("Privada") }, leadingIcon = { Icon(Icons.Default.Lock, null) })
                    }
                    Text(if (roomKind == RoomKind.PUBLIC) "Sala pública visível para as contas cadastradas." else "Sala privada; convide e aguarde a aceitação para conversar.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = {
                val title = newRoomName.trim()
                if (title.isNotEmpty() && activity != null) {
                    activity.createRoom(accessToken, userId, title, roomKind) { room, error ->
                        if (room != null) { rooms.add(0, room); newRoomName = ""; roomKind = RoomKind.PUBLIC; showCreateRoom = false }
                        if (error != null) notice = error
                    }
                }
            }) { Text("Criar") } },
            dismissButton = { TextButton(onClick = { showCreateRoom = false }) { Text("Cancelar") } }
        )
    }

    if (showProfileDialog) {
        AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            title = { Text("Meu perfil") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (pendingAvatarBitmap != null) Image(pendingAvatarBitmap!!.asImageBitmap(), null, Modifier.size(84.dp).background(Panel, CircleShape), contentScale = ContentScale.Crop)
                    else if (myAvatarBitmap != null) Image(myAvatarBitmap!!.asImageBitmap(), null, Modifier.size(84.dp).background(Panel, CircleShape), contentScale = ContentScale.Crop)
                    else Icon(Icons.Default.AccountCircle, null, tint = Color.White, modifier = Modifier.size(84.dp))
                    OutlinedTextField(displayName, { displayName = it.take(60) }, label = { Text("Nome que os outros verão") }, singleLine = true)
                    TextButton(onClick = { profileImagePicker.launch(arrayOf("image/*")) }) { Text("Escolher foto do perfil") }
                }
            },
            confirmButton = { TextButton(onClick = {
                if (activity != null) activity.saveMyProfile(accessToken, displayName, pendingAvatarData) { error ->
                    if (error != null) notice = error else {
                        myAvatarData = pendingAvatarData ?: myAvatarData
                        myAvatarBitmap = myAvatarData?.let(activity::decodeSharedWallpaper)
                        notice = "Perfil salvo e compartilhado com as contas que podem ver suas mensagens."
                        pendingAvatarData = null; pendingAvatarBitmap = null; showProfileDialog = false
                    }
                }
            }) { Text("Salvar") } },
            dismissButton = { TextButton(onClick = { pendingAvatarData = null; pendingAvatarBitmap = null; showProfileDialog = false }) { Text("Cancelar") } }
        )
    }

    if (showBackendInfo) {
        AlertDialog(
            onDismissRequest = { showBackendInfo = false },
            title = { Text("Configurações") },
            text = {
                Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Conta", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Conectado: $email", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                    OutlinedButton(onClick = {
                        activity?.let { UnifiedPush.unregister(it.applicationContext) }
                        accessToken = ""
                        userId = ""
                        selectedRoom = null
                        rooms.clear()
                        messages.clear()
                        draft = ""
                        notice = "Sessão encerrada. Entre novamente para carregar suas conversas."
                        isSignup = false
                        screen = Screen.AUTH
                        showBackendInfo = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("Sair da conta neste aparelho") }
                    HorizontalDivider(color = Color(0x334F5B8F))
                    Text("Aparência", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Tamanho do texto: ${(fontScale * 100).toInt()}%", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                    Slider(value = fontScale, onValueChange = { fontScale = it }, onValueChangeFinished = { settingsPrefs?.edit()?.putFloat("font_scale", fontScale)?.apply() }, valueRange = 0.85f..1.3f, steps = 8)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { fontScale = (fontScale - 0.05f).coerceAtLeast(0.85f); settingsPrefs?.edit()?.putFloat("font_scale", fontScale)?.apply() }) { Text("A−") }
                        TextButton(onClick = { fontScale = (fontScale + 0.05f).coerceAtMost(1.3f); settingsPrefs?.edit()?.putFloat("font_scale", fontScale)?.apply() }) { Text("A+") }
                    }
                    Text("O tema visual permanece escuro nesta versão.", color = Color(0xFFBFC4E0), fontSize = 11.sp)
                    HorizontalDivider(color = Color(0x334F5B8F))
                    Text("Notificações", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("A permissão do Android controla os avisos do app. As notificações de mensagens em segundo plano ainda dependem da integração do servidor.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                    OutlinedButton(onClick = {
                        runCatching { activity?.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)) }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Abrir notificações do Android") }
                    HorizontalDivider(color = Color(0x334F5B8F))
                    Text("Privacidade e armazenamento", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Controles de status online/última vez dependem de suporte seguro no servidor e ainda não estão disponíveis.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                    Text("Arquivos temporários do Mensageiro", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Limpar o cache remove cópias temporárias baixadas neste aparelho; não apaga mensagens do servidor.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                    OutlinedButton(onClick = { showClearCacheConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Limpar arquivos temporários") }
                    HorizontalDivider(color = Color(0x334F5B8F))
                    Text("Bot automático", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Teste isolado do Gemini: envia somente a pergunta fixa de teste depois de validar sua sessão. Não lê mensagens nem salas.", color = Color(0xFFBFC4E0), fontSize = 13.sp)
                    Button(
                        onClick = {
                            if (accessToken.isBlank()) {
                                authCheckStatus = "Sessão não encontrada. Feche Configurações e entre novamente no Mensageiro."
                            } else if (activity == null) {
                                authCheckStatus = "Não consegui iniciar o teste neste aparelho."
                            } else {
                                authCheckInProgress = true
                                authCheckStatus = "Conectando ao Worker seguro…"
                                activity.testIsolatedGemini(accessToken) {
                                    authCheckStatus = it
                                    authCheckInProgress = false
                                }
                            }
                        },
                        enabled = !authCheckInProgress,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (authCheckInProgress) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Text("Testar Gemini isolado")
                    }
                    Text("Resultado: $authCheckStatus", color = if (authCheckStatus.startsWith("Sessão validada")) Mint else Color(0xFFFFD28A), fontSize = 12.sp)
                    OutlinedButton(
                        onClick = {
                            if (accessToken.isBlank()) authCheckStatus = "Sessão não encontrada. Entre novamente."
                            else if (activity == null) authCheckStatus = "Não consegui iniciar a checagem."
                            else {
                                authCheckInProgress = true
                                activity.checkPublicMessageCapability(accessToken) {
                                    authCheckStatus = it
                                    authCheckInProgress = false
                                }
                            }
                        },
                        enabled = !authCheckInProgress,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Verificar permissão de mensagens (só leitura)") }
                    Text("Worker usa a chave Gemini guardada em segredo. Não acessa o banco nem publica no Mensageiro. Respostas automáticas seguem desligadas.", color = Color(0xFFFFD28A), fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Respostas automáticas", color = Color.White, fontSize = 13.sp)
                            Text("Responder a mensagens novas", color = Color(0xFFBFC4E0), fontSize = 11.sp)
                        }
                        Switch(checked = false, onCheckedChange = {}, enabled = false)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Comando /bot", color = Color.White, fontSize = 13.sp)
                            Text("Responder somente quando chamado", color = Color(0xFFBFC4E0), fontSize = 11.sp)
                        }
                        Switch(checked = false, onCheckedChange = {}, enabled = false)
                    }
                    Text("Salas públicas", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    val publicBotRooms = rooms.filter { it.kind == RoomKind.PUBLIC }
                    if (publicBotRooms.isEmpty()) {
                        Text("Nenhuma sala pública carregada neste momento.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
                    } else {
                        publicBotRooms.take(8).forEach { botRoom ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = false, onCheckedChange = {}, enabled = false)
                                Text(botRoom.title, color = Color(0xFFBFC4E0), fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                    Text("As opções aparecerão desativadas até a etapa de integração segura do servidor. Nenhuma mensagem será lida ou publicada pelo bot nesta etapa.", color = Color(0xFFFFD28A), fontSize = 12.sp)
                    Text("Esta configuração não restringe criação ou uso das salas públicas.", color = Color(0xFFBFC4E0), fontSize = 11.sp)
                    Text(notice, color = Color(0xFFFFD28A), fontSize = 11.sp)
                    HorizontalDivider(color = Color(0x334F5B8F))
                    Text("Notificações sem Firebase (UnifiedPush + ntfy)", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Este teste só registra o distribuidor neste aparelho e mostra avisos genéricos recebidos. O backend ainda não envia notificações e não há vínculo seguro da inscrição com a conta; portanto, não há entrega de mensagens com o app fechado.", color = Color(0xFFFFD28A), fontSize = 11.sp)
                    Button(onClick = {
                        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(activity ?: return@Button, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            pushPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            activity?.registerUnifiedPush()
                            pushNotice = "Registro solicitado. Backend de envio pendente."
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Preparar UnifiedPush neste aparelho") }
                    TextButton(onClick = { activity?.unregisterUnifiedPush(); pushNotice = "Inscrição removida deste aparelho." }) { Text("Desativar notificações neste aparelho") }
                    Text(pushNotice, color = Color(0xFFBFC4E0), fontSize = 11.sp)
                    Text("© 2026 Luiz Fernando. Todos os direitos reservados.", color = Color(0xFF9FA5C5), fontSize = 11.sp)
                    Text("Aviso referente ao código e aos materiais originais do Mensageiro; bibliotecas de terceiros seguem suas próprias licenças.", color = Color(0xFF858BAA), fontSize = 10.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showBackendInfo = false }) { Text("Fechar") } }
        )
    }
    if (showClearCacheConfirm) {
        AlertDialog(
            onDismissRequest = { showClearCacheConfirm = false },
            title = { Text("Limpar arquivos temporários?") },
            text = { Text("Isso apaga cópias temporárias deste aparelho. Mensagens e arquivos já enviados ao servidor não serão apagados.") },
            confirmButton = { TextButton(onClick = {
                val ok = runCatching { activity?.cacheDir?.listFiles()?.forEach { it.deleteRecursively() }; true }.getOrDefault(false)
                notice = if (ok) "Arquivos temporários locais limpos." else "Não consegui limpar o cache agora."
                showClearCacheConfirm = false
            }) { Text("Limpar") } },
            dismissButton = { TextButton(onClick = { showClearCacheConfirm = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun AuthScreen(
    signup: Boolean,
    name: String,
    onName: (String) -> Unit,
    email: String,
    onEmail: (String) -> Unit,
    onToggle: () -> Unit,
    onSubmit: (String, String, String) -> Unit,
    notice: String
) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ChatBubbleOutline, null, tint = Color.White, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("MENSAGEIRO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp, letterSpacing = 1.5.sp)
        Text("Público quando você quiser. Privado quando precisar.", color = Color(0xFFBFC4E0), fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        if (signup) OutlinedTextField(name, onName, label = { Text("Seu nome") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(email, onEmail, label = { Text("E-mail") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
        Spacer(Modifier.height(8.dp))
        var password by remember { mutableStateOf("") }
        OutlinedTextField(password, { password = it }, label = { Text("Senha") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
        Text("Conta do Mensageiro — não é a senha do Gmail.", color = Color(0xFFBFC4E0), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(14.dp))
        Button(onClick = { onSubmit(name, email, password) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(if (signup) "Criar conta" else "Entrar") }
        TextButton(onClick = onToggle) { Text(if (signup) "Já tenho conta" else "Criar conta") }
        Text(notice, color = Color(0xFFFFD28A), fontSize = 11.sp)
    }
}

@Composable
private fun RoomListScreen(name: String, currentUserId: String, rooms: List<Room>, status: String, onCreate: () -> Unit, onRefresh: () -> Unit, onSettings: () -> Unit, onInvite: (Room) -> Unit, onRoom: (Room) -> Unit, onFriends: () -> Unit, onCreateGroup: () -> Unit, onProfile: () -> Unit, avatar: Bitmap?, online: Boolean) {
    var roomSearch by remember { mutableStateOf("") }
    val filteredRooms = rooms.filter { it.title.contains(roomSearch.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Column(Modifier.fillMaxWidth()) {
            Text("Conversas", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 25.sp, maxLines = 1)
            Text(name, color = Color(0xFFBFC4E0), fontSize = 13.sp, maxLines = 1)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Public, "Atualizar", tint = Mint) }
            IconButton(onClick = onFriends) { Icon(Icons.Default.Group, "Amigos", tint = Mint) }
            IconButton(onClick = onProfile) {
                if (avatar != null) Image(avatar.asImageBitmap(), contentDescription = "Meu perfil", modifier = Modifier.size(34.dp).background(Panel, CircleShape), contentScale = ContentScale.Crop)
                else Icon(Icons.Default.AccountCircle, "Meu perfil", tint = Color.White)
            }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Informações", tint = Color.White) }
            IconButton(onClick = onCreate) { Icon(Icons.Default.Add, "Nova conversa", tint = Mint) }
            IconButton(onClick = onCreateGroup) { Icon(Icons.Default.GroupAdd, "Criar grupo", tint = Mint) }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (avatar != null) Image(avatar.asImageBitmap(), contentDescription = "Foto do perfil", modifier = Modifier.size(40.dp).background(Panel, CircleShape), contentScale = ContentScale.Crop)
            else Box(Modifier.size(40.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.AccountCircle, null, tint = Color.White) }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(8.dp).background(if (online) Mint else Color.Gray, CircleShape))
                    Text(if (online) "Online" else "Offline", color = if (online) Mint else Color.LightGray, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onFriends) { Text("Amigos", color = Mint) }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = roomSearch,
            onValueChange = { roomSearch = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Pesquisar sala") },
            placeholder = { Text("Pesquisar sala pública pelo nome") },
            shape = RoundedCornerShape(16.dp)
        )
        Text(status, color = Color(0xFFFFD28A), fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip(onClick = {}, label = { Text("Públicas") }, leadingIcon = { Icon(Icons.Default.Public, null) })
            AssistChip(onClick = {}, label = { Text("Privadas") }, leadingIcon = { Icon(Icons.Default.Lock, null) })
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            if (filteredRooms.isEmpty()) {
                item { Text(if (roomSearch.isBlank()) "Nenhuma sala encontrada. Toque em atualizar." else "Nenhuma sala com esse nome.", color = Color(0xFFBFC4E0), modifier = Modifier.padding(12.dp)) }
            }
            items(filteredRooms, key = { it.id }) { room ->
                Card(modifier = Modifier.fillMaxWidth().clickable { onRoom(room) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(48.dp).background(if (room.kind == RoomKind.PUBLIC) Purple else Color(0xFF3F9C88), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(when (room.kind) { RoomKind.PUBLIC -> Icons.Default.Public; RoomKind.PRIVATE -> Icons.Default.Lock; RoomKind.GROUP -> Icons.Default.Group }, null, tint = Color.White)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(room.title, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(room.detail, color = Color(0xFFBFC4E0), fontSize = 12.sp)
                        }
                        Text(room.kind.label, color = if (room.kind == RoomKind.PUBLIC) Mint else Color(0xFFE0C8FF), fontSize = 11.sp)
                        if (room.kind == RoomKind.PRIVATE && room.createdBy == currentUserId && !room.pendingInvite) {
                            IconButton(onClick = { onInvite(room) }) { Icon(Icons.Default.PersonAdd, "Convidar para esta sala", tint = Mint) }
                        }
                        if (room.pendingInvite) Text("ACEITAR", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Use o botão + para criar uma sala ou o ícone de grupo para montar um grupo privado com amigos.", color = Color(0xFF9FA5C5), fontSize = 11.sp)
    }
}

@Composable
private fun FriendsScreen(friends: List<FriendProfile>, requests: List<FriendProfile>, status: String, email: String, onEmail: (String) -> Unit, onBack: () -> Unit, onRefresh: () -> Unit, onAddFriend: (String) -> Unit, onRespond: (String, Boolean) -> Unit, onPresenceRefresh: () -> Unit) {
    LaunchedEffect(Unit) { while (true) { delay(15_000); onPresenceRefresh() } }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
            Text("Amigos", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onRefresh) { Text("Atualizar", color = Mint) }
        }
        OutlinedTextField(email, onEmail, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("E-mail da conta no Mensageiro") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
        Button(onClick = { if (email.contains("@")) onAddFriend(email.trim()) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Enviar pedido de amizade") }
        Text("Use o e-mail da conta da pessoa. Ela precisa aceitar o pedido.", color = Color(0xFFBFC4E0), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        Text(status, color = Color(0xFFFFD28A), fontSize = 12.sp)
        Text("Pedidos recebidos", color = Mint, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
        if (requests.isEmpty()) Text("Nenhum pedido pendente.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
        requests.forEach { person ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(person.avatarData, person.displayName)
                Text(person.displayName, color = Color.White, modifier = Modifier.weight(1f).padding(start = 8.dp))
                TextButton(onClick = { onRespond(person.requestId, true) }) { Text("Aceitar", color = Mint) }
                TextButton(onClick = { onRespond(person.requestId, false) }) { Text("Recusar", color = Color.LightGray) }
            }
        }
        Text("Meus amigos", color = Mint, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
        if (friends.isEmpty()) Text("Seus amigos aparecerão aqui quando aceitarem o pedido.", color = Color(0xFFBFC4E0), fontSize = 12.sp)
        friends.forEach { person ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(person.avatarData, person.displayName)
                Text(person.displayName, color = Color.White, modifier = Modifier.weight(1f).padding(start = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.size(7.dp).background(if (person.online) Mint else Color.Gray, CircleShape))
                    Text(if (person.online) "Online" else "Offline", color = if (person.online) Mint else Color.LightGray, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ProfileAvatar(data: String?, name: String) {
    val activity = androidx.compose.ui.platform.LocalContext.current as? MainActivity
    val bitmap = remember(data) { if (data != null) activity?.decodeSharedWallpaper(data) else null }
    if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = "Foto de $name", modifier = Modifier.size(38.dp).background(Panel, CircleShape), contentScale = ContentScale.Crop)
    else Box(Modifier.size(38.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.AccountCircle, "Foto de $name", tint = Mint) }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun ChatScreen(room: Room, name: String, messages: List<ChatMessage>, draft: String, currentUserId: String, avatarBitmap: Bitmap?, status: String, accessToken: String, activity: MainActivity?, onMessages: (List<ChatMessage>) -> Unit, onStatus: (String) -> Unit, onDraft: (String) -> Unit, onBack: () -> Unit, onSend: () -> Unit) {
    var messageAction by remember(room.id) { mutableStateOf<ChatMessage?>(null) }
    var friendCandidate by remember(room.id) { mutableStateOf<ChatMessage?>(null) }
    var hiddenRevision by remember(room.id, currentUserId) { mutableIntStateOf(0) }
    var wallpaperBitmap by remember(room.id) { mutableStateOf<Bitmap?>(null) }
    var savingWallpaper by remember(room.id) { mutableStateOf(false) }
    var recorderState by remember(room.id) { mutableStateOf(RecorderState.IDLE) }
    var sendingProgress by remember(room.id) { mutableIntStateOf(0) }
    var mediaUploading by remember(room.id) { mutableStateOf(false) }
    val loadedMediaFiles = remember { mutableStateMapOf<String, File>() }
    var mediaLoading by remember { mutableStateOf<String?>(null) }
    var showCameraMenu by remember { mutableStateOf(false) }
    var pendingCameraVideo by remember { mutableStateOf<File?>(null) }
    var pendingPhotoFile by remember { mutableStateOf<File?>(null) }
    var showEmojiPicker by remember { mutableStateOf(false) }
    var playingAudio by remember { mutableStateOf<String?>(null) }
    val isRecording = recorderState == RecorderState.RECORDING
    val sendingAudio = recorderState == RecorderState.SENDING
    val canSendMessages = !room.pendingInvite
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && !room.pendingInvite && activity != null) activity.startAudioRecording { error ->
            if (error != null) onStatus(error) else { recorderState = RecorderState.RECORDING; onStatus("Gravando sem limite de tempo… toque no botão para parar e enviar.") }
        } else onStatus("Permita o acesso ao microfone para gravar áudio.")
    }
    val pendingPhotoUri = remember { mutableStateOf<Uri?>(null) }
    val pendingVideoUri = remember { mutableStateOf<Uri?>(null) }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && activity != null && pendingPhotoUri.value != null) {
            val source = pendingPhotoFile
            pendingPhotoFile = null
            pendingPhotoUri.value = null
            val file = source?.let(activity::compressCameraPhoto)
            if (file == null) onStatus("Não consegui preparar a foto.") else {
                mediaUploading = true
                activity.shareMediaFile(accessToken, room.id, file, "image/jpeg") { result ->
                    if (result?.startsWith("PROGRESS:") == true) onStatus("Enviando foto: ${result.substringAfter(':')}%")
                    else {
                        mediaUploading = false
                        if (result != null) onStatus(result) else {
                            onStatus("Foto enviada.")
                            activity.loadMessages(accessToken, room.id) { found, _ -> if (found != null) onMessages(found) }
                        }
                    }
                }
            }
        } else if (!success) onStatus("Foto cancelada.")
    }
    val takeVideo = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { success ->
        if (success && activity != null && pendingCameraVideo != null) {
            val copied = pendingCameraVideo
            pendingCameraVideo = null
            pendingVideoUri.value = null
            if (copied == null) onStatus("Não encontrei o vídeo gravado.") else {
                mediaUploading = true
                onStatus("Enviando vídeo…")
                activity.shareMediaFile(accessToken, room.id, copied, "video/mp4") { result ->
                    if (result?.startsWith("PROGRESS:") == true) onStatus("Enviando vídeo: ${result.substringAfter(':')}%")
                    else {
                        mediaUploading = false
                        if (result != null) onStatus(result) else {
                            onStatus("Vídeo enviado.")
                            activity.loadMessages(accessToken, room.id) { found, _ -> if (found != null) onMessages(found) }
                        }
                    }
                }
            }
        } else if (!success) onStatus("Gravação de vídeo cancelada.")
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && activity != null) {
            savingWallpaper = true
            onStatus("Salvando papel de parede somente neste aparelho…")
            val localBitmap = activity.saveLocalChatWallpaper(currentUserId, room.id, uri)
            savingWallpaper = false
            if (localBitmap == null) onStatus("Não consegui salvar essa foto como papel de parede.")
            else {
                wallpaperBitmap = localBitmap
                onStatus("Papel de parede salvo só para este chat neste aparelho.")
            }
        }
    }
    DisposableEffect(room.id) {
        onDispose {
            if (recorderState == RecorderState.RECORDING) activity?.cancelAudioRecording()
            loadedMediaFiles.values.forEach { it.delete() }
            loadedMediaFiles.clear()
        }
    }
    var botDetectedCount by remember(room.id) { mutableIntStateOf(0) }
    var botDetectedLastId by remember(room.id) { mutableStateOf("") }
    LaunchedEffect(room.id, accessToken, currentUserId) {
        wallpaperBitmap = activity?.loadLocalChatWallpaper(currentUserId, room.id)
        var seenIds = messages.map { it.id }.toSet()
        while (true) {
            activity?.loadMessages(accessToken, room.id) { found, _ ->
                if (found != null) {
                    val previousIds = seenIds
                    val newMessages = found.filter { it.id !in previousIds }
                    // Etapa 2 apenas detecta novas mensagens de outros usuários em sala pública.
                    // Não envia texto ao Gemini nem publica respostas nesta etapa.
                    if (room.kind == RoomKind.PUBLIC) {
                        val eligible = newMessages.filter { it.senderId.isNotBlank() && it.senderId != currentUserId && it.text.isNotBlank() && !it.text.startsWith("/bot ", ignoreCase = true) }
                        if (eligible.isNotEmpty()) {
                            botDetectedCount += eligible.size
                            botDetectedLastId = eligible.last().id
                        }
                    }
                    seenIds = found.map { it.id }.toSet()
                    onMessages(found)
                }
            }
            delay(6000)
        }
    }
    if (friendCandidate != null) {
        val person = friendCandidate!!
        AlertDialog(
            onDismissRequest = { friendCandidate = null },
            title = { Text(person.author) },
            text = { Text("Enviar pedido de amizade para ${person.author}? A pessoa precisará aceitar. Isso não dá acesso automático a salas privadas.") },
            confirmButton = { TextButton(onClick = {
                friendCandidate = null
                if (activity == null || person.senderId == currentUserId) onStatus("Não é possível adicionar essa conta como amiga.")
                else {
                    onStatus("Enviando pedido de amizade…")
                    activity.requestFriendByUserId(accessToken, room.id, person.senderId) { error ->
                        onStatus(error ?: "Pedido de amizade enviado para ${person.author}; ela precisa aceitar.")
                    }
                }
            }) { Text("Enviar pedido") } },
            dismissButton = { TextButton(onClick = { friendCandidate = null }) { Text("Cancelar") } }
        )
    }
    if (messageAction != null && room.kind == RoomKind.PUBLIC) {
        val targetMessage = messageAction!!
        AlertDialog(
            onDismissRequest = { messageAction = null },
            title = { Text("Deseja apagar a mensagem?") },
            text = {
                Column {
                    TextButton(onClick = {
                        messageAction = null
                        activity?.deleteMessageForEveryone(accessToken, room.id, targetMessage.id, currentUserId) { error ->
                            if (error != null) onStatus(error)
                            else {
                                onMessages(messages.filterNot { it.id == targetMessage.id })
                                onStatus("Mensagem apagada para todos.")
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Apagar para todos", color = Mint) }
                    TextButton(onClick = {
                        activity?.hideMessageForMe(currentUserId, targetMessage.id)
                        hiddenRevision++
                        messageAction = null
                    }, modifier = Modifier.fillMaxWidth()) { Text("Apagar para mim", color = Mint) }
                    TextButton(onClick = { messageAction = null }, modifier = Modifier.fillMaxWidth()) { Text("Cancelar", color = Mint) }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(room.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(room.kind.label, color = Mint, fontSize = 12.sp)
            }
            IconButton(onClick = { if (!savingWallpaper) imagePicker.launch(arrayOf("image/*")) }, enabled = !savingWallpaper) {
                Icon(Icons.Default.Wallpaper, contentDescription = "Escolher papel de parede deste chat, só neste aparelho", tint = Mint)
            }
            Icon(when (room.kind) { RoomKind.PUBLIC -> Icons.Default.Public; RoomKind.PRIVATE -> Icons.Default.Lock; RoomKind.GROUP -> Icons.Default.Group }, null, tint = Mint)
            Spacer(Modifier.width(10.dp))
        }
        Text(status, color = Color(0xFFFFD28A), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("Sincroniza enquanto aberta • sem alertas com o app fechado", color = Color(0xFFBFC4E0), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(6.dp))
        if (room.kind == RoomKind.PUBLIC) {
            Text("Etapa 2 — detecção local: $botDetectedCount mensagem(ns) nova(s) detectada(s) de outras contas nesta sala. Nenhuma mensagem foi enviada ao Gemini e nenhuma resposta foi publicada.", color = Color(0xFFFFD28A), fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            wallpaperBitmap?.let { bitmap ->
                Image(bitmap.asImageBitmap(), contentDescription = "Papel de parede do chat", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(messages.filterNot { hiddenRevision >= 0 && activity?.isMessageHiddenForMe(currentUserId, it.id) == true }, key = { it.id }) { message ->
                val mine = message.senderId == currentUserId
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
                    if (!mine) {
                        if (message.avatarData != null && activity != null) {
                            val avatar = remember(message.senderId, message.avatarData) { activity.decodeSharedWallpaper(message.avatarData) }
                            if (avatar != null) Image(avatar.asImageBitmap(), contentDescription = "Foto de ${message.author} — tocar para adicionar como amigo", modifier = Modifier.size(36.dp).background(Panel, CircleShape).clickable { if (message.senderId.isNotBlank()) friendCandidate = message }, contentScale = ContentScale.Crop)
                            else Icon(Icons.Default.AccountCircle, "Tocar para adicionar ${message.author} como amigo", tint = Mint, modifier = Modifier.size(36.dp).clickable { if (message.senderId.isNotBlank()) friendCandidate = message })
                        } else Icon(Icons.Default.AccountCircle, "Tocar para adicionar ${message.author} como amigo", tint = Mint, modifier = Modifier.size(36.dp).clickable { if (message.senderId.isNotBlank()) friendCandidate = message })
                        Spacer(Modifier.width(6.dp))
                    }
                    Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start, modifier = Modifier.widthIn(max = 300.dp)) {
                    Card(
                        modifier = Modifier,
                        colors = CardDefaults.cardColors(containerColor = (if (mine) Color(0xFF5148A8) else Panel).copy(alpha = if (wallpaperBitmap != null) 0.82f else 1f)), shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(horizontal = 13.dp, vertical = 9.dp)) {
                            Text(if (mine) name else message.author, color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            if (message.mediaType != null) {
                                val localFile = loadedMediaFiles[message.id]
                                if (localFile != null && message.mediaType.startsWith("image/")) {
                                    val bitmap = remember(message.id) { BitmapFactory.decodeFile(localFile.absolutePath) }
                                    if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = "Foto enviada por ${message.author}", modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp), contentScale = ContentScale.Fit)
                                } else if (localFile != null && message.mediaType.startsWith("video/")) {
                                    AndroidView(factory = { context -> VideoView(context).apply {
                                        setVideoPath(localFile.absolutePath)
                                        setMediaController(MediaController(context).also { it.setAnchorView(this) })
                                    } }, modifier = Modifier.fillMaxWidth().height(220.dp))
                                } else {
                                    Text(if (mediaLoading == message.id) "Carregando foto/vídeo…" else "Foto ou vídeo", color = Color.White)
                                    Button(onClick = {
                                        if (activity != null && mediaLoading == null) {
                                            mediaLoading = message.id
                                            activity.loadMediaFile(accessToken, message.id) { file, mime, error ->
                                                mediaLoading = null
                                                if (error != null || file == null || mime == null) onStatus(error ?: "Mídia indisponível.")
                                                else loadedMediaFiles[message.id] = file
                                            }
                                        }
                                    }, enabled = mediaLoading == null) { Text(if (mediaLoading == message.id) "Carregando…" else "Ver mídia") }
                                }
                            } else if (message.audioId != null) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        if (playingAudio == message.id) return@Button
                                        else if (activity != null) {
                                            playingAudio = message.id
                                            activity.loadAudio(accessToken, message.id) { file, error ->
                                                if (error != null || file == null) { playingAudio = null; onStatus(error ?: "Áudio indisponível.") }
                                                else activity.playAudio(file) { if (playingAudio == message.id) playingAudio = null }
                                            }
                                        }
                                    }) { Text(if (playingAudio == message.id) "Tocando…" else "▶ Ouvir áudio") }
                                }
                            } else Text(message.text, color = Color.White, fontSize = 14.sp)
                            Text(message.time, color = Color(0xFFCFD3E8), fontSize = 9.sp, modifier = Modifier.align(Alignment.End))
                        }
                    }
                    }
                    if (mine) {
                        if (avatarBitmap != null) Image(avatarBitmap.asImageBitmap(), contentDescription = "Sua foto de perfil", modifier = Modifier.size(32.dp).background(Panel, CircleShape), contentScale = ContentScale.Crop)
                        else Icon(Icons.Default.AccountCircle, null, tint = Mint, modifier = Modifier.size(32.dp))
                    }
                }
            }
        }
        }
        if (showEmojiPicker && canSendMessages) {
            val emojis = listOf("😀","😂","🥰","😍","😊","😉","😭","😎","🤔","👍","❤️","🙏","🎉","🔥","👏","😅","😢","🥳","💯","✨","🤝","😘","🤗","🙌")
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 160.dp).background(Panel), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items(emojis.chunked(8)) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { emoji -> TextButton(onClick = { onDraft(draft + emoji); showEmojiPicker = false }) { Text(emoji, fontSize = 23.sp) } }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (canSendMessages) {
                IconButton(onClick = { showEmojiPicker = !showEmojiPicker }) { Icon(Icons.Default.EmojiEmotions, "Escolher emoji", tint = Mint) }
                OutlinedTextField(draft, onDraft, modifier = Modifier.weight(1f), placeholder = { Text("Escreva uma mensagem") }, maxLines = 4)
                IconButton(onClick = onSend) { Icon(Icons.Default.Send, "Enviar", tint = Mint) }
            } else {
                Text(if (room.pendingInvite) "Aceite o convite para conversar" else "Escreva uma mensagem", color = Color(0xFFBFC4E0), modifier = Modifier.weight(1f), fontSize = 12.sp)
            }
            Box {
                IconButton(onClick = { showCameraMenu = true }, enabled = canSendMessages && !mediaUploading) { Icon(Icons.Default.CameraAlt, "Tirar foto ou gravar vídeo", tint = if (canSendMessages) Mint else Color.Gray) }
                DropdownMenu(expanded = showCameraMenu, onDismissRequest = { showCameraMenu = false }) {
                        DropdownMenuItem(text = { Text("Tirar foto") }, onClick = {
                            showCameraMenu = false
                            if (activity != null) {
                                pendingPhotoFile = activity.createCameraImageFile()
                                val uri = activity.fileProviderUri(pendingPhotoFile!!)
                                pendingPhotoUri.value = uri
                                runCatching { takePhoto.launch(uri) }.onFailure { onStatus("Não encontrei um app de câmera para tirar foto.") }
                            }
                        })
                        DropdownMenuItem(text = { Text("Gravar vídeo") }, onClick = {
                            showCameraMenu = false
                            if (activity != null) {
                                pendingCameraVideo = activity.createCameraVideoFile()
                                val uri = activity.fileProviderUri(pendingCameraVideo!!)
                                pendingVideoUri.value = uri
                                runCatching { takeVideo.launch(uri) }.onFailure { onStatus("Não encontrei um app de câmera para gravar vídeo.") }
                            }
                        })
                }
            }
            if (canSendMessages) {
                IconButton(onClick = {
                    if (sendingAudio) return@IconButton
                    if (!isRecording) micPermission.launch(android.Manifest.permission.RECORD_AUDIO)
                    else {
                        recorderState = RecorderState.SENDING
                        sendingProgress = 0
                        onStatus("Preparando áudio…")
                        activity?.stopAudioRecording { file, stopError ->
                            if (stopError != null || file == null) { recorderState = RecorderState.IDLE; onStatus(stopError ?: "Gravação vazia.") }
                            else activity.sendAudioMessage(accessToken, room.id, file) { result ->
                                if (result?.startsWith("PROGRESS:") == true) {
                                    sendingProgress = result.substringAfter(":").toIntOrNull() ?: 0
                                    onStatus("Enviando áudio: $sendingProgress%")
                                } else {
                                    recorderState = RecorderState.IDLE
                                    if (result != null) onStatus(result)
                                    else {
                                        onStatus("Áudio enviado.")
                                        activity.loadMessages(accessToken, room.id) { found, loadError ->
                                            if (found != null) onMessages(found)
                                            if (loadError != null) onStatus(loadError)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, enabled = !sendingAudio) {
                    Icon(if (isRecording) Icons.Default.Stop else Icons.Default.Mic, if (isRecording) "Parar e enviar áudio" else "Gravar áudio", tint = if (isRecording) Color(0xFFFF6B6B) else Mint)
                }
            }
        }
    }
}
