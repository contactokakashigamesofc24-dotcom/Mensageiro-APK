package br.com.zapia.mensageiro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.unifiedpush.android.connector.FailedReason
import org.unifiedpush.android.connector.PushService
import org.unifiedpush.android.connector.data.PushEndpoint
import org.unifiedpush.android.connector.data.PushMessage

/** UnifiedPush receiver. Endpoint credentials are encrypted locally and never logged or displayed. */
class MessengerPushService : PushService() {
    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
    }

    override fun onNewEndpoint(endpoint: PushEndpoint, instance: String) {
        try {
            PushRegistrationVault.saveEndpoint(applicationContext, endpoint)
            applicationContext.sendBroadcast(Intent(ACTION_ENDPOINT_UPDATED).setPackage(packageName))
            genericNotice(this, "Notificações preparadas", "Registro deste aparelho guardado com proteção; aguardando vínculo com a conta.")
        } catch (_: Exception) {
            PushRegistrationVault.clearEndpoint(applicationContext)
            genericNotice(this, "Notificações", "Não foi possível guardar o registro com segurança.")
        }
    }

    override fun onMessage(message: PushMessage, instance: String) {
        // Intentionally ignore payload contents: no private message data on lock screen/logs.
        genericNotice(this, "Mensageiro", "Você tem uma nova atividade.")
    }

    override fun onRegistrationFailed(reason: FailedReason, instance: String) {
        // Do not include endpoint, token, or server response in user-facing diagnostics.
        genericNotice(this, "Notificações", "Não foi possível concluir o registro UnifiedPush.")
    }

    override fun onUnregistered(instance: String) {
        PushRegistrationVault.clearEndpoint(applicationContext)
        applicationContext.sendBroadcast(Intent(ACTION_ENDPOINT_REMOVED).setPackage(packageName))
        genericNotice(this, "Notificações", "A inscrição UnifiedPush foi removida.")
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Mensageiro", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisos genéricos do Mensageiro; o conteúdo das mensagens não aparece aqui."
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun genericNotice(context: Context, title: String, text: String) {
        val prefs = context.getSharedPreferences("messenger_settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("notifications_enabled", true)) return
        ensureChannel(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(if (prefs.getBoolean("hide_lock_screen_notices", true)) NotificationCompat.VISIBILITY_SECRET else NotificationCompat.VISIBILITY_PRIVATE)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Android 13+ may have notification permission disabled; do not log payload or secrets.
        }
    }

    companion object {
        const val ACTION_ENDPOINT_UPDATED = "br.com.zapia.mensageiro.PUSH_ENDPOINT_UPDATED"
        const val ACTION_ENDPOINT_REMOVED = "br.com.zapia.mensageiro.PUSH_ENDPOINT_REMOVED"
        private const val CHANNEL_ID = "mensageiro_generic_v2"
        private const val NOTIFICATION_ID = 71001
    }
}
