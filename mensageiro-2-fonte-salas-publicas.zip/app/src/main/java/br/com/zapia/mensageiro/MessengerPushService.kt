package br.com.zapia.mensageiro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.unifiedpush.android.connector.FailedReason
import org.unifiedpush.android.connector.PushService
import org.unifiedpush.android.connector.data.PushEndpoint
import org.unifiedpush.android.connector.data.PushMessage

/**
 * Minimal privacy-preserving UnifiedPush receiver. Push payload, endpoint URLs and keys are
 * deliberately not persisted, logged, displayed or forwarded. A trusted server-side dispatcher
 * and authenticated endpoint registration must be implemented before this can deliver app events.
 */
class MessengerPushService : PushService() {
    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
    }

    override fun onNewEndpoint(endpoint: PushEndpoint, instance: String) {
        // Endpoint URL and Web Push keys are bearer-like secrets; don't log or persist them.
        genericNotice(this, "Push preparado", "Registro local recebido; envio pelo servidor ainda não configurado.")
    }

    override fun onMessage(message: PushMessage, instance: String) {
        // Intentionally ignore payload contents: no private message data on lock screen/logs.
        genericNotice(this, "Mensageiro", "Você tem uma nova atividade.")
    }

    override fun onRegistrationFailed(reason: FailedReason, instance: String) {
        // Do not include endpoint, token, or server response in user-facing diagnostics.
        genericNotice(this, "Notificações", "Não foi possível concluir o registro UnifiedPush.")
    }

    override fun onUnregistered(instance: String) {
        genericNotice(this, "Notificações", "A inscrição UnifiedPush foi removida.")
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Mensageiro", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Avisos genéricos do Mensageiro; o conteúdo das mensagens não aparece aqui."
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun genericNotice(context: Context, title: String, text: String) {
        ensureChannel(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Android 13+ may have notification permission disabled; do not log payload or secrets.
        }
    }

    companion object {
        private const val CHANNEL_ID = "mensageiro_generic"
        private const val NOTIFICATION_ID = 71001
    }
}
