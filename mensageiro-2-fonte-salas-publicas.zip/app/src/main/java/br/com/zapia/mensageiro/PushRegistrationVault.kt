package br.com.zapia.mensageiro

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import org.unifiedpush.android.connector.data.PushEndpoint
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Keeps the bearer-like UnifiedPush endpoint and keys encrypted with an Android Keystore key. */
internal object PushRegistrationVault {
    private const val PREFS = "messenger_push_secure"
    private const val KEY_ALIAS = "mensageiro_push_endpoint_v1"
    private const val DEVICE_ID_KEY = "device_id"
    private const val ENDPOINT_KEY = "endpoint_ciphertext"
    private const val ENDPOINT_UPDATED_KEY = "endpoint_updated_at"
    private const val REGISTERED_USER_KEY = "registered_user_id"

    fun deviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString(DEVICE_ID_KEY, null)
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString()
        prefs.edit().putString(DEVICE_ID_KEY, created).apply()
        return created
    }

    fun saveEndpoint(context: Context, endpoint: PushEndpoint) {
        require(endpoint.url.startsWith("https://") && endpoint.url.length <= 2048) { "invalid_endpoint" }
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (keyStore.getKey(KEY_ALIAS, null) !is SecretKey) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(ENDPOINT_KEY).remove(ENDPOINT_UPDATED_KEY).apply()
        }
        require(!endpoint.temporary) { "temporary_endpoint" }
        val keys = endpoint.pubKeySet ?: throw IllegalArgumentException("missing_keys")
        val json = JSONObject()
            .put("url", endpoint.url)
            .put("temporary", endpoint.temporary)
            .put("pubKeySet", JSONObject().put("pubKey", keys.pubKey).put("auth", keys.auth))
            .toString()
        val encrypted = encrypt(json.toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ENDPOINT_KEY, encrypted)
            .putLong(ENDPOINT_UPDATED_KEY, System.currentTimeMillis())
            .apply()
    }

    fun endpointUpdatedAt(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(ENDPOINT_UPDATED_KEY, 0L)

    fun readEndpoint(context: Context): JSONObject? {
        val value = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ENDPOINT_KEY, null) ?: return null
        return try {
            JSONObject(String(decrypt(value), Charsets.UTF_8))
        } catch (_: Exception) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(ENDPOINT_KEY).remove(ENDPOINT_UPDATED_KEY).apply()
            null
        }
    }

    fun registeredUserId(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(REGISTERED_USER_KEY, null)

    fun setRegisteredUserId(context: Context, userId: String?) {
        val edit = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (userId.isNullOrBlank()) edit.remove(REGISTERED_USER_KEY) else edit.putString(REGISTERED_USER_KEY, userId)
        edit.apply()
    }

    fun clearEndpoint(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(ENDPOINT_KEY).remove(ENDPOINT_UPDATED_KEY).apply()
    }

    fun clearRegistrationBinding(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(REGISTERED_USER_KEY).apply()
    }

    private fun encrypt(plain: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(plain)
        val combined = cipher.iv + encrypted
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): ByteArray {
        val combined = Base64.decode(value, Base64.NO_WRAP)
        require(combined.size > 12)
        val iv = combined.copyOfRange(0, 12)
        val encrypted = combined.copyOfRange(12, combined.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(encrypted)
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(false)
                .build()
        )
        return generator.generateKey()
    }
}
