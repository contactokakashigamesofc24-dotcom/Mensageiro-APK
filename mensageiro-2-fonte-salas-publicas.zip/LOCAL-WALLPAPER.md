# Papel de parede local por chat

- Escolher pelo ícone de papel de parede na conversa e selecionar uma foto.
- O arquivo é redimensionado e salvo no armazenamento privado do app, separado por conta e sala.
- Não faz upload, não cria ou atualiza dados no Nhost e não aparece nos dispositivos de outros participantes.
- Reabrir o mesmo chat carrega a foto salva neste aparelho.
- Limpar o cache temporário não remove o papel de parede, pois ele fica em armazenamento privado persistente.
- O SQL antigo de wallpaper compartilhado permanece apenas no diretório backend como preparação histórica; este fluxo novo não o chama.

Estado: código-fonte modificado, ainda sem build e sem teste em telefone.
