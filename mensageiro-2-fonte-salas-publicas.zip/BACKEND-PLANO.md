# Backend do Mensageiro — plano, ainda não implantado

Não execute SQL desta pasta em nenhum banco existente. Este projeto ainda não tem backend conectado.

Para tornar o app real entre celulares, primeiro criar um Supabase novo e dedicado ao Mensageiro; depois modelar e testar:
- Auth com cadastro por e-mail e confirmação.
- perfis públicos com dados mínimos;
- salas públicas discoverable por usuários autenticados;
- salas privadas com convite e aceite explícitos;
- mensagens acessíveis apenas aos membros aceitos em salas privadas;
- políticas RLS revisadas para evitar recursão e testes de isolamento;
- Realtime, bloqueio/denúncia, rate limits e exclusão de conta.

Não incluir dados, chaves, tabelas ou funções dos projetos Chave Wi-Fi, Compartilha Seguro ou ChatBot. Não publicar como mensageiro de produção antes de testar com duas contas e uma conta não membro.
