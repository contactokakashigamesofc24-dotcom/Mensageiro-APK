# Mensageiro novo — etapa 2/4: detecção local de mensagens

Esta etapa mantém o Mensageiro novo e acrescenta no chat público um contador de mensagens novas recebidas de outras contas enquanto a tela do chat está aberta. Identifica remetente diferente do usuário local e ignora comandos `/bot` neste modo de observação.

**Importante:** detecção apenas local; não envia conteúdo ao Gemini, não faz respostas automáticas, não cria publicações, não modifica permissões/banco e não restringe criação ou uso de salas. Não funciona com o app fechado.

Esta é uma cópia de código-fonte para revisão; não compilada.
