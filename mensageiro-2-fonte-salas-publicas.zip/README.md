# Mensageiro — Android em desenvolvimento

Versão 0.6 conecta a interface a um backend Nhost dedicado criado pelo usuário na região São Paulo (`sa-east-1`), subdomínio `fapcygtcubeukddoieus`.

## Funcionalidades desta etapa
- Cadastro/login com e-mail e senha própria do Mensageiro via Nhost Auth.
- Lista de salas e operações GraphQL com token da conta do usuário.
- Envio e leitura de mensagens salvas no servidor.
- Atualização periódica a cada 4 segundos enquanto uma conversa está aberta.
- Salas públicas para usuários autenticados e salas privadas limitadas ao criador, se as permissões Hasura forem configuradas conforme o guia.

## Importante antes de compilar/testar
- Primeiro aplique `backend/MENSAGEIRO_SCHEMA.sql` no SQL Editor do projeto Nhost e acompanhe as tabelas no Hasura.
- Configure role `user` exatamente conforme `backend/HASURA_PERMISSIONS.md`. Sem isso, as operações não devem ser abertas; tabelas começam negadas.
- O código nunca inclui admin secret e não envia `created_by` ou `sender_id` escolhidos pelo cliente; as permissões devem predefinir ambos com `X-Hasura-User-Id`.
- A interface de convite/aceite e funções SQL estão preparadas em `backend/PRIVATE_ROOM_INVITES.sql` e `backend/PRIVATE_ROOM_INVITES.md`. Elas trabalham com a sala privada existente (não criam outra). **Ainda não estão instaladas/testadas em produção**: exige aplicar o SQL, acompanhar funções Hasura e configurar/verificar permissões exatamente como o guia. Não convide por outro meio nem declare privacidade validada antes dos testes com contas reais.
- APK ainda não compilado ou testado após essa alteração; construir no workflow GitHub e testar com duas contas e duas instalações.
- Notificações de mensagens com o app fechado **ainda não estão disponíveis**. O pacote inclui somente preparação local UnifiedPush/ntfy, sem backend de envio/registro autenticado; consulte `UNIFIEDPUSH-PARTIAL.md`. Sem sessão persistente/refresh token implementado e sem criptografia ponta a ponta.
- Não use para dados sensíveis antes da validação de segurança descrita no guia.

## Workflow
O workflow do GitHub extrai `mensageiro-prototipo.zip`, compila e publica um artefato APK. Substitua o ZIP antigo pelo pacote atualizado antes de executar.

## Menu de apagar mensagens públicas (código em preparação)
- Toque longo na própria mensagem pública abre “Deseja apagar a mensagem?” com “Apagar para todos”, “Apagar para mim” e “Cancelar”.
- “Apagar para mim” oculta localmente apenas na conta/aparelho atual.
- “Apagar para todos” remove a mensagem do servidor e dos dois chats. O backend precisa autorizar delete apenas quando `sender_id` é o usuário autenticado e a sala relacionada é pública. A permissão continua negada até ser configurada e testada com duas contas; não declarar funcional antes disso.
- “Cancelar” fecha o diálogo sem alterar a mensagem.
- Este código ainda precisa ser compilado e testado em dois celulares após configurar a permissão do servidor.

## Grupos privados

O pacote mais recente inclui criação de grupos privados com amigos aceitos, convites pendentes/aceitos e interface de sala. Configure `backend/MESSENGER_GROUPS.sql` e leia `backend/MESSENGER_GROUPS.md` antes de usar; não há teste entre contas nem build confirmado para esta alteração. Restringir as permissões do Hasura é essencial para impedir que terceiros acessem UUIDs privados.

## Bloqueio de mensagens de desconhecidos

Pacote atual: salas públicas somente leitura; o envio público foi retirado. Mensagens/áudios/fotos/vídeos exigem sala privada/grupo autorizado e flag global ativa. Aplique `backend/MESSENGER_GLOBAL_SWITCH.sql` e valide com contas não administrativas seguindo o guia; ainda não há build ou teste pós-alteração confirmado.

## Direitos autorais

A tela Configurações exibe “© 2026 Luiz Fernando. Todos os direitos reservados.” para identificar a autoria pretendida do código e dos materiais originais. Bibliotecas e componentes de terceiros continuam sob suas próprias licenças; o aviso não altera essas licenças nem equivale, por si só, a registro formal.


## Papel de parede local por chat

O ícone de papel de parede abre a galeria e grava a imagem escolhida somente no armazenamento privado deste aparelho, por usuário e por sala. Não envia a foto ao Nhost e não altera o papel de parede de outros participantes. A imagem permanece depois de fechar e abrir o chat novamente; limpar arquivos temporários/cache não apaga esse papel de parede local.


## Adicionar amigo tocando na foto no chat

O código-fonte agora abre uma confirmação quando o usuário toca na foto/nome visual de outra conta que escreveu na sala. O pedido usa o UUID de remetente que o app já recebeu para renderizar a mensagem; o servidor precisa oferecer `request_friend_by_user_id_in_room` com sessão Hasura injetada. A migração proposta está em `backend/FRIEND_REQUEST_FROM_CHAT.sql` e permanece staged, sem aplicação no Nhost. Depois do pedido, a outra pessoa ainda precisa aceitar; amizade não concede acesso automático a salas privadas.
