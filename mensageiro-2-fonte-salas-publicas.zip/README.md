# Mensageiro 2 — salas públicas

Cópia Android separada do Mensageiro, mantendo o mesmo serviço Nhost de autenticação e dados. O applicationId foi separado para permitir instalar ao lado do app atual.

O código usa o mesmo endpoint Nhost existente; contas cadastradas permanecem no serviço e podem entrar com os dados atuais. A cópia restaura no cliente a criação/uso de salas públicas com base no projeto anterior.

## Importante
- Este projeto não cria nem migra contas e não cria outro projeto Nhost.
- Nenhuma alteração foi aplicada ao backend. A instalação e a operação dependem de as permissões/funções já publicadas no Nhost ainda aceitarem operações em salas públicas.
- O backend deve ser validado com as contas existentes antes de considerar o funcionamento garantido.
- O bot não está incluído nesta cópia e não altera as salas.
- O APK é gerado pelo GitHub Actions e não está assinado para Play Store.
