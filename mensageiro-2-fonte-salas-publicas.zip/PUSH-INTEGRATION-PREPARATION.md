# Mensageiro — preparação UnifiedPush (não compilada / não publicada)

Esta versão prepara a ponta Android para registrar uma inscrição do Sunup sem Firebase.

## Alterações incluídas
- Recebe endpoint e chaves Web Push no callback UnifiedPush e cifra o JSON localmente com AES-GCM e chave Android Keystore.
- Recusa endpoints marcados como temporários; não registra URL/chaves em logs ou na tela.
- Usa UUID persistente da instalação para distinguir o dispositivo.
- Adiciona cliente para rotas Nhost `GET /v1/push/vapid`, `POST /v1/push/register` e `POST /v1/push/unregister`, sempre com TLS e Bearer JWT nas rotas privadas.
- A inscrição é vinculada à conta autenticada quando já existe endpoint guardado; troca de conta não substitui silenciosamente o vínculo anterior.
- Ao sair/desativar, tenta revogar a inscrição com token da conta antes de remover o registro local; se a revogação falhar, avisa que o vínculo servidor precisa ser verificado.
- Avisos genéricos permanecem sem texto de mensagem e passam para canal Android de alta prioridade com ID de canal novo.
- A tela não diz que push de conversas já está funcionando.

## Requisitos antes de testar
1. No Nhost, implantar manualmente as Functions revisadas no repositório backend; implantação automática deve permanecer desligada até autorização explícita.
2. Configurar variáveis secretas no painel e VAPID; Nhost precisa responder `GET /v1/push/vapid` com chave pública válida. Sem isso, o app deliberadamente não solicita o endpoint ao Sunup.
3. Confirmar allowlist de contas e schema/metadata. A permissão `user` para as três tabelas push deve permanecer sem acesso direto; o backend usa admin secret apenas dentro do Nhost.
4. Validar a URL real do Sunup, fazer build e testar em aparelho com app aberto/fechado, permissão Android e segunda conta/dispositivo. O sistema Android pode suprimir notificações heads-up via configuração do usuário/fabricante.

## Estado desta entrega
- São apenas arquivos-fonte num ZIP para revisão/compilação pelo usuário.
- Não houve build, testes Android, publicação de APK, commit em repositório APK, implantação Nhost nem envio de endpoint/chaves.
- A URL da Function está fixa para o projeto Mensageiro em `sa-east-1`; verificar se o endpoint functions correto responde antes de usar.
- O endpoint guardado localmente é segredo de entrega; nunca compartilhar em captura, mensagem ou log.
