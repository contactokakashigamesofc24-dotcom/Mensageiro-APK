Etapa 3 — gate de sessão, não integração de conteúdo.

Worker separado em Cloudflare valida token de acesso por encaminhamento seguro ao endpoint de sessão Nhost; resposta não expõe identidade. Worker não tem bindings nem segredos, não conversa com Gemini, não lê GraphQL nem banco, e não recebe conteúdo de chat.

O botão na tela Configurações executa apenas esse teste. Respostas automáticas continuam desligadas; etapa 4 não implementada. Esta cópia exige build e teste do APK no aparelho.
