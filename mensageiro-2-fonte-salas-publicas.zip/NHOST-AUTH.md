# Nhost Auth — projeto Mensageiro

Projeto dedicado do usuário, região São Paulo (`sa-east-1`), subdomínio `fapcygtcubeukddoieus`.

O app usa os endpoints Nhost Auth para cadastro e login por e-mail/senha. Não usa senha do Gmail, service role ou segredo administrativo.

## Confirmação de e-mail e retorno ao app

A versão 0.4 envia `redirectTo=mensageiro://auth/callback` no cadastro e registra esse deep link Android no app. Antes de pedir nova confirmação, no painel do Nhost, configure Auth → Client & Redirect URLs:
- Client URL pode ficar definido como o endereço de um frontend de produção quando houver;
- Allowed Redirect URLs: adicionar exatamente `mensageiro://auth/callback` (se o painel aceitar esquema Android personalizado).

Depois, reenviar a confirmação para o usuário não confirmado usando o fluxo seguro de Auth ou fazer novo cadastro apenas se o Nhost permitir. Não reutilizar o link antigo: ele já contém o redirect `localhost:3000`.

Ao tocar no link de confirmação novo no Android com este APK instalado, o sistema deve oferecer/abrir Mensageiro. O usuário então volta à tela de login e entra com e-mail e senha do app.

Teste real em aparelho obrigatório: verificar se o painel Nhost aceita `mensageiro://auth/callback`, se e-mail usa esse redirect e se Android abre o app. Se Nhost rejeitar esquema customizado, usar um domínio HTTPS de callback controlado pelo projeto que redirecione para o deep link e adicionar ambos à allowlist.

## Limites atuais
- Cadastro/login podem ser testados com credenciais reais do app após o callback estar configurado.
- Sessão não é persistida entre reinícios.
- Autenticação ainda NÃO conecta salas nem mensagens entre usuários.


## Recuperação da senha (2.2.12)
Na tela de entrada, toque em “Esqueci minha senha” e informe o e-mail da conta do Mensageiro. O link de redefinição usa PKCE e abre o app pelo endereço `mensageiro://auth/callback`. O app troca o código de uso único pela sessão de recuperação e envia a nova senha ao endpoint Auth da Nhost. O verificador PKCE fica somente nas preferências privadas do app e o link deve ser aberto no mesmo aparelho onde o pedido foi iniciado.

Antes de testar, em Auth → Settings → Client & Redirect URLs, adicionar exatamente `mensageiro://auth/callback` à lista de redirecionamentos permitidos. Não alterar provedores OAuth.


## Recuperação de senha (v2.2.13)
O projeto usa o fluxo de ticket da Nhost Auth legada. O app solicita recuperação sem `codeChallenge`, recebe o ticket no redirecionamento `mensageiro://auth/callback` e o envia junto da nova senha para `/user/password`. Permitir esse URI em Auth → Settings → Client & Redirect URLs. Abra o e-mail no mesmo aparelho.


## Recuperação de senha (v2.2.14)
Este projeto usa o fluxo legado de ticket da Nhost Auth. O app solicita recuperação sem `codeChallenge`, recebe o ticket no redirecionamento `mensageiro://auth/callback` e o envia junto à nova senha para `/user/password`. Permita esse URI em Auth → Settings → Client & Redirect URLs e abra o e-mail no mesmo aparelho.
