# Mensageiro — UnifiedPush/ntfy (preparação local, não ponta a ponta)

## O que esta atualização de fonte faz

- Usa o `org.unifiedpush.android:connector:3.3.5` e declara o serviço de recepção conforme a documentação oficial do UnifiedPush.
- Acrescenta a permissão Android `POST_NOTIFICATIONS`; no Android 13 (API 33) e posteriores, pede autorização ao tocar em **Preparar UnifiedPush neste aparelho**.
- Adiciona canal de notificação Android e receptor que, deliberadamente, ignora qualquer corpo recebido e exibe apenas avisos genéricos.
- Acrescenta a opção de remover a inscrição UnifiedPush deste aparelho.
- Não grava nem imprime endpoints, chaves ou tokens; não mostra conteúdo de mensagens em notificações.

## Limite importante: isto não entrega notificações de mensagens

O botão solicita uma inscrição ao distribuidor instalado. Para o usuário selecionar ntfy, o app ntfy precisa estar instalado/aberto e configurado como distribuidor UnifiedPush. Um endpoint pode ser criado pelo distribuidor, mas esta versão **não envia endpoint ou chaves a um backend**, não registra a conta no backend, não despacha mensagens e não dá suporte a desassociar conta/sessão no servidor. O receptor local apenas apresenta um aviso genérico quando recebe algum evento. Não existe notificação real de mensagens com o app fechado nesta entrega.

Não testar como se fosse uma notificação de conversa e não informar que push está ativo. O botão só serve para validar a seleção/registro local do distribuidor, até a integração autenticada do servidor ser feita. Se foi tocado e quiser limpar a inscrição, use **Desativar notificações neste aparelho**. O backend não foi alterado.

## Verificação do backend disponível (Nhost)

No projeto Nhost indicado para o Mensageiro, o navegador autenticado mostrou somente as tabelas `messages`, `rooms` e `room_members` em `public`. Não apareceu tabela de dispositivos/inscrições nem serviço de despacho confiável. Há SQLs e funções de recursos em desenvolvimento no repositório, mas não estavam visíveis como instalados/verificados no banco; não foram executados nesta tarefa. As permissões Hasura de mensagens/membros tampouco foram testadas com usuários reais. Portanto, não é seguro inferir que a segurança pretendida está aplicada ou instalar uma rotina de notificações agora.

## Próximas etapas necessárias antes de usar em produção

1. No Nhost, validar o schema e as permissões Hasura existentes, especialmente leitura de mensagens, membros aceitos e envio apenas em salas/grupos permitidos; testar com contas membro e não membro. Não abrir CRUD público nem colocar admin secret no APK.
2. Projetar e revisar uma função/serviço server-side autenticado para registrar/rotacionar/remover endpoints por conta/dispositivo, verificando token Nhost, identidade de sessão do servidor, HTTPS, tamanho/formato, limites e unicidade. Guardar endpoints e chaves criptografados e com acesso mínimo; nunca aceitar um destino/URL arbitrário enviado pelo app, para evitar SSRF/open relay.
3. Implementar exclusão da inscrição no logout, na troca de conta e na desinstalação/rotação de endpoint, com chamadas autenticadas e tratamento de falha/retry; só depois usar instâncias separadas corretamente por conta/dispositivo. Esta interface atual não tem logout implementado.
4. Criar um dispatcher confiável acionado por mensagem criada somente após checar as permissões reais e membros com `accepted_at IS NOT NULL`; excluir remetente e não membros. Validar idempotência, rate limits e expiração. Payload deve ser genérico (sem texto, nomes ou sala privada) e criptografado conforme o protocolo/biblioteca oficial do UnifiedPush. Não disparar para sala pública somente-leitura nem para convites pendentes.
5. Configurar, publicar e validar o backend por procedimento autenticado; só então implementar o cliente de endpoint e confirmar entrega, troca de endpoint, revogação/logout e isolamento entre duas contas/aparelhos.

## Compatibilidade e dependências

- O projeto já declara `minSdk 26`, compatível com a versão mínima documentada para o connector (Android 4.1+). A solicitação dinâmica de permissão de notificações é aplicável a Android 13/API 33+; em versões anteriores usa o controle de notificação do sistema.
- ntfy está no aparelho conforme informado, mas precisa estar ativo e escolhido como distribuidor UnifiedPush. O fato de o aplicativo ntfy estar instalado não comprova que o registro foi concedido nem garante entrega; a configuração de bateria/rede/servidor também pode afetar atraso.
- A documentação do ntfy alerta que, sem modo de entrega instantânea em builds pertinentes, Android Doze pode atrasar avisos. O app ntfy/distribuidor é necessário; nenhum Firebase foi adicionado pelo Mensageiro.

## Referências oficiais consultadas

- UnifiedPush Connector: https://unifiedpush.org/kdoc/connector/
- Código fonte espelho da biblioteca: https://github.com/UnifiedPush/android-connector
- ntfy como distribuidor UnifiedPush para Android: https://unifiedpush.org/users/distributors/ntfy/
- ntfy no telefone: https://docs.ntfy.sh/subscribe/phone/
- Maven Central connector `3.3.5`: https://central.sonatype.com/artifact/org.unifiedpush.android/connector

A biblioteca connector foi inspecionada para usar sua API `PushService`, eventos `PUSH_EVENT`, `tryUseCurrentOrDefaultDistributor`, `register` e `unregister`. O aplicativo não tem um endpoint de envio próprio configurado.
