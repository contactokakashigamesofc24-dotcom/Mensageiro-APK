# Mensageiro — bot, etapa 1/4: controles de Configurações

Esta cópia mantém o Mensageiro novo e acrescenta, na tela de Configurações existente, a estrutura visual das opções de respostas automáticas, comando `/bot` e seleção de salas públicas.

**Estado desta etapa:** controles deliberadamente desativados; nada é enviado ou recebido pelo bot. Não há integração de servidor, consulta ao Gemini, alteração de permissões, migração SQL, nem restrição de criação/uso das salas.

Próximas etapas, uma por vez e somente após validação: 2) detecção de mensagens novas enquanto o app estiver aberto; 3) Worker privado com chave Gemini como segredo; 4) publicação segura no mesmo chat.

Este é apenas o código-fonte ZIP. Não compilei nem publiquei APK.
